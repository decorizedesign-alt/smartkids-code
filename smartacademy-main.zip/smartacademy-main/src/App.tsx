import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { supabase } from './lib/supabase';

// Public pages
import HomePage from './pages/public/HomePage';
import CoursesPage from './pages/public/CoursesPage';
import PricingPage from './pages/public/PricingPage';
import AboutPage from './pages/public/AboutPage';
import ContactPage from './pages/public/ContactPage';
import FAQPage from './pages/public/FAQPage';
import BlogPage from './pages/public/BlogPage';

// Auth pages
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage';
import StudentLoginPage from './pages/auth/StudentLoginPage';
import TeacherLoginPage from './pages/auth/TeacherLoginPage';
import ParentLoginPage from './pages/auth/ParentLoginPage';

// Student pages
import StudentDashboard from './pages/student/StudentDashboard';
import StudentCourses from './pages/student/StudentCourses';
import StudentLiveClasses from './pages/student/StudentLiveClasses';
import StudentProjects from './pages/student/StudentProjects';
import StudentBadges from './pages/student/StudentBadges';
import StudentProfile from './pages/student/StudentProfile';
import StudentNotifications from './pages/student/StudentNotifications';
import StudentSettings from './pages/student/StudentSettings';

// Teacher pages
import TeacherDashboard from './pages/teacher/TeacherDashboard';
import TeacherStudents from './pages/teacher/TeacherStudents';
import TeacherCourses from './pages/teacher/TeacherCourses';
import TeacherAssignments from './pages/teacher/TeacherAssignments';
import TeacherLiveSessions from './pages/teacher/TeacherLiveSessions';
import TeacherAnalytics from './pages/teacher/TeacherAnalytics';
import TeacherMessages from './pages/teacher/TeacherMessages';
import TeacherSettings from './pages/teacher/TeacherSettings';

// Parent pages
import ParentDashboard from './pages/parent/ParentDashboard';
import ParentChildProgress from './pages/parent/ParentChildProgress';
import ParentBilling from './pages/parent/ParentBilling';
import ParentOrders from './pages/parent/ParentOrders';
import ParentShipping from './pages/parent/ParentShipping';
import ParentReports from './pages/parent/ParentReports';
import ParentMessages from './pages/parent/ParentMessages';
import ParentSettings from './pages/parent/ParentSettings';

// Admin pages
import AdminLoginPage from './pages/admin/AdminLoginPage';
import AdminForcePasswordChange from './pages/admin/AdminForcePasswordChange';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminUsers from './pages/admin/AdminUsers';
import AdminTeachers from './pages/admin/AdminTeachers';
import AdminStudents from './pages/admin/AdminStudents';
import AdminParents from './pages/admin/AdminParents';
import AdminCourses from './pages/admin/AdminCourses';
import AdminKits from './pages/admin/AdminKits';
import AdminBilling from './pages/admin/AdminBilling';
import AdminNotifications from './pages/admin/AdminNotifications';
import AdminAnalytics from './pages/admin/AdminAnalytics';
import AdminSettings from './pages/admin/AdminSettings';

// Layouts
import PublicLayout from './components/layouts/PublicLayout';
import StudentLayout from './components/layouts/StudentLayout';
import TeacherLayout from './components/layouts/TeacherLayout';
import ParentLayout from './components/layouts/ParentLayout';
import AdminLayout from './components/layouts/AdminLayout';
import ProtectedRoute from './components/auth/ProtectedRoute';

export default function App() {
  const { fetchUserData, setLoading, setProfile } = useAuthStore();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        fetchUserData(session.user.id).finally(() => setLoading(false));
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        fetchUserData(session.user.id);
      } else {
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchUserData, setLoading, setProfile]);

  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/courses" element={<CoursesPage />} />
          <Route path="/pricing" element={<PricingPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/blog" element={<BlogPage />} />
        </Route>

        {/* Auth Routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/login/student" element={<StudentLoginPage />} />
        <Route path="/login/teacher" element={<TeacherLoginPage />} />
        <Route path="/login/parent" element={<ParentLoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />

        {/* Admin Auth (unprotected) */}
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route path="/admin/force-change-password" element={<AdminForcePasswordChange />} />

        {/* Admin Routes (protected) */}
        <Route path="/admin" element={
          <ProtectedRoute role="admin">
            <AdminLayout />
          </ProtectedRoute>
        }>
          <Route index element={<Navigate to="/admin/dashboard" replace />} />
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="teachers" element={<AdminTeachers />} />
          <Route path="students" element={<AdminStudents />} />
          <Route path="parents" element={<AdminParents />} />
          <Route path="courses" element={<AdminCourses />} />
          <Route path="kits" element={<AdminKits />} />
          <Route path="billing" element={<AdminBilling />} />
          <Route path="notifications" element={<AdminNotifications />} />
          <Route path="analytics" element={<AdminAnalytics />} />
          <Route path="settings" element={<AdminSettings />} />
        </Route>

        {/* Student Routes */}
        <Route path="/student" element={
          <ProtectedRoute role="student">
            <StudentLayout />
          </ProtectedRoute>
        }>
          <Route index element={<Navigate to="/student/dashboard" replace />} />
          <Route path="dashboard" element={<StudentDashboard />} />
          <Route path="courses" element={<StudentCourses />} />
          <Route path="live-classes" element={<StudentLiveClasses />} />
          <Route path="projects" element={<StudentProjects />} />
          <Route path="badges" element={<StudentBadges />} />
          <Route path="profile" element={<StudentProfile />} />
          <Route path="notifications" element={<StudentNotifications />} />
          <Route path="settings" element={<StudentSettings />} />
        </Route>

        {/* Teacher Routes */}
        <Route path="/teacher" element={
          <ProtectedRoute role="teacher">
            <TeacherLayout />
          </ProtectedRoute>
        }>
          <Route index element={<Navigate to="/teacher/dashboard" replace />} />
          <Route path="dashboard" element={<TeacherDashboard />} />
          <Route path="students" element={<TeacherStudents />} />
          <Route path="courses" element={<TeacherCourses />} />
          <Route path="assignments" element={<TeacherAssignments />} />
          <Route path="live-sessions" element={<TeacherLiveSessions />} />
          <Route path="analytics" element={<TeacherAnalytics />} />
          <Route path="messages" element={<TeacherMessages />} />
          <Route path="settings" element={<TeacherSettings />} />
        </Route>

        {/* Parent Routes */}
        <Route path="/parent" element={
          <ProtectedRoute role="parent">
            <ParentLayout />
          </ProtectedRoute>
        }>
          <Route index element={<Navigate to="/parent/dashboard" replace />} />
          <Route path="dashboard" element={<ParentDashboard />} />
          <Route path="child-progress" element={<ParentChildProgress />} />
          <Route path="billing" element={<ParentBilling />} />
          <Route path="orders" element={<ParentOrders />} />
          <Route path="shipping" element={<ParentShipping />} />
          <Route path="reports" element={<ParentReports />} />
          <Route path="messages" element={<ParentMessages />} />
          <Route path="settings" element={<ParentSettings />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
