import { Navigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import type { UserRole } from '../../types';

interface ProtectedRouteProps {
  children: React.ReactNode;
  role: UserRole;
}

export default function ProtectedRoute({ children, role }: ProtectedRouteProps) {
  const { profile, isLoading, isAuthenticated } = useAuthStore();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-white">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-purple-600 font-medium">Loading Smart Kids Academy...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !profile) {
    const loginMap: Record<UserRole, string> = {
      student: '/login/student',
      teacher: '/login/teacher',
      parent: '/login/parent',
      admin: '/admin/login',
    };
    return <Navigate to={loginMap[role]} replace />;
  }

  if (profile.role !== role) {
    const redirectMap: Record<UserRole, string> = {
      student: '/student/dashboard',
      teacher: '/teacher/dashboard',
      parent: '/parent/dashboard',
      admin: '/admin/dashboard',
    };
    return <Navigate to={redirectMap[profile.role]} replace />;
  }

  // Admin must change password before accessing anything else
  if (role === 'admin' && (profile as { force_password_change?: boolean }).force_password_change) {
    return <Navigate to="/admin/force-change-password" replace />;
  }

  return <>{children}</>;
}
