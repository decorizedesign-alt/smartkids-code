import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import {
  LayoutDashboard, BookOpen, Video, Folder, Award,
  User, Bell, Settings, Bot, LogOut, Menu, X,
  Star, Zap, Home
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/student/dashboard' },
  { icon: BookOpen, label: 'My Courses', path: '/student/courses' },
  { icon: Video, label: 'Live Classes', path: '/student/live-classes' },
  { icon: Folder, label: 'Projects', path: '/student/projects' },
  { icon: Award, label: 'Badges', path: '/student/badges' },
  { icon: User, label: 'Profile', path: '/student/profile' },
  { icon: Bell, label: 'Notifications', path: '/student/notifications' },
  { icon: Settings, label: 'Settings', path: '/student/settings' },
];

export default function StudentLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { profile, student, signOut } = useAuthStore();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login/student');
  };

  const levelColors = ['bg-green-500', 'bg-blue-500', 'bg-purple-500', 'bg-orange-500', 'bg-yellow-500'];
  const levelColor = levelColors[(student?.current_level ?? 1) - 1];
  const xpForNext = [500, 1500, 3500, 7500, 9999];
  const xpPercent = student ? Math.min(100, (student.xp_points / xpForNext[student.current_level - 1]) * 100) : 0;

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar overlay for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-100 flex flex-col shadow-lg lg:shadow-none transition-transform duration-300 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}>
        {/* Logo */}
        <div className="p-6 border-b border-gray-100">
          <NavLink to="/" className="flex items-center gap-2">
            <div className="w-9 h-9 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-display font-bold text-sm text-gray-900">Smart Kids</div>
              <div className="text-xs text-purple-500 font-medium">Academy</div>
            </div>
          </NavLink>
        </div>

        {/* Student Info */}
        <div className="p-4 mx-4 mt-4 rounded-2xl bg-gradient-to-br from-purple-50 to-white border border-purple-100">
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-10 h-10 ${levelColor} rounded-xl flex items-center justify-center text-white font-bold text-lg`}>
              {profile?.full_name?.[0] ?? '?'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-gray-900 text-sm truncate">{profile?.full_name ?? student?.username}</p>
              <p className="text-xs text-purple-500 font-medium">Level {student?.current_level ?? 1}</p>
            </div>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-gray-500">
              <span className="flex items-center gap-1"><Zap className="w-3 h-3 text-yellow-500" />{student?.xp_points ?? 0} XP</span>
              <span className="flex items-center gap-1"><Star className="w-3 h-3 text-orange-400" />{student?.streak_days ?? 0} streak</span>
            </div>
            <div className="xp-bar">
              <div className="xp-fill" style={{ width: `${xpPercent}%` }} />
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          {navItems.map(item => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-glow'
                    : 'text-gray-600 hover:bg-purple-50 hover:text-purple-600'
                }`
              }
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Sign out */}
        <div className="p-4 border-t border-gray-100">
          <button
            onClick={handleSignOut}
            className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-gray-500 hover:bg-red-50 hover:text-red-500 transition-all w-full"
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-100 px-4 md:px-6 py-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl hover:bg-gray-100 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="font-display font-bold text-lg text-gray-900 hidden sm:block">Student Portal</h1>
          </div>
          <div className="flex items-center gap-3">
            <NavLink to="/student/notifications" className="relative p-2 rounded-xl hover:bg-gray-100 transition-colors">
              <Bell className="w-5 h-5 text-gray-600" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-purple-500 rounded-full" />
            </NavLink>
            <div className={`w-8 h-8 ${levelColor} rounded-xl flex items-center justify-center text-white font-bold text-sm`}>
              {profile?.full_name?.[0] ?? '?'}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <Outlet />
        </main>

        {/* Mobile bottom nav */}
        <nav className="lg:hidden bg-white border-t border-gray-100 safe-area-inset-bottom px-2 py-2">
          <div className="flex justify-around">
            {navItems.slice(0, 5).map(item => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl transition-all ${
                    isActive ? 'text-purple-600' : 'text-gray-400'
                  }`
                }
              >
                <item.icon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{item.label.split(' ')[0]}</span>
              </NavLink>
            ))}
          </div>
        </nav>
      </div>
    </div>
  );
}
