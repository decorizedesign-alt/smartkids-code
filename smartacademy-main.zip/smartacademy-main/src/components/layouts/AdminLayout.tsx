import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import {
  LayoutDashboard, Users, GraduationCap, BookOpen, Package,
  CreditCard, Bell, BarChart2, Settings, ShieldCheck, LogOut,
  Menu, X, ChevronDown, User, Cpu,
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

const navGroups = [
  {
    label: 'Overview',
    items: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/admin/dashboard' },
      { icon: BarChart2, label: 'Analytics', path: '/admin/analytics' },
    ],
  },
  {
    label: 'User Management',
    items: [
      { icon: Users, label: 'All Users', path: '/admin/users' },
      { icon: GraduationCap, label: 'Teachers', path: '/admin/teachers' },
      { icon: User, label: 'Students', path: '/admin/students' },
      { icon: Users, label: 'Parents', path: '/admin/parents' },
    ],
  },
  {
    label: 'Content',
    items: [
      { icon: BookOpen, label: 'Courses & Files', path: '/admin/courses' },
      { icon: Cpu, label: 'Robotics Kits', path: '/admin/kits' },
    ],
  },
  {
    label: 'Business',
    items: [
      { icon: CreditCard, label: 'Billing', path: '/admin/billing' },
      { icon: Bell, label: 'Notifications', path: '/admin/notifications' },
    ],
  },
  {
    label: 'System',
    items: [
      { icon: Settings, label: 'Site Settings', path: '/admin/settings' },
    ],
  },
];

export default function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { profile, signOut } = useAuthStore();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/admin/login');
  };

  return (
    <div className="flex h-screen bg-gray-950 overflow-hidden">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-gray-900 border-r border-white/5 flex flex-col transition-transform duration-300 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}>
        {/* Logo */}
        <div className="p-5 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl flex items-center justify-center shadow-glow">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-display font-bold text-sm text-white">Smart Kids</div>
              <div className="text-xs text-purple-400 font-medium">Admin Panel</div>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-gray-500 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Admin info */}
        <div className="p-4 mx-3 mt-3 rounded-2xl bg-purple-500/10 border border-purple-500/20">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-700 rounded-lg flex items-center justify-center text-white font-bold text-sm">
              A
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-semibold text-sm truncate">{profile?.full_name ?? 'Admin'}</p>
              <p className="text-purple-400 text-xs">Super Administrator</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 space-y-5 px-3">
          {navGroups.map(group => (
            <div key={group.label}>
              <p className="text-gray-600 text-xs font-bold uppercase tracking-wider px-3 mb-1.5">{group.label}</p>
              <div className="space-y-0.5">
                {group.items.map(item => (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={() => setSidebarOpen(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                        isActive
                          ? 'bg-purple-600 text-white shadow-glow'
                          : 'text-gray-400 hover:bg-white/5 hover:text-white'
                      }`
                    }
                  >
                    <item.icon className="w-4 h-4 flex-shrink-0" />
                    {item.label}
                  </NavLink>
                ))}
              </div>
            </div>
          ))}
        </nav>

        {/* Sign out */}
        <div className="p-3 border-t border-white/5">
          <button
            onClick={handleSignOut}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-500 hover:bg-red-500/10 hover:text-red-400 transition-all w-full"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="bg-gray-900 border-b border-white/5 px-4 md:px-6 py-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl hover:bg-white/5 transition-colors text-gray-400"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="font-display font-bold text-white hidden sm:block">Administration</span>
          </div>
          <div className="flex items-center gap-3">
            <NavLink to="/admin/notifications" className="p-2 rounded-xl hover:bg-white/5 transition-colors relative">
              <Bell className="w-5 h-5 text-gray-400" />
            </NavLink>
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl flex items-center justify-center text-white font-bold text-sm">
              A
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto bg-gray-950 p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
