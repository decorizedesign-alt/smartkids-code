import { Calendar, Clock, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const posts = [
  { title: 'Top 5 Robotics Projects for Beginners', category: 'Projects', date: 'June 15, 2025', readTime: '5 min read', image: 'https://images.pexels.com/photos/8566472/pexels-photo-8566472.jpeg?auto=compress&cs=tinysrgb&w=400', excerpt: 'Start your robotics journey with these fun and achievable beginner projects that teach core concepts.' },
  { title: 'How Gamification Boosts Kids\' Learning', category: 'Education', date: 'June 10, 2025', readTime: '7 min read', image: 'https://images.pexels.com/photos/8761753/pexels-photo-8761753.jpeg?auto=compress&cs=tinysrgb&w=400', excerpt: 'Research shows that game-like rewards systems dramatically increase engagement and retention in young learners.' },
  { title: 'AI & Machine Learning Explained for Kids', category: 'AI & ML', date: 'June 5, 2025', readTime: '6 min read', image: 'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=400', excerpt: 'Breaking down the complex world of artificial intelligence into concepts that 10-year-olds can understand.' },
  { title: 'Choosing the Right Robotics Kit for Your Child', category: 'Guides', date: 'May 28, 2025', readTime: '8 min read', image: 'https://images.pexels.com/photos/8438919/pexels-photo-8438919.jpeg?auto=compress&cs=tinysrgb&w=400', excerpt: 'A comprehensive parent\'s guide to selecting the best physical robotics kit for your child\'s age and skill level.' },
];

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 py-16 text-center">
        <h1 className="font-display text-4xl font-extrabold text-white mb-4">Smart Kids Blog</h1>
        <p className="text-purple-200 text-lg">Tips, guides, and resources for parents and young learners</p>
      </div>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {posts.map(post => (
            <div key={post.title} className="card-hover overflow-hidden group">
              <img src={post.image} alt={post.title} className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-300" />
              <div className="p-6">
                <span className="badge bg-purple-100 text-purple-600 mb-3 inline-block">{post.category}</span>
                <h3 className="font-display font-bold text-xl text-gray-900 mb-2">{post.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed mb-4">{post.excerpt}</p>
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{post.date}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{post.readTime}</span>
                  </div>
                  <button className="text-purple-600 font-medium hover:text-purple-700 flex items-center gap-1">
                    Read more <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
