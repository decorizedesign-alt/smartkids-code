import { Link } from 'react-router-dom';
import { Bot, Star, Zap, Trophy, Play, ChevronRight, Shield, Cpu, Rocket, Users, BookOpen, Award } from 'lucide-react';

const features = [
  { icon: Cpu, title: 'Robotics & Coding', desc: 'Build real robots and learn to code through hands-on projects', color: 'bg-purple-100 text-purple-600' },
  { icon: Play, title: 'Video Lessons', desc: 'HD video tutorials designed specifically for young learners', color: 'bg-blue-100 text-blue-600' },
  { icon: Zap, title: 'Live Classes', desc: 'Interactive live sessions with expert robotics teachers', color: 'bg-yellow-100 text-yellow-600' },
  { icon: Trophy, title: 'Gamification', desc: 'Earn XP, badges, and level up as you learn and build', color: 'bg-orange-100 text-orange-600' },
  { icon: Shield, title: 'COPPA Safe', desc: 'Parent-controlled accounts with full privacy protection', color: 'bg-green-100 text-green-600' },
  { icon: Rocket, title: 'Physical Kits', desc: 'Real robotics kits delivered to your door to build with', color: 'bg-pink-100 text-pink-600' },
];

const courses = [
  {
    title: 'Intro to Robotics', level: 'Level 1', students: 1240, rating: 4.9,
    image: 'https://images.pexels.com/photos/8566472/pexels-photo-8566472.jpeg?auto=compress&cs=tinysrgb&w=400',
    badge: 'Most Popular', badgeColor: 'bg-yellow-400 text-gray-900',
  },
  {
    title: 'Sensors & Motors', level: 'Level 2', students: 890, rating: 4.8,
    image: 'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=400',
    badge: 'New', badgeColor: 'bg-green-400 text-white',
  },
  {
    title: 'AI for Kids', level: 'Level 4', students: 620, rating: 4.9,
    image: 'https://images.pexels.com/photos/8761753/pexels-photo-8761753.jpeg?auto=compress&cs=tinysrgb&w=400',
    badge: 'Advanced', badgeColor: 'bg-purple-500 text-white',
  },
];

const stats = [
  { value: '50K+', label: 'Young Learners', icon: Users },
  { value: '120+', label: 'Expert Courses', icon: BookOpen },
  { value: '98%', label: 'Parent Satisfaction', icon: Star },
  { value: '25+', label: 'Awards Won', icon: Award },
];

const testimonials = [
  { name: 'Sarah M.', role: 'Parent of 2', text: 'My daughter went from zero coding knowledge to building her own robot in just 3 months. The progress has been incredible!', avatar: 'S', color: 'bg-pink-400' },
  { name: 'James T.', role: 'Parent', text: 'The live classes are fantastic. Teachers are patient and engaging. My son never misses a session!', avatar: 'J', color: 'bg-blue-400' },
  { name: 'Priya K.', role: 'Parent of 3', text: 'Best investment we made for our kids. The gamification keeps them motivated and they actually beg to do lessons!', avatar: 'P', color: 'bg-green-400' },
];

const levels = [
  { level: 1, name: 'Circuit Explorer', color: 'from-green-400 to-green-500', desc: 'Basic electronics & circuits' },
  { level: 2, name: 'Sensor Builder', color: 'from-blue-400 to-blue-500', desc: 'Sensors, motors & control' },
  { level: 3, name: 'Robo Inventor', color: 'from-purple-400 to-purple-500', desc: 'Full robot construction' },
  { level: 4, name: 'AI Engineer', color: 'from-orange-400 to-orange-500', desc: 'AI & machine learning basics' },
  { level: 5, name: 'Robotics Master', color: 'from-yellow-400 to-yellow-500', desc: 'Advanced robotics systems' },
];

export default function HomePage() {
  return (
    <div className="overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center bg-gradient-to-br from-white via-purple-50/40 to-yellow-50/30 overflow-hidden pt-8">
        {/* Background decorations */}
        <div className="absolute inset-0 bg-cyber-grid opacity-40" />
        <div className="absolute top-20 right-10 w-72 h-72 bg-purple-300/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-yellow-300/20 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 px-4 py-2 rounded-full text-sm font-semibold mb-6 animate-fade-in">
                <Zap className="w-4 h-4 text-yellow-500" />
                #1 Robotics Platform for Kids
              </div>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-gray-900 leading-tight mb-6">
                Where Kids{' '}
                <span className="gradient-text">Build</span>{' '}
                the Future
              </h1>
              <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                Interactive robotics courses, live teacher-led classes, real robot kits, and a gamified learning adventure for children ages 6-14.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link to="/register" className="btn-primary text-lg py-4 px-8 flex items-center justify-center gap-2">
                  Start Free Trial
                  <ChevronRight className="w-5 h-5" />
                </Link>
                <Link to="/courses" className="btn-secondary text-lg py-4 px-8 flex items-center justify-center gap-2">
                  <Play className="w-5 h-5" />
                  Watch Demo
                </Link>
              </div>
              <div className="flex items-center justify-center lg:justify-start gap-6 mt-8">
                <div className="flex -space-x-2">
                  {['bg-purple-400', 'bg-blue-400', 'bg-green-400', 'bg-yellow-400'].map((c, i) => (
                    <div key={i} className={`w-8 h-8 ${c} rounded-full border-2 border-white flex items-center justify-center text-white text-xs font-bold`}>
                      {['A', 'B', 'C', 'D'][i]}
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    {[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />)}
                  </div>
                  <p className="text-sm text-gray-500 mt-0.5">50,000+ happy families</p>
                </div>
              </div>
            </div>

            {/* Hero Illustration */}
            <div className="relative flex justify-center lg:justify-end">
              <div className="relative w-full max-w-lg">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-400 to-purple-600 rounded-4xl blur-2xl opacity-20 scale-105" />
                <div className="relative bg-white rounded-4xl shadow-2xl overflow-hidden border border-purple-100 p-6">
                  <img
                    src="https://images.pexels.com/photos/8566472/pexels-photo-8566472.jpeg?auto=compress&cs=tinysrgb&w=600"
                    alt="Kids building robots"
                    className="w-full h-64 object-cover rounded-2xl mb-4"
                  />
                  {/* Mock dashboard card */}
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="font-display font-bold text-gray-900">Alex's Progress</p>
                      <p className="text-sm text-purple-500">Robo Inventor • Level 3</p>
                    </div>
                    <div className="bg-yellow-100 px-3 py-1 rounded-full">
                      <span className="text-yellow-700 font-bold text-sm">⚡ 1,850 XP</span>
                    </div>
                  </div>
                  <div className="progress-bar mb-2">
                    <div className="progress-fill" style={{ width: '72%' }} />
                  </div>
                  <p className="text-xs text-gray-500 mb-3">72% to Level 4</p>
                  <div className="flex gap-2">
                    {['🏆', '⭐', '🚀', '🤖', '💡'].map((emoji, i) => (
                      <div key={i} className="w-9 h-9 bg-purple-50 rounded-xl flex items-center justify-center text-lg">
                        {emoji}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Floating badges */}
                <div className="absolute -top-4 -right-4 bg-yellow-400 text-gray-900 rounded-2xl px-4 py-2 font-bold text-sm shadow-lg animate-bounce-slow">
                  🔥 7 Day Streak!
                </div>
                <div className="absolute -bottom-4 -left-4 bg-purple-600 text-white rounded-2xl px-4 py-2 font-bold text-sm shadow-lg animate-float">
                  🤖 New Badge Earned!
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-white py-16 border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map(stat => (
              <div key={stat.label} className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-2xl mb-3">
                  <stat.icon className="w-6 h-6 text-purple-600" />
                </div>
                <div className="font-display text-3xl font-extrabold text-gray-900">{stat.value}</div>
                <div className="text-gray-500 text-sm mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-gradient-to-b from-white to-purple-50/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="section-title mb-4">Everything Kids Need to <span className="gradient-text">Become Inventors</span></h2>
            <p className="text-gray-500 text-lg max-w-2xl mx-auto">A complete learning ecosystem designed for young minds, with safety and engagement at the core.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map(feature => (
              <div key={feature.title} className="card-hover p-6">
                <div className={`w-12 h-12 ${feature.color} rounded-2xl flex items-center justify-center mb-4`}>
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="font-display font-bold text-lg text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-500 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Courses Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="section-title mb-2">Featured <span className="gradient-text">Courses</span></h2>
              <p className="text-gray-500">Expertly designed for every skill level</p>
            </div>
            <Link to="/courses" className="btn-secondary text-sm hidden sm:flex items-center gap-2">
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {courses.map(course => (
              <div key={course.title} className="card-hover overflow-hidden group">
                <div className="relative overflow-hidden">
                  <img
                    src={course.image}
                    alt={course.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <span className={`absolute top-3 left-3 badge ${course.badgeColor}`}>{course.badge}</span>
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="badge bg-purple-100 text-purple-600">{course.level}</span>
                  </div>
                  <h3 className="font-display font-bold text-lg text-gray-900 mb-3">{course.title}</h3>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      <span className="font-semibold text-gray-700">{course.rating}</span>
                    </div>
                    <span className="text-gray-500">{course.students.toLocaleString()} students</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-8 sm:hidden">
            <Link to="/courses" className="btn-secondary inline-flex items-center gap-2">
              View All Courses <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Level System */}
      <section className="py-20 bg-gray-900 text-white overflow-hidden relative">
        <div className="absolute inset-0 bg-cyber-grid opacity-10" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-3xl md:text-4xl font-extrabold mb-4">
              Level Up Your <span className="text-yellow-400">Robot Skills</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">Progress through 5 expertly crafted levels, earning XP and badges along the way.</p>
          </div>
          <div className="flex flex-col md:flex-row gap-4 items-center justify-center">
            {levels.map((level, i) => (
              <div key={level.level} className="relative flex-1 max-w-xs w-full">
                {i < levels.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-2 z-10 text-gray-500">
                    <ChevronRight className="w-4 h-4" />
                  </div>
                )}
                <div className="bg-gray-800 border border-gray-700 rounded-3xl p-5 text-center hover:border-purple-500 transition-colors">
                  <div className={`w-12 h-12 bg-gradient-to-br ${level.color} rounded-2xl flex items-center justify-center text-white font-extrabold text-xl mx-auto mb-3`}>
                    {level.level}
                  </div>
                  <p className="font-display font-bold text-white mb-1">{level.name}</p>
                  <p className="text-gray-400 text-xs">{level.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gradient-to-b from-purple-50/30 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="section-title mb-4">Loved by <span className="gradient-text">50,000+ Families</span></h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map(t => (
              <div key={t.name} className="card p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[1,2,3,4,5].map(i => <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />)}
                </div>
                <p className="text-gray-600 leading-relaxed mb-6 italic">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 ${t.color} rounded-full flex items-center justify-center text-white font-bold`}>
                    {t.avatar}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{t.name}</p>
                    <p className="text-sm text-gray-400">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-purple-800 relative overflow-hidden">
        <div className="absolute inset-0 bg-cyber-grid opacity-10" />
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="text-6xl mb-6 animate-float inline-block">🤖</div>
          <h2 className="font-display text-3xl md:text-5xl font-extrabold text-white mb-6">
            Ready to Build the Future?
          </h2>
          <p className="text-purple-200 text-lg mb-10 max-w-xl mx-auto">
            Join thousands of young inventors already learning on Smart Kids Academy. First 14 days free, no credit card required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register" className="btn-yellow text-lg py-4 px-10 flex items-center justify-center gap-2">
              Start Free Trial
              <Rocket className="w-5 h-5" />
            </Link>
            <Link to="/pricing" className="border-2 border-white/30 text-white font-semibold rounded-2xl py-4 px-10 hover:bg-white/10 transition-all flex items-center justify-center gap-2">
              See Pricing
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
