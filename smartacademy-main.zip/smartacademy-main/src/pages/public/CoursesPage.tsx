import { useState } from 'react';
import { Search, Filter, Star, Users, Clock, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const categories = ['All', 'Beginner', 'Intermediate', 'Advanced', 'AI & ML', 'Electronics', 'Programming'];

const allCourses = [
  { id: 1, title: 'Introduction to Robotics', category: 'Beginner', level: 1, students: 1240, rating: 4.9, duration: '8h 30m', price: 49, image: 'https://images.pexels.com/photos/8566472/pexels-photo-8566472.jpeg?auto=compress&cs=tinysrgb&w=400', instructor: 'Mr. Johnson', badge: 'Popular' },
  { id: 2, title: 'Sensors & Motor Control', category: 'Intermediate', level: 2, students: 890, rating: 4.8, duration: '10h 15m', price: 59, image: 'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=400', instructor: 'Ms. Chen', badge: 'New' },
  { id: 3, title: 'AI for Kids: Machine Learning Basics', category: 'AI & ML', level: 4, students: 620, rating: 4.9, duration: '12h', price: 79, image: 'https://images.pexels.com/photos/8761753/pexels-photo-8761753.jpeg?auto=compress&cs=tinysrgb&w=400', instructor: 'Dr. Patel', badge: 'Advanced' },
  { id: 4, title: 'Build Your First Robot', category: 'Beginner', level: 1, students: 2100, rating: 4.7, duration: '6h', price: 39, image: 'https://images.pexels.com/photos/8438919/pexels-photo-8438919.jpeg?auto=compress&cs=tinysrgb&w=400', instructor: 'Mr. Kim', badge: '' },
  { id: 5, title: 'Coding with Scratch', category: 'Programming', level: 1, students: 1580, rating: 4.8, duration: '7h 45m', price: 45, image: 'https://images.pexels.com/photos/8566456/pexels-photo-8566456.jpeg?auto=compress&cs=tinysrgb&w=400', instructor: 'Ms. Lopez', badge: '' },
  { id: 6, title: 'Arduino for Beginners', category: 'Electronics', level: 2, students: 760, rating: 4.6, duration: '9h', price: 55, image: 'https://images.pexels.com/photos/8566474/pexels-photo-8566474.jpeg?auto=compress&cs=tinysrgb&w=400', instructor: 'Mr. Smith', badge: '' },
];

export default function CoursesPage() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [search, setSearch] = useState('');

  const filtered = allCourses.filter(c => {
    const matchCat = activeCategory === 'All' || c.category === activeCategory;
    const matchSearch = c.title.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-display text-4xl font-extrabold text-white mb-4">Robotics Courses</h1>
          <p className="text-purple-200 text-lg mb-8">Expert-designed courses for every skill level, ages 6-14</p>
          <div className="max-w-xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search courses..."
              className="w-full pl-12 pr-4 py-4 rounded-2xl text-gray-900 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Categories */}
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2 mb-8">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`flex-shrink-0 px-5 py-2 rounded-2xl font-medium text-sm transition-all ${
                activeCategory === cat
                  ? 'bg-purple-600 text-white shadow-glow'
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-purple-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Course Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(course => (
            <div key={course.id} className="card-hover overflow-hidden group">
              <div className="relative overflow-hidden">
                <img src={course.image} alt={course.title} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
                {course.badge && (
                  <span className={`absolute top-3 left-3 badge ${
                    course.badge === 'Popular' ? 'bg-yellow-400 text-gray-900' :
                    course.badge === 'New' ? 'bg-green-400 text-white' :
                    'bg-purple-500 text-white'
                  }`}>{course.badge}</span>
                )}
              </div>
              <div className="p-5">
                <div className="flex items-center gap-2 mb-2">
                  <span className="badge bg-purple-100 text-purple-600">Level {course.level}</span>
                  <span className="badge bg-gray-100 text-gray-600">{course.category}</span>
                </div>
                <h3 className="font-display font-bold text-lg text-gray-900 mb-1">{course.title}</h3>
                <p className="text-sm text-gray-500 mb-3">by {course.instructor}</p>
                <div className="flex items-center justify-between text-sm mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    <span className="font-semibold">{course.rating}</span>
                    <span className="text-gray-400">({course.students.toLocaleString()})</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-400">
                    <Clock className="w-4 h-4" />
                    {course.duration}
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-display font-bold text-xl text-gray-900">${course.price}</span>
                  <Link to="/register" className="btn-primary text-sm py-2 px-4">
                    Enroll Now
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">🔍</div>
            <p className="text-gray-500 text-lg">No courses found. Try a different search.</p>
          </div>
        )}
      </div>
    </div>
  );
}
