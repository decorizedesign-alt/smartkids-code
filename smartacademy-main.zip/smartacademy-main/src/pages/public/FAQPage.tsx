import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqs = [
  { q: 'What age is Smart Kids Academy for?', a: 'Smart Kids Academy is designed for children ages 6-14. Our courses are structured to match different developmental stages and skill levels.' },
  { q: 'Is parental consent required?', a: 'Yes! We are fully COPPA compliant. A parent or guardian must create an account first and provide consent before a child can access the platform.' },
  { q: 'What equipment do my kids need?', a: 'Just a tablet, computer, or smartphone with a stable internet connection. For physical kit courses, we ship all necessary robotics components directly to your door.' },
  { q: 'How do the live classes work?', a: 'Live classes are hosted via Zoom or Google Meet. Students join at a scheduled time with their teacher and classmates for interactive sessions lasting 45-60 minutes.' },
  { q: 'Can I cancel my subscription anytime?', a: 'Absolutely! You can cancel anytime from your Parent Dashboard. You\'ll retain access until the end of your current billing period.' },
  { q: 'Is my child\'s data safe?', a: 'We take privacy very seriously. We collect minimal data, encrypt all information, and never share personal data with third parties. Parents can view and delete all child data at any time.' },
  { q: 'What happens if my child misses a live class?', a: 'All live sessions are recorded and available for 30 days after the event. Your child can watch the recording at their own pace.' },
  { q: 'Are there any certificates?', a: 'Yes! Students receive digital certificates upon completing each course. These can be printed or shared digitally.' },
];

export default function FAQPage() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 py-16 text-center">
        <h1 className="font-display text-4xl font-extrabold text-white mb-4">Frequently Asked Questions</h1>
        <p className="text-purple-200 text-lg">Everything you need to know about Smart Kids Academy</p>
      </div>
      <div className="max-w-3xl mx-auto px-4 py-16">
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div key={i} className="card overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left"
              >
                <span className="font-semibold text-gray-900 pr-4">{faq.q}</span>
                {open === i ? <ChevronUp className="w-5 h-5 text-purple-500 flex-shrink-0" /> : <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />}
              </button>
              {open === i && (
                <div className="px-6 pb-6 text-gray-600 leading-relaxed border-t border-gray-50 pt-4 animate-fade-in">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
