import { Bot, Target, Heart, Globe } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <div className="bg-gradient-to-br from-purple-600 to-purple-900 py-24 text-center">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-6xl mb-6 animate-float inline-block">🤖</div>
          <h1 className="font-display text-4xl md:text-5xl font-extrabold text-white mb-6">About Smart Kids Academy</h1>
          <p className="text-purple-200 text-xl leading-relaxed max-w-2xl mx-auto">
            We believe every child is a future inventor. Our mission is to make robotics and programming accessible, fun, and safe for kids everywhere.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-20">
          <div>
            <h2 className="section-title mb-6">Our <span className="gradient-text">Mission</span></h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              Smart Kids Academy was founded in 2021 by a team of educators and engineers who believed that the next generation of innovators needed a safe, engaging place to learn robotics and programming.
            </p>
            <p className="text-gray-600 leading-relaxed">
              We combine proven pedagogy with modern gamification to create learning experiences that kids actually love. Every lesson is designed with child development experts and reviewed by parents.
            </p>
          </div>
          <img
            src="https://images.pexels.com/photos/8761753/pexels-photo-8761753.jpeg?auto=compress&cs=tinysrgb&w=600"
            alt="Kids learning robotics"
            className="w-full h-80 object-cover rounded-3xl"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {[
            { icon: Target, title: 'Our Mission', desc: 'Make robotics learning accessible to every child', color: 'bg-purple-100 text-purple-600' },
            { icon: Heart, title: 'Our Values', desc: 'Safety, fun, and learning go hand in hand', color: 'bg-pink-100 text-pink-600' },
            { icon: Globe, title: 'Our Reach', desc: '50,000+ students across 40+ countries', color: 'bg-blue-100 text-blue-600' },
            { icon: Bot, title: 'Our Team', desc: '100+ educators, engineers, and child specialists', color: 'bg-green-100 text-green-600' },
          ].map(item => (
            <div key={item.title} className="card p-6 text-center">
              <div className={`w-14 h-14 ${item.color} rounded-3xl flex items-center justify-center mx-auto mb-4`}>
                <item.icon className="w-7 h-7" />
              </div>
              <h3 className="font-display font-bold text-gray-900 mb-2">{item.title}</h3>
              <p className="text-gray-500 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
