import { Check, Star, Zap, Rocket } from 'lucide-react';
import { Link } from 'react-router-dom';

const plans = [
  {
    name: 'Explorer',
    price: { monthly: 19, annual: 15 },
    description: 'Perfect for getting started',
    color: 'border-gray-200',
    highlight: false,
    features: [
      'Access to 20+ beginner courses',
      '2 live classes per month',
      'Progress tracking',
      'Digital badges',
      'Parent dashboard',
      'Email support',
    ],
  },
  {
    name: 'Inventor',
    price: { monthly: 39, annual: 32 },
    description: 'Most popular for active learners',
    color: 'border-purple-500',
    highlight: true,
    features: [
      'Access to ALL 120+ courses',
      'Unlimited live classes',
      'Physical robotics kit included',
      'AI assistant helper',
      'Advanced analytics',
      'Certificate program',
      'Priority support',
      '1 physical kit/year',
    ],
  },
  {
    name: 'Master',
    price: { monthly: 69, annual: 57 },
    description: 'For serious young engineers',
    color: 'border-yellow-400',
    highlight: false,
    features: [
      'Everything in Inventor',
      '2 physical kits/year',
      'Monthly 1-on-1 mentoring',
      'Competition preparation',
      'Advanced project reviews',
      'Priority kit shipping',
      'Dedicated account manager',
      'Offline lesson download',
    ],
  },
];

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-purple-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="section-title mb-4">Simple, <span className="gradient-text">Transparent</span> Pricing</h1>
          <p className="text-gray-500 text-lg max-w-2xl mx-auto">
            Start with a 14-day free trial. No credit card required. Cancel anytime.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map(plan => (
            <div
              key={plan.name}
              className={`card p-8 border-2 ${plan.color} relative ${plan.highlight ? 'scale-105 shadow-glow' : ''}`}
            >
              {plan.highlight && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-sm font-semibold px-6 py-1.5 rounded-full flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-white" /> Most Popular
                </div>
              )}
              <h3 className="font-display font-bold text-2xl text-gray-900 mb-1">{plan.name}</h3>
              <p className="text-gray-500 text-sm mb-6">{plan.description}</p>
              <div className="mb-8">
                <span className="font-display text-5xl font-extrabold text-gray-900">${plan.price.monthly}</span>
                <span className="text-gray-400">/month</span>
                <p className="text-sm text-green-600 font-medium mt-1">
                  Save ${(plan.price.monthly - plan.price.annual) * 12}/yr with annual
                </p>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map(f => (
                  <li key={f} className="flex items-start gap-2 text-sm text-gray-600">
                    <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                to="/register"
                className={plan.highlight ? 'btn-primary w-full text-center block' : 'btn-secondary w-full text-center block'}
              >
                Start Free Trial
              </Link>
            </div>
          ))}
        </div>

        <div className="mt-20 max-w-3xl mx-auto">
          <h2 className="section-title text-center mb-12">All Plans Include</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: '🔒', title: 'COPPA Safe', desc: 'Full parent control' },
              { icon: '📱', title: 'Mobile App', desc: 'Learn anywhere' },
              { icon: '🌍', title: 'Multi-Language', desc: '10+ languages' },
              { icon: '🎮', title: 'Gamification', desc: 'XP & rewards' },
            ].map(item => (
              <div key={item.title} className="text-center">
                <div className="text-4xl mb-2">{item.icon}</div>
                <p className="font-semibold text-gray-900">{item.title}</p>
                <p className="text-sm text-gray-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
