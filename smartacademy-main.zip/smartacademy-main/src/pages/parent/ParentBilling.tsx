import { useState } from 'react';
import { CreditCard, Check, Download, Calendar } from 'lucide-react';

const plans = [
  { name: 'Explorer', price: 19, features: ['20+ courses', '2 live classes/month', 'Progress tracking'] },
  { name: 'Inventor', price: 39, features: ['All 120+ courses', 'Unlimited live classes', '1 Robot kit/year', 'AI assistant'], highlight: true },
  { name: 'Master', price: 69, features: ['Everything in Inventor', '2 kits/year', 'Monthly mentoring'] },
];

const invoices = [
  { id: 'INV-001', date: 'Jun 1, 2025', amount: 39, status: 'paid', plan: 'Inventor' },
  { id: 'INV-002', date: 'May 1, 2025', amount: 39, status: 'paid', plan: 'Inventor' },
  { id: 'INV-003', date: 'Apr 1, 2025', amount: 39, status: 'paid', plan: 'Inventor' },
];

export default function ParentBilling() {
  const [currentPlan, setCurrentPlan] = useState('Inventor');

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Billing & Subscription</h1>
        <p className="text-gray-500">Manage your subscription and payment history</p>
      </div>

      {/* Current Plan */}
      <div className="card p-6 border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-2xl flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="font-display font-bold text-gray-900">Current Plan: <span className="text-purple-600">Inventor</span></p>
              <p className="text-sm text-gray-500">Next billing: July 1, 2025</p>
            </div>
          </div>
          <span className="badge bg-green-100 text-green-700"><span className="w-1.5 h-1.5 bg-green-500 rounded-full inline-block mr-1" />Active</span>
        </div>
        <div className="flex gap-3 mt-4">
          <button className="btn-secondary text-sm py-2">Change Plan</button>
          <button className="text-sm text-red-500 font-medium hover:text-red-700 px-4 py-2">Cancel Subscription</button>
        </div>
      </div>

      {/* Plan Comparison */}
      <div>
        <h2 className="font-display font-bold text-lg text-gray-900 mb-4">Available Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {plans.map(plan => (
            <div key={plan.name} className={`card p-5 border-2 ${currentPlan === plan.name ? 'border-purple-500' : 'border-transparent'} ${plan.highlight ? 'bg-gradient-to-br from-purple-50 to-white' : ''}`}>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-display font-bold text-gray-900">{plan.name}</h3>
                {currentPlan === plan.name && <span className="badge bg-purple-100 text-purple-600 text-xs">Current</span>}
              </div>
              <div className="mb-4">
                <span className="font-display text-3xl font-extrabold text-gray-900">${plan.price}</span>
                <span className="text-gray-400 text-sm">/mo</span>
              </div>
              <ul className="space-y-2 mb-4">
                {plan.features.map(f => (
                  <li key={f} className="flex items-center gap-2 text-sm text-gray-600">
                    <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => setCurrentPlan(plan.name)}
                className={`w-full py-2.5 rounded-2xl text-sm font-semibold transition-all ${
                  currentPlan === plan.name ? 'bg-gray-100 text-gray-400 cursor-default' : 'btn-primary'
                }`}
                disabled={currentPlan === plan.name}
              >
                {currentPlan === plan.name ? 'Current Plan' : 'Switch Plan'}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Invoice History */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-lg text-gray-900 mb-4">Payment History</h2>
        <div className="space-y-3">
          {invoices.map(inv => (
            <div key={inv.id} className="flex items-center justify-between py-3 border-b border-gray-50 last:border-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-gray-100 rounded-xl flex items-center justify-center">
                  <Calendar className="w-4 h-4 text-gray-500" />
                </div>
                <div>
                  <p className="font-medium text-gray-900 text-sm">{inv.plan} Plan</p>
                  <p className="text-xs text-gray-400">{inv.date} · {inv.id}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="font-semibold text-gray-900">${inv.amount}</p>
                  <span className="badge bg-green-100 text-green-700 text-xs">Paid</span>
                </div>
                <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                  <Download className="w-4 h-4 text-gray-500" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
