import { TrendingUp, Award, Flame, BookOpen, CheckCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const weeklyActivity = [
  { day: 'Mon', minutes: 30 }, { day: 'Tue', minutes: 45 }, { day: 'Wed', minutes: 20 },
  { day: 'Thu', minutes: 60 }, { day: 'Fri', minutes: 50 }, { day: 'Sat', minutes: 25 }, { day: 'Sun', minutes: 0 },
];

const xpGrowth = [
  { month: 'Jan', xp: 200 }, { month: 'Feb', xp: 500 }, { month: 'Mar', xp: 950 },
  { month: 'Apr', xp: 1200 }, { month: 'May', xp: 1600 }, { month: 'Jun', xp: 1850 },
];

const courseProgress = [
  { course: 'Intro to Robotics', progress: 72, lessons: 18, total: 25 },
  { course: 'Sensors & Control', progress: 40, lessons: 8, total: 20 },
];

export default function ParentChildProgress() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Child Progress</h1>
        <p className="text-gray-500">Detailed overview of Alex's learning journey</p>
      </div>

      {/* Child Overview */}
      <div className="bg-gradient-to-br from-green-50 to-white card p-6 border-2 border-green-100">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 bg-purple-400 rounded-2xl flex items-center justify-center text-white font-bold text-2xl">🤖</div>
          <div>
            <p className="font-display font-bold text-xl text-gray-900">Alex Johnson</p>
            <p className="text-sm text-gray-500">@alex_robo · Robo Inventor Level 3</p>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { icon: TrendingUp, label: 'XP Points', value: '1,850', color: 'text-purple-600 bg-purple-50' },
            { icon: Flame, label: 'Day Streak', value: '7', color: 'text-orange-500 bg-orange-50' },
            { icon: BookOpen, label: 'Lessons Done', value: '26', color: 'text-blue-600 bg-blue-50' },
            { icon: Award, label: 'Badges', value: '8', color: 'text-yellow-600 bg-yellow-50' },
          ].map(stat => (
            <div key={stat.label} className={`flex items-center gap-2 p-3 rounded-2xl ${stat.color.split(' ')[1]}`}>
              <stat.icon className={`w-5 h-5 flex-shrink-0 ${stat.color.split(' ')[0]}`} />
              <div>
                <p className="font-bold text-gray-900">{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Activity */}
        <div className="card p-6">
          <h2 className="font-display font-bold text-lg text-gray-900 mb-4">This Week's Activity</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={weeklyActivity}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9CA3AF' }} />
              <YAxis hide />
              <Tooltip formatter={v => [`${v} min`, 'Study Time']} contentStyle={{ borderRadius: '12px', border: 'none' }} />
              <Bar dataKey="minutes" fill="#16a34a" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* XP Growth */}
        <div className="card p-6">
          <h2 className="font-display font-bold text-lg text-gray-900 mb-4">XP Growth Over Time</h2>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={xpGrowth}>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9CA3AF' }} />
              <YAxis hide />
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none' }} />
              <Line type="monotone" dataKey="xp" name="XP" stroke="#8B5CF6" strokeWidth={3} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Course Progress */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-lg text-gray-900 mb-4">Course Progress</h2>
        <div className="space-y-4">
          {courseProgress.map(c => (
            <div key={c.course} className="flex flex-col sm:flex-row sm:items-center gap-3">
              <div className="flex-1">
                <div className="flex justify-between mb-1.5">
                  <p className="font-medium text-gray-900">{c.course}</p>
                  <span className="text-sm text-gray-500">{c.lessons}/{c.total} lessons</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${c.progress}%` }} />
                </div>
              </div>
              <span className={`badge flex-shrink-0 ${c.progress > 60 ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                {c.progress}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
