import { MapPin, Truck, Package, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const shipments = [
  {
    id: 'SHIP-001',
    kit: 'Inventor Robotics Kit v2',
    tracking: 'UPS-1Z999AA10123456784',
    carrier: 'UPS',
    status: 'delivered',
    address: '123 Main St, San Francisco, CA 94102',
    shipped: 'May 25, 2025',
    delivered: 'May 28, 2025',
    steps: [
      { label: 'Order Placed', done: true, date: 'May 22' },
      { label: 'Processing', done: true, date: 'May 23' },
      { label: 'Shipped', done: true, date: 'May 25' },
      { label: 'In Transit', done: true, date: 'May 26' },
      { label: 'Delivered', done: true, date: 'May 28' },
    ],
  },
  {
    id: 'SHIP-002',
    kit: 'Sensor Expansion Pack',
    tracking: 'FEDEX-1234567890',
    carrier: 'FedEx',
    status: 'in_transit',
    address: '123 Main St, San Francisco, CA 94102',
    shipped: 'Jun 10, 2025',
    delivered: null,
    steps: [
      { label: 'Order Placed', done: true, date: 'Jun 8' },
      { label: 'Processing', done: true, date: 'Jun 9' },
      { label: 'Shipped', done: true, date: 'Jun 10' },
      { label: 'In Transit', done: true, date: 'Jun 11' },
      { label: 'Delivered', done: false, date: 'Est. Jun 14' },
    ],
  },
];

const statusColor: Record<string, string> = {
  delivered: 'bg-green-100 text-green-700',
  in_transit: 'bg-blue-100 text-blue-700',
  processing: 'bg-yellow-100 text-yellow-700',
};

export default function ParentShipping() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Shipping Tracker</h1>
        <p className="text-gray-500">Track your robotics kit deliveries</p>
      </div>

      <div className="space-y-6">
        {shipments.map(shipment => (
          <div key={shipment.id} className="card p-6">
            <div className="flex items-start justify-between mb-5 flex-wrap gap-3">
              <div>
                <h3 className="font-display font-bold text-gray-900 mb-1">{shipment.kit}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-500 flex-wrap">
                  <span className="flex items-center gap-1"><Truck className="w-3.5 h-3.5" /> {shipment.carrier}</span>
                  <span>·</span>
                  <span className="font-mono text-xs">{shipment.tracking}</span>
                </div>
              </div>
              <span className={`badge ${statusColor[shipment.status]}`}>
                {shipment.status === 'delivered' ? '✓ Delivered' : shipment.status === 'in_transit' ? '🚛 In Transit' : '⏳ Processing'}
              </span>
            </div>

            {/* Tracking Steps */}
            <div className="flex items-center justify-between mb-5 overflow-x-auto pb-2">
              {shipment.steps.map((step, i) => (
                <div key={step.label} className="flex flex-col items-center flex-1 min-w-0 relative">
                  {i < shipment.steps.length - 1 && (
                    <div className={`absolute top-4 left-1/2 w-full h-0.5 ${step.done && shipment.steps[i + 1].done ? 'bg-green-400' : 'bg-gray-200'}`} />
                  )}
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${step.done ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-400'}`}>
                    {step.done ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                  </div>
                  <p className="text-xs text-gray-600 mt-2 text-center font-medium leading-tight px-1">{step.label}</p>
                  <p className="text-xs text-gray-400 text-center">{step.date}</p>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm text-gray-500 bg-gray-50 rounded-2xl p-3">
              <MapPin className="w-4 h-4 flex-shrink-0 text-gray-400" />
              {shipment.address}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
