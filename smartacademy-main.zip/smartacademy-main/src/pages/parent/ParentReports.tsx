import { FileText, Download, TrendingUp, BookOpen, Award, Flame } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const monthlyReport = [
  { month: 'Jan', lessons: 8, xp: 200 },
  { month: 'Feb', lessons: 12, xp: 380 },
  { month: 'Mar', lessons: 15, xp: 450 },
  { month: 'Apr', lessons: 10, xp: 320 },
  { month: 'May', lessons: 18, xp: 540 },
  { month: 'Jun', lessons: 14, xp: 420 },
];

export default function ParentReports() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Progress Reports</h1>
          <p className="text-gray-500">Detailed learning reports for Alex</p>
        </div>
        <button className="btn-secondary text-sm flex items-center gap-2">
          <Download className="w-4 h-4" /> Export PDF
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { icon: BookOpen, label: 'Total Lessons', value: '95', color: 'bg-blue-50 text-blue-600', iconBg: 'bg-blue-100' },
          { icon: TrendingUp, label: 'Total XP', value: '1,850', color: 'bg-purple-50 text-purple-600', iconBg: 'bg-purple-100' },
          { icon: Award, label: 'Certificates', value: '2', color: 'bg-yellow-50 text-yellow-600', iconBg: 'bg-yellow-100' },
          { icon: Flame, label: 'Longest Streak', value: '14 days', color: 'bg-orange-50 text-orange-500', iconBg: 'bg-orange-100' },
        ].map(stat => (
          <div key={stat.label} className={`card p-4 ${stat.color}`}>
            <div className={`w-9 h-9 ${stat.iconBg} rounded-xl flex items-center justify-center mb-2`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div className="font-display font-bold text-xl text-gray-900">{stat.value}</div>
            <div className="text-xs text-gray-500 mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Monthly Activity Chart */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-lg text-gray-900 mb-4">Monthly Activity</h2>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={monthlyReport}>
            <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9CA3AF' }} />
            <YAxis hide />
            <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
            <Bar dataKey="lessons" name="Lessons" fill="#16a34a" radius={[6, 6, 0, 0]} />
            <Bar dataKey="xp" name="XP × 0.1" fill="#8B5CF6" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Weekly Reports */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-lg text-gray-900 mb-4">Weekly Reports</h2>
        <div className="space-y-3">
          {[
            { week: 'Week of Jun 9 – Jun 15', lessons: 5, xp: 180, streak: 7, highlight: 'Completed "Traffic Light" project!' },
            { week: 'Week of Jun 2 – Jun 8', lessons: 4, xp: 140, streak: 5, highlight: 'Earned 7-Day Streak badge' },
            { week: 'Week of May 26 – Jun 1', lessons: 6, xp: 210, streak: 4, highlight: 'Started Sensors & Control course' },
          ].map(report => (
            <div key={report.week} className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 bg-gray-50 rounded-2xl hover:bg-green-50 transition-colors group">
              <div className="flex-1">
                <p className="font-semibold text-gray-900 text-sm">{report.week}</p>
                <p className="text-sm text-green-600 mt-0.5">{report.highlight}</p>
              </div>
              <div className="flex gap-3 text-sm">
                <span className="badge bg-blue-100 text-blue-700">{report.lessons} lessons</span>
                <span className="badge bg-purple-100 text-purple-700">+{report.xp} XP</span>
                <span className="badge bg-orange-100 text-orange-700">🔥 {report.streak} streak</span>
              </div>
              <button className="text-gray-400 hover:text-green-600 transition-colors">
                <Download className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
