import { Package, Truck, CheckCircle, Clock } from 'lucide-react';

const orders = [
  {
    id: 'ORD-2025-001',
    kit: 'Inventor Robotics Kit v2',
    date: 'May 28, 2025',
    status: 'delivered',
    items: ['Arduino Uno', 'Servo Motors x4', 'Ultrasonic Sensor', 'Breadboard Kit', 'Instruction Manual'],
    image: 'https://images.pexels.com/photos/8566472/pexels-photo-8566472.jpeg?auto=compress&cs=tinysrgb&w=200',
  },
  {
    id: 'ORD-2025-002',
    kit: 'Sensor Expansion Pack',
    date: 'Jun 10, 2025',
    status: 'in_transit',
    items: ['IR Sensor x2', 'Temperature Sensor', 'LCD Display', 'Jumper Wires'],
    image: 'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=200',
  },
];

const statusConfig: Record<string, { icon: typeof CheckCircle; color: string; label: string }> = {
  delivered: { icon: CheckCircle, color: 'bg-green-100 text-green-700', label: 'Delivered' },
  in_transit: { icon: Truck, color: 'bg-blue-100 text-blue-700', label: 'In Transit' },
  processing: { icon: Clock, color: 'bg-yellow-100 text-yellow-700', label: 'Processing' },
};

export default function ParentOrders() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Orders</h1>
        <p className="text-gray-500">Your robotics kit orders</p>
      </div>

      <div className="space-y-4">
        {orders.map(order => {
          const status = statusConfig[order.status];
          return (
            <div key={order.id} className="card p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <img src={order.image} alt={order.kit} className="w-full sm:w-28 h-24 object-cover rounded-2xl flex-shrink-0" />
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <h3 className="font-display font-bold text-gray-900">{order.kit}</h3>
                      <p className="text-sm text-gray-400">Order {order.id} · {order.date}</p>
                    </div>
                    <span className={`badge ${status.color} flex-shrink-0`}>
                      <status.icon className="w-3 h-3 mr-1" />
                      {status.label}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {order.items.map(item => (
                      <span key={item} className="badge bg-gray-100 text-gray-600">{item}</span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
