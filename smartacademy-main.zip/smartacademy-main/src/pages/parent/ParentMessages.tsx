import { useState } from 'react';
import { Send, Search } from 'lucide-react';

const contacts = [
  { id: '1', name: 'Mr. Johnson', role: 'Robotics Teacher', avatar: 'J', color: 'bg-blue-400', lastMessage: 'Alex is doing great!', time: '2h ago', unread: 1 },
  { id: '2', name: 'Ms. Chen', role: 'Sensor Course Teacher', avatar: 'C', color: 'bg-purple-400', lastMessage: 'Session tomorrow at 4PM', time: '1d ago', unread: 0 },
];

const demoMessages = [
  { id: '1', sender: 'them', text: 'Hello! Just wanted to let you know that Alex completed his Traffic Light project and received full marks!', time: '10:00 AM' },
  { id: '2', sender: 'me', text: 'That\'s amazing news! He worked really hard on that. Thank you for letting me know.', time: '10:05 AM' },
  { id: '3', sender: 'them', text: 'He\'s one of our most engaged students. Keep encouraging him at home!', time: '10:07 AM' },
  { id: '4', sender: 'me', text: 'We definitely will. Is there anything specific he should work on next?', time: '10:10 AM' },
  { id: '5', sender: 'them', text: 'He should try the Sensors & Motors course next — it\'s a perfect fit for his level.', time: '10:12 AM' },
];

export default function ParentMessages() {
  const [activeContact, setActiveContact] = useState(contacts[0]);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState(demoMessages);

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    setMessages(prev => [...prev, { id: String(Date.now()), sender: 'me', text: message, time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) }]);
    setMessage('');
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Messages</h1>
        <p className="text-gray-500">Chat with your child's teachers</p>
      </div>
      <div className="card overflow-hidden flex h-[calc(100vh-280px)] min-h-[500px]">
        <div className="w-56 border-r border-gray-100 flex flex-col flex-shrink-0">
          <div className="p-3 border-b border-gray-100">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input className="w-full pl-9 pr-3 py-2 text-sm bg-gray-50 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-green-200" placeholder="Search..." />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {contacts.map(contact => (
              <button
                key={contact.id}
                onClick={() => setActiveContact(contact)}
                className={`w-full p-3 flex items-center gap-3 text-left hover:bg-gray-50 transition-colors ${activeContact.id === contact.id ? 'bg-green-50 border-r-2 border-green-600' : ''}`}
              >
                <div className={`w-9 h-9 ${contact.color} rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0`}>
                  {contact.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 text-sm truncate">{contact.name}</p>
                  <p className="text-xs text-gray-400 truncate">{contact.role}</p>
                </div>
                {contact.unread > 0 && (
                  <span className="w-4 h-4 bg-green-500 text-white text-xs rounded-full flex items-center justify-center flex-shrink-0">{contact.unread}</span>
                )}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 flex flex-col min-w-0">
          <div className="p-4 border-b border-gray-100 flex items-center gap-3">
            <div className={`w-9 h-9 ${activeContact.color} rounded-xl flex items-center justify-center text-white font-bold`}>
              {activeContact.avatar}
            </div>
            <div>
              <p className="font-semibold text-gray-900 text-sm">{activeContact.name}</p>
              <p className="text-xs text-gray-400">{activeContact.role}</p>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map(msg => (
              <div key={msg.id} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[70%] px-4 py-2.5 rounded-2xl text-sm ${
                  msg.sender === 'me' ? 'bg-green-600 text-white rounded-br-md' : 'bg-gray-100 text-gray-800 rounded-bl-md'
                }`}>
                  <p>{msg.text}</p>
                  <p className={`text-xs mt-1 ${msg.sender === 'me' ? 'text-green-200' : 'text-gray-400'}`}>{msg.time}</p>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={sendMessage} className="p-4 border-t border-gray-100 flex gap-3">
            <input
              value={message}
              onChange={e => setMessage(e.target.value)}
              className="flex-1 bg-gray-50 rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-200"
              placeholder="Type a message..."
            />
            <button type="submit" className="w-10 h-10 bg-green-600 text-white rounded-xl flex items-center justify-center hover:bg-green-700 transition-colors flex-shrink-0">
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
