import { useEffect, useState } from 'react';
import { TrendingUp, CreditCard, Package, Bell, ChevronRight, Users, Award, Flame } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';
import type { Student } from '../../types';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const progressData = [
  { week: 'W1', xp: 200 }, { week: 'W2', xp: 450 }, { week: 'W3', xp: 380 },
  { week: 'W4', xp: 620 }, { week: 'W5', xp: 850 }, { week: 'W6', xp: 1200 },
];

export default function ParentDashboard() {
  const { parent, profile } = useAuthStore();
  const [children, setChildren] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!parent) { setLoading(false); return; }
    supabase.from('students').select('*').eq('parent_id', parent.id).then(({ data }) => {
      if (data) setChildren(data);
      setLoading(false);
    });
  }, [parent]);

  const firstName = profile?.full_name?.split(' ')[0] ?? 'Parent';
  const LEVEL_NAMES = ['', 'Circuit Explorer', 'Sensor Builder', 'Robo Inventor', 'AI Engineer', 'Robotics Master'];
  const LEVEL_COLORS = ['', 'bg-green-400', 'bg-blue-400', 'bg-purple-400', 'bg-orange-400', 'bg-yellow-400'];

  const mockChild = { id: '1', username: 'alex_robo', current_level: 3, xp_points: 1850, streak_days: 7 };
  const displayChild = children[0] ?? mockChild;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome */}
      <div className="bg-gradient-to-br from-green-600 to-green-800 rounded-3xl p-6 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-cyber-grid opacity-10" />
        <div className="relative flex flex-col md:flex-row md:items-center gap-4">
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-2xl font-bold">
            {firstName[0]}
          </div>
          <div>
            <p className="text-green-200 text-sm">Parent Portal</p>
            <h1 className="font-display text-2xl font-bold">Hello, {firstName}! 👪</h1>
            <p className="text-green-200 text-sm">Monitoring your child's learning progress</p>
          </div>
        </div>
      </div>

      {/* Child Progress Card */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display font-bold text-xl text-gray-900">Child Progress</h2>
          <Link to="/parent/child-progress" className="text-green-600 text-sm font-medium flex items-center gap-1">
            Details <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 mb-5">
          <div className={`w-16 h-16 ${LEVEL_COLORS[displayChild.current_level]} rounded-2xl flex items-center justify-center text-white font-bold text-2xl`}>
            🤖
          </div>
          <div className="flex-1">
            <p className="font-display font-bold text-xl text-gray-900">@{displayChild.username}</p>
            <p className="text-sm text-gray-500">{LEVEL_NAMES[displayChild.current_level]} · Level {displayChild.current_level}</p>
            <div className="flex items-center gap-4 mt-2">
              <span className="flex items-center gap-1 text-sm"><span className="text-yellow-500">⚡</span> {displayChild.xp_points} XP</span>
              <span className="flex items-center gap-1 text-sm"><Flame className="w-4 h-4 text-orange-400" /> {displayChild.streak_days} day streak</span>
            </div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={120}>
          <LineChart data={progressData}>
            <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#9CA3AF' }} />
            <YAxis hide />
            <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
            <Line type="monotone" dataKey="xp" name="XP Earned" stroke="#16a34a" strokeWidth={3} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { icon: '📚', label: 'Courses Enrolled', value: '3', color: 'bg-blue-50' },
          { icon: '🏆', label: 'Badges Earned', value: '8', color: 'bg-yellow-50' },
          { icon: '🎓', label: 'Certificates', value: '2', color: 'bg-purple-50' },
          { icon: '📦', label: 'Kits Ordered', value: '1', color: 'bg-green-50' },
        ].map(stat => (
          <div key={stat.label} className={`card p-4 ${stat.color} text-center`}>
            <div className="text-3xl mb-1">{stat.icon}</div>
            <div className="font-display font-bold text-xl text-gray-900">{stat.value}</div>
            <div className="text-xs text-gray-500 mt-0.5 leading-tight">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { icon: CreditCard, label: 'Manage Billing', href: '/parent/billing', color: 'from-green-500 to-green-700' },
          { icon: Package, label: 'Track Orders', href: '/parent/orders', color: 'from-blue-500 to-blue-700' },
          { icon: TrendingUp, label: 'View Reports', href: '/parent/reports', color: 'from-purple-500 to-purple-700' },
        ].map(item => (
          <Link key={item.label} to={item.href}
            className={`bg-gradient-to-br ${item.color} rounded-2xl p-5 text-white flex items-center gap-3 hover:shadow-lg hover:scale-105 transition-all`}>
            <item.icon className="w-6 h-6 flex-shrink-0" />
            <span className="font-semibold">{item.label}</span>
            <ChevronRight className="w-4 h-4 ml-auto" />
          </Link>
        ))}
      </div>
    </div>
  );
}
