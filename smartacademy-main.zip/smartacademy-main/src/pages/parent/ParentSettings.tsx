import { useState } from 'react';
import { User, Shield, Bell, MapPin, Save, Trash2 } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';

export default function ParentSettings() {
  const { profile, setProfile } = useAuthStore();
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [notifications, setNotifications] = useState({ progress: true, billing: true, messages: true, weeklyReport: true });

  const handleSave = async () => {
    if (!profile) return;
    setSaving(true);
    await supabase.from('profiles').update({ full_name: fullName }).eq('id', profile.id);
    setProfile({ ...profile, full_name: fullName });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Settings</h1>
        <p className="text-gray-500">Manage your parent account preferences</p>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-green-100 rounded-2xl flex items-center justify-center">
            <User className="w-5 h-5 text-green-600" />
          </div>
          <h2 className="font-display font-bold text-lg text-gray-900">Profile</h2>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
            <input value={fullName} onChange={e => setFullName(e.target.value)} className="input-field" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Email</label>
            <input value="parent@example.com" className="input-field bg-gray-50" disabled />
          </div>
          <button onClick={handleSave} disabled={saving} className="bg-green-600 text-white font-semibold rounded-2xl px-6 py-2.5 text-sm hover:bg-green-700 transition-colors flex items-center gap-2">
            <Save className="w-4 h-4" />
            {saved ? 'Saved!' : saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-purple-100 rounded-2xl flex items-center justify-center">
            <Bell className="w-5 h-5 text-purple-600" />
          </div>
          <h2 className="font-display font-bold text-lg text-gray-900">Notifications</h2>
        </div>
        <div className="space-y-4">
          {(Object.entries(notifications) as [string, boolean][]).map(([key, value]) => {
            const labels: Record<string, string> = {
              progress: 'Child Progress Updates',
              billing: 'Billing & Payment Alerts',
              messages: 'Teacher Messages',
              weeklyReport: 'Weekly Progress Reports',
            };
            return (
              <div key={key} className="flex items-center justify-between py-2">
                <span className="text-sm font-medium text-gray-700">{labels[key]}</span>
                <button
                  onClick={() => setNotifications(prev => ({ ...prev, [key]: !value }))}
                  className={`relative w-12 h-6 rounded-full transition-colors ${value ? 'bg-green-500' : 'bg-gray-200'}`}
                >
                  <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform shadow ${value ? 'translate-x-7' : 'translate-x-1'}`} />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-red-100 rounded-2xl flex items-center justify-center">
            <Shield className="w-5 h-5 text-red-500" />
          </div>
          <h2 className="font-display font-bold text-lg text-gray-900">Privacy & COPPA</h2>
        </div>
        <div className="space-y-3 text-sm">
          <p className="bg-green-50 text-green-700 rounded-2xl p-4">
            Your child's data is fully protected under COPPA regulations. We collect minimal data, encrypt everything, and never share it with third parties.
          </p>
          <button className="flex items-center gap-2 text-red-500 font-medium hover:text-red-700 transition-colors">
            <Trash2 className="w-4 h-4" />
            Request Data Deletion
          </button>
        </div>
      </div>
    </div>
  );
}
