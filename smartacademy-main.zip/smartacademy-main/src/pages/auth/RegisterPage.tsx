import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Mail, Lock, Eye, EyeOff, User, Bot, ArrowRight, AlertCircle, Check } from 'lucide-react';
import { supabase } from '../../lib/supabase';

type Role = 'parent' | 'teacher';

const schema = z.object({
  fullName: z.string().min(2, 'Full name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  confirmPassword: z.string(),
  agreeTerms: z.boolean().refine(val => val, 'You must accept the terms'),
  agreePrivacy: z.boolean().refine(val => val, 'You must accept the privacy policy'),
}).refine(data => data.password === data.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
});
type FormData = z.infer<typeof schema>;

export default function RegisterPage() {
  const [role, setRole] = useState<Role>('parent');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { agreeTerms: false, agreePrivacy: false },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    setError('');
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: { full_name: data.fullName, role },
        },
      });
      if (authError) throw authError;

      if (authData.user) {
        await supabase.from('profiles').insert({
          id: authData.user.id,
          role,
          full_name: data.fullName,
        });

        if (role === 'parent') {
          await supabase.from('parents').insert({ user_id: authData.user.id });
          navigate('/parent/dashboard');
        } else {
          await supabase.from('teachers').insert({ user_id: authData.user.id });
          navigate('/teacher/dashboard');
        }
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-yellow-50/30 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl flex items-center justify-center shadow-glow mx-auto mb-4">
              <Bot className="w-8 h-8 text-white" />
            </div>
          </Link>
          <h1 className="font-display text-3xl font-bold text-gray-900 mb-2">Join Smart Kids Academy</h1>
          <p className="text-gray-500">Start your 14-day free trial today</p>
        </div>

        <div className="card p-8">
          {/* Role Toggle */}
          <div className="grid grid-cols-2 gap-3 mb-6 bg-gray-100 p-1.5 rounded-2xl">
            {(['parent', 'teacher'] as Role[]).map(r => (
              <button
                key={r}
                onClick={() => setRole(r)}
                className={`py-2.5 rounded-xl text-sm font-semibold capitalize transition-all ${role === r ? 'bg-white text-purple-600 shadow-sm' : 'text-gray-500'}`}
              >
                {r === 'parent' ? '👪 Parent' : '👨‍🏫 Teacher'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {error && (
              <div className="flex items-center gap-2 bg-red-50 text-red-600 border border-red-200 rounded-2xl px-4 py-3 text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input {...register('fullName')} className="input-field pl-11" placeholder="Jane Smith" />
              </div>
              {errors.fullName && <p className="text-red-500 text-xs mt-1">{errors.fullName.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input {...register('email')} type="email" className="input-field pl-11" placeholder="you@email.com" />
              </div>
              {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input {...register('password')} type={showPassword ? 'text' : 'password'} className="input-field pl-11 pr-11" placeholder="Min. 8 characters" />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input {...register('confirmPassword')} type="password" className="input-field pl-11" placeholder="Repeat password" />
              </div>
              {errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword.message}</p>}
            </div>

            <div className="space-y-3 pt-1">
              {[
                { field: 'agreeTerms' as const, label: 'I agree to the Terms of Service' },
                { field: 'agreePrivacy' as const, label: 'I agree to the Privacy Policy & COPPA disclosure' },
              ].map(({ field, label }) => (
                <label key={field} className="flex items-start gap-3 cursor-pointer">
                  <input {...register(field)} type="checkbox" className="mt-0.5 w-4 h-4 accent-purple-600" />
                  <span className="text-sm text-gray-600">{label}</span>
                </label>
              ))}
              {(errors.agreeTerms || errors.agreePrivacy) && (
                <p className="text-red-500 text-xs">Please accept all required agreements</p>
              )}
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2 mt-2">
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>Create Account <ArrowRight className="w-4 h-4" /></>}
            </button>
          </form>

          <p className="text-center text-sm text-gray-500 mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-purple-600 font-semibold">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
