import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bot, ArrowRight, AlertCircle, Hash } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';

const EMOJIS = ['🤖', '🚀', '⭐', '🎮', '🔥', '💎', '🌟', '🦁', '🐉', '🎯', '⚡', '🏆'];

export default function StudentLoginPage() {
  const [username, setUsername] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'pin' | 'emoji'>('pin');
  const [emojiPassword, setEmojiPassword] = useState<string[]>([]);
  const { fetchUserData } = useAuthStore();
  const navigate = useNavigate();

  const addEmoji = (emoji: string) => {
    if (emojiPassword.length < 4) setEmojiPassword(prev => [...prev, emoji]);
  };

  const handleLogin = async () => {
    if (!username) { setError('Please enter your username'); return; }
    setLoading(true);
    setError('');
    try {
      const { data: student, error: studentError } = await supabase
        .from('students')
        .select('user_id, pin_hash')
        .eq('username', username.toLowerCase())
        .maybeSingle();

      if (studentError || !student) throw new Error('Student not found. Check your username.');

      const enteredPin = mode === 'pin' ? pin : emojiPassword.join('');
      if (student.pin_hash && student.pin_hash !== enteredPin) throw new Error('Incorrect PIN/password.');

      await fetchUserData(student.user_id);
      navigate('/student/dashboard');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-yellow-50/30 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <Link to="/">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-3xl flex items-center justify-center shadow-glow mx-auto mb-4 animate-float">
              <Bot className="w-9 h-9 text-white" />
            </div>
          </Link>
          <h1 className="font-display text-3xl font-bold text-gray-900 mb-1">Hi there! 👋</h1>
          <p className="text-gray-500">Log in to your robot academy</p>
        </div>

        <div className="card p-8">
          {error && (
            <div className="flex items-center gap-2 bg-red-50 text-red-600 border border-red-200 rounded-2xl px-4 py-3 text-sm mb-4">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          )}

          <div className="mb-5">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Your Username</label>
            <input
              value={username}
              onChange={e => setUsername(e.target.value)}
              className="input-field text-center text-lg font-semibold"
              placeholder="robo_alex_42"
            />
          </div>

          <div className="flex gap-2 mb-5">
            <button
              onClick={() => setMode('pin')}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${mode === 'pin' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-500'}`}
            >
              <Hash className="w-4 h-4 inline mr-1" /> PIN
            </button>
            <button
              onClick={() => setMode('emoji')}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${mode === 'emoji' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-500'}`}
            >
              🎭 Emoji
            </button>
          </div>

          {mode === 'pin' ? (
            <div className="mb-5">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">4-Digit PIN</label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={pin}
                onChange={e => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                className="input-field text-center text-3xl tracking-widest"
                placeholder="• • • •"
              />
            </div>
          ) : (
            <div className="mb-5">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Emoji Password (pick 4)</label>
              <div className="flex justify-center gap-3 mb-3 h-12 items-center bg-gray-50 rounded-2xl">
                {emojiPassword.length > 0 ? emojiPassword.map((e, i) => (
                  <span key={i} className="text-2xl">{e}</span>
                )) : <span className="text-gray-300 text-sm">Pick 4 emojis below</span>}
              </div>
              <div className="grid grid-cols-6 gap-2">
                {EMOJIS.map(emoji => (
                  <button
                    key={emoji}
                    onClick={() => addEmoji(emoji)}
                    disabled={emojiPassword.length >= 4}
                    className="text-2xl w-10 h-10 rounded-xl hover:bg-purple-50 transition-all disabled:opacity-40 flex items-center justify-center"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
              {emojiPassword.length > 0 && (
                <button onClick={() => setEmojiPassword([])} className="text-xs text-purple-500 mt-2 hover:underline">Clear</button>
              )}
            </div>
          )}

          <button
            onClick={handleLogin}
            disabled={loading || (mode === 'pin' ? pin.length < 4 : emojiPassword.length < 4)}
            className="btn-primary w-full flex items-center justify-center gap-2"
          >
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <>Let's Go! <ArrowRight className="w-4 h-4" /></>}
          </button>

          <p className="text-center text-sm text-gray-500 mt-4">
            New student?{' '}
            <Link to="/register" className="text-purple-600 font-semibold">Ask your parent</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
