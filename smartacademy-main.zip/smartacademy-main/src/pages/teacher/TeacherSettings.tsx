import { useState } from 'react';
import { User, Bell, Shield, Save } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';

export default function TeacherSettings() {
  const { profile, teacher, setProfile } = useAuthStore();
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [bio, setBio] = useState(teacher?.bio ?? '');
  const [specialization, setSpecialization] = useState(teacher?.specialization ?? '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    if (!profile) return;
    setSaving(true);
    await Promise.all([
      supabase.from('profiles').update({ full_name: fullName }).eq('id', profile.id),
      teacher && supabase.from('teachers').update({ bio, specialization }).eq('id', teacher.id),
    ]);
    setProfile({ ...profile, full_name: fullName });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Settings</h1>
        <p className="text-gray-500">Manage your teacher account</p>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-blue-100 rounded-2xl flex items-center justify-center">
            <User className="w-5 h-5 text-blue-600" />
          </div>
          <h2 className="font-display font-bold text-lg text-gray-900">Profile Information</h2>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
            <input value={fullName} onChange={e => setFullName(e.target.value)} className="input-field" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Specialization</label>
            <input value={specialization} onChange={e => setSpecialization(e.target.value)} className="input-field" placeholder="e.g. Robotics & Arduino" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Bio</label>
            <textarea value={bio} onChange={e => setBio(e.target.value)} className="input-field h-24 resize-none" placeholder="Tell students about yourself..." />
          </div>
          <button onClick={handleSave} disabled={saving} className="bg-blue-600 text-white font-semibold rounded-2xl px-6 py-2.5 text-sm hover:bg-blue-700 transition-colors flex items-center gap-2">
            <Save className="w-4 h-4" />
            {saved ? 'Saved!' : saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-green-100 rounded-2xl flex items-center justify-center">
            <Shield className="w-5 h-5 text-green-600" />
          </div>
          <h2 className="font-display font-bold text-lg text-gray-900">Security</h2>
        </div>
        <div className="space-y-3 text-sm text-gray-600">
          <p className="bg-green-50 rounded-2xl p-4">2-Factor Authentication is enabled for your account.</p>
          <button className="text-blue-600 font-medium hover:underline">Change Password</button>
        </div>
      </div>
    </div>
  );
}
