import { useEffect, useState } from 'react';
import {
  Users, FolderOpen, ClipboardList, TrendingUp,
  MessageSquare, Bell, Video, BarChart2, Upload, CheckCircle,
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Link } from 'react-router-dom';

const weeklyData = [
  { day: 'Mon', views: 24, downloads: 8 },
  { day: 'Tue', views: 38, downloads: 14 },
  { day: 'Wed', views: 29, downloads: 11 },
  { day: 'Thu', views: 45, downloads: 19 },
  { day: 'Fri', views: 36, downloads: 13 },
  { day: 'Sat', views: 18, downloads: 6 },
  { day: 'Sun', views: 12, downloads: 4 },
];

const recentStudents = [
  { name: 'Alex Johnson', progress: 72, avatar: 'A', color: 'bg-purple-400', lastFile: 'Lesson 3 – Motors' },
  { name: 'Maya Chen', progress: 45, avatar: 'M', color: 'bg-blue-400', lastFile: 'Intro PDF' },
  { name: 'Liam Smith', progress: 30, avatar: 'L', color: 'bg-green-400', lastFile: 'Homework Sheet' },
  { name: 'Sofia Garcia', progress: 88, avatar: 'S', color: 'bg-orange-400', lastFile: 'Project Guide' },
];

const upcomingSessions = [
  { title: 'Arduino Basics – Week 3', time: 'Tomorrow, 4:00 PM', platform: 'zoom', students: 14 },
  { title: 'Robot Arm Assembly', time: 'Jun 20, 2:00 PM', platform: 'google_meet', students: 18 },
];

export default function TeacherDashboard() {
  const { teacher, profile } = useAuthStore();
  const [stats, setStats] = useState({
    students: 0,
    uploadedFiles: 0,
    pendingAssignments: 0,
    sessions: 0,
    unreadMessages: 3,
    notifications: 5,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      if (!teacher) { setLoading(false); return; }
      const [filesRes, sessionsRes, assignRes] = await Promise.all([
        supabase.from('course_files').select('id', { count: 'exact' }).eq('teacher_id', teacher.id),
        supabase.from('live_sessions').select('id', { count: 'exact' }).eq('teacher_id', teacher.id).eq('status', 'scheduled'),
        supabase.from('assignments').select('id', { count: 'exact' }).eq('teacher_id', teacher.id),
      ]);
      setStats({
        students: teacher.total_students || 24,
        uploadedFiles: filesRes.count ?? 0,
        pendingAssignments: assignRes.count ?? 0,
        sessions: sessionsRes.count ?? 0,
        unreadMessages: 3,
        notifications: 5,
      });
      setLoading(false);
    };
    fetchStats();
  }, [teacher]);

  const firstName = profile?.full_name?.split(' ')[0] ?? 'Teacher';

  const statCards = [
    {
      icon: Users,
      label: 'Total Students',
      value: stats.students,
      sub: '+3 this week',
      color: 'bg-blue-50',
      iconColor: 'bg-blue-100 text-blue-600',
      href: '/teacher/students',
    },
    {
      icon: FolderOpen,
      label: 'Uploaded Files',
      value: stats.uploadedFiles,
      sub: 'Across all modules',
      color: 'bg-purple-50',
      iconColor: 'bg-purple-100 text-purple-600',
      href: '/teacher/courses',
    },
    {
      icon: ClipboardList,
      label: 'Pending Assignments',
      value: stats.pendingAssignments || 8,
      sub: '3 need grading',
      color: 'bg-yellow-50',
      iconColor: 'bg-yellow-100 text-yellow-600',
      href: '/teacher/assignments',
    },
    {
      icon: TrendingUp,
      label: 'Student Progress',
      value: '71%',
      sub: 'Avg. completion',
      color: 'bg-green-50',
      iconColor: 'bg-green-100 text-green-600',
      href: '/teacher/analytics',
    },
    {
      icon: MessageSquare,
      label: 'Messages',
      value: stats.unreadMessages,
      sub: 'Unread messages',
      color: 'bg-pink-50',
      iconColor: 'bg-pink-100 text-pink-500',
      href: '/teacher/messages',
    },
    {
      icon: Bell,
      label: 'Notifications',
      value: stats.notifications,
      sub: 'New alerts',
      color: 'bg-orange-50',
      iconColor: 'bg-orange-100 text-orange-500',
      href: '/teacher/dashboard',
    },
    {
      icon: Video,
      label: 'Upcoming Classes',
      value: upcomingSessions.length,
      sub: 'Scheduled sessions',
      color: 'bg-cyan-50',
      iconColor: 'bg-cyan-100 text-cyan-600',
      href: '/teacher/live-sessions',
    },
    {
      icon: CheckCircle,
      label: 'Completion Rate',
      value: '87%',
      sub: '+5% vs last month',
      color: 'bg-emerald-50',
      iconColor: 'bg-emerald-100 text-emerald-600',
      href: '/teacher/analytics',
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Hero */}
      <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-3xl p-6 md:p-8 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-cyber-grid opacity-10" />
        <div className="absolute top-0 right-0 w-48 h-48 bg-purple-500/20 rounded-full -translate-y-1/4 translate-x-1/4" />
        <div className="relative flex flex-col md:flex-row md:items-center gap-5">
          <div className="w-16 h-16 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center text-2xl font-bold flex-shrink-0 border border-white/20">
            {firstName[0]}
          </div>
          <div className="flex-1">
            <p className="text-blue-200 text-sm mb-0.5">Good morning,</p>
            <h1 className="font-display text-2xl md:text-3xl font-bold">{firstName}! 👨‍🏫</h1>
            <p className="text-blue-200 text-sm mt-0.5">{teacher?.specialization ?? 'Robotics Teacher'} · Smart Kids Academy</p>
          </div>
          <div className="flex gap-3 flex-wrap">
            <div className="bg-white/10 backdrop-blur rounded-2xl px-4 py-3 text-center border border-white/10">
              <p className="font-display font-bold text-2xl">{stats.students}</p>
              <p className="text-blue-200 text-xs mt-0.5">Students</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-2xl px-4 py-3 text-center border border-white/10">
              <p className="font-display font-bold text-2xl">{stats.uploadedFiles}</p>
              <p className="text-blue-200 text-xs mt-0.5">Files</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-2xl px-4 py-3 text-center border border-white/10">
              <p className="font-display font-bold text-2xl">{upcomingSessions.length}</p>
              <p className="text-blue-200 text-xs mt-0.5">Sessions</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bento-style Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {statCards.map(stat => (
          <Link
            key={stat.label}
            to={stat.href}
            className={`card p-4 md:p-5 ${stat.color} hover:shadow-card-hover hover:-translate-y-0.5 transition-all group`}
          >
            <div className={`w-10 h-10 ${stat.iconColor} rounded-2xl flex items-center justify-center mb-3`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div className="font-display font-bold text-2xl text-gray-900">{stat.value}</div>
            <div className="text-sm font-semibold text-gray-700 mt-0.5 leading-tight">{stat.label}</div>
            <div className="text-xs text-gray-400 mt-1">{stat.sub}</div>
          </Link>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* File Activity Chart */}
        <div className="lg:col-span-2 card p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-display font-bold text-xl text-gray-900">File Activity This Week</h2>
            <div className="flex items-center gap-3 text-xs text-gray-400">
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-purple-500 inline-block" />Views</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-yellow-400 inline-block" />Downloads</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={weeklyData} barGap={4}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9CA3AF' }} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.1)', padding: '10px 14px' }}
                labelStyle={{ fontWeight: 600, color: '#1f2937' }}
              />
              <Bar dataKey="views" name="Views" fill="#8B5CF6" radius={[6, 6, 0, 0]} />
              <Bar dataKey="downloads" name="Downloads" fill="#FACC15" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Student Progress */}
        <div className="card p-6">
          <h2 className="font-display font-bold text-xl text-gray-900 mb-5">Student Progress</h2>
          <div className="space-y-4">
            {recentStudents.map(student => (
              <div key={student.name} className="flex items-center gap-3">
                <div className={`w-9 h-9 ${student.color} rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0`}>
                  {student.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between mb-1">
                    <p className="font-semibold text-gray-900 text-xs truncate">{student.name}</p>
                    <span className="text-xs font-bold text-gray-500 flex-shrink-0 ml-1">{student.progress}%</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: `${student.progress}%` }} />
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5 truncate">Last: {student.lastFile}</p>
                </div>
              </div>
            ))}
          </div>
          <Link to="/teacher/students" className="block text-center text-blue-600 text-xs font-semibold mt-4 hover:underline">
            View all students →
          </Link>
        </div>
      </div>

      {/* Upcoming Live Sessions + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Sessions */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-xl text-gray-900">Upcoming Live Classes</h2>
            <Link to="/teacher/live-sessions" className="text-blue-600 text-sm font-medium hover:underline">See all</Link>
          </div>
          {upcomingSessions.length === 0 ? (
            <div className="text-center py-8">
              <Video className="w-10 h-10 text-gray-200 mx-auto mb-2" />
              <p className="text-gray-400 text-sm">No upcoming sessions</p>
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingSessions.map(session => (
                <div key={session.title} className="flex items-center gap-4 p-4 bg-gradient-to-r from-blue-50 to-white rounded-2xl border border-blue-100">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${session.platform === 'zoom' ? 'bg-blue-100' : 'bg-green-100'}`}>
                    <Video className={`w-5 h-5 ${session.platform === 'zoom' ? 'text-blue-600' : 'text-green-600'}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm truncate">{session.title}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{session.time} · {session.students} students</p>
                  </div>
                  <span className={`badge flex-shrink-0 ${session.platform === 'zoom' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'}`}>
                    {session.platform === 'zoom' ? 'Zoom' : 'Meet'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="card p-6">
          <h2 className="font-display font-bold text-xl text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Upload Files', icon: Upload, color: 'from-purple-500 to-purple-700', href: '/teacher/courses' },
              { label: 'Schedule Session', icon: Video, color: 'from-blue-500 to-blue-700', href: '/teacher/live-sessions' },
              { label: 'Grade Work', icon: CheckCircle, color: 'from-green-500 to-green-700', href: '/teacher/assignments' },
              { label: 'View Analytics', icon: BarChart2, color: 'from-orange-500 to-orange-600', href: '/teacher/analytics' },
            ].map(action => (
              <Link
                key={action.label}
                to={action.href}
                className={`bg-gradient-to-br ${action.color} rounded-2xl p-4 text-white flex flex-col items-center gap-2 text-center hover:shadow-lg hover:scale-105 transition-all`}
              >
                <action.icon className="w-6 h-6" />
                <span className="text-xs font-semibold leading-tight">{action.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
