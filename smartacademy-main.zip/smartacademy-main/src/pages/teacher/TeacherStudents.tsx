import { useState } from 'react';
import { Search, Filter, ChevronRight, Mail } from 'lucide-react';

const mockStudents = [
  { id: '1', name: 'Alex Johnson', username: 'alex_robo', level: 3, xp: 1850, progress: 72, streak: 7, avatar: 'A', color: 'bg-purple-400', lastActive: '2 hours ago', status: 'active' },
  { id: '2', name: 'Maya Chen', username: 'maya_bot', level: 2, xp: 890, progress: 45, streak: 3, avatar: 'M', color: 'bg-blue-400', lastActive: '1 day ago', status: 'active' },
  { id: '3', name: 'Liam Smith', username: 'liam_s', level: 1, xp: 320, progress: 30, streak: 0, avatar: 'L', color: 'bg-green-400', lastActive: '3 days ago', status: 'inactive' },
  { id: '4', name: 'Sofia Garcia', username: 'sofia_g', level: 4, xp: 4200, progress: 88, streak: 15, avatar: 'S', color: 'bg-orange-400', lastActive: 'Just now', status: 'active' },
  { id: '5', name: 'Ethan Park', username: 'ethan_p', level: 2, xp: 1100, progress: 55, streak: 5, avatar: 'E', color: 'bg-pink-400', lastActive: '5 hours ago', status: 'active' },
  { id: '6', name: 'Aria Patel', username: 'aria_p', level: 1, xp: 450, progress: 25, streak: 2, avatar: 'A', color: 'bg-yellow-400', lastActive: '2 days ago', status: 'inactive' },
];

const LEVEL_NAMES = ['', 'Circuit Explorer', 'Sensor Builder', 'Robo Inventor', 'AI Engineer', 'Robotics Master'];

export default function TeacherStudents() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  const filtered = mockStudents.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.username.includes(search.toLowerCase());
    const matchFilter = filter === 'all' || s.status === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Students</h1>
          <p className="text-gray-500">{mockStudents.length} students enrolled</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input value={search} onChange={e => setSearch(e.target.value)} className="input-field pl-11" placeholder="Search students..." />
        </div>
        <div className="flex gap-2">
          {['all', 'active', 'inactive'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-all capitalize ${filter === f ? 'bg-blue-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-blue-300'}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Students Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(student => (
          <div key={student.id} className="card-hover p-5">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 ${student.color} rounded-2xl flex items-center justify-center text-white font-bold text-lg`}>
                  {student.avatar}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{student.name}</p>
                  <p className="text-xs text-gray-400">@{student.username}</p>
                </div>
              </div>
              <span className={`w-2 h-2 rounded-full mt-2 ${student.status === 'active' ? 'bg-green-400' : 'bg-gray-300'}`} />
            </div>

            <div className="grid grid-cols-3 gap-2 mb-4 text-center">
              <div className="bg-purple-50 rounded-xl p-2">
                <p className="font-bold text-purple-700">{student.level}</p>
                <p className="text-xs text-gray-400">Level</p>
              </div>
              <div className="bg-yellow-50 rounded-xl p-2">
                <p className="font-bold text-yellow-700">{student.xp}</p>
                <p className="text-xs text-gray-400">XP</p>
              </div>
              <div className="bg-orange-50 rounded-xl p-2">
                <p className="font-bold text-orange-700">🔥{student.streak}</p>
                <p className="text-xs text-gray-400">Streak</p>
              </div>
            </div>

            <div className="mb-3">
              <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span>{LEVEL_NAMES[student.level]}</span>
                <span>{student.progress}%</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${student.progress}%` }} />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-400">Active {student.lastActive}</span>
              <button className="flex items-center gap-1 text-blue-600 text-xs font-medium hover:text-blue-700">
                <Mail className="w-3.5 h-3.5" /> Message
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
