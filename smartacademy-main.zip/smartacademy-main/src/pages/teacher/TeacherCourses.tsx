import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Upload, FolderPlus, Search, Filter, Grid3X3, List,
  FileText, Film, Image, Archive, FileSpreadsheet, Presentation,
  MoreVertical, Download, Eye, Edit2, Trash2, Copy, Globe,
  Lock, Calendar, GripVertical, ChevronDown, ChevronRight,
  Plus, X, Check, AlertCircle, FolderOpen, File,
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';

// ─── Types ───────────────────────────────────────────────────────────────────

interface CourseModule {
  id: string;
  teacher_id: string;
  title: string;
  description: string | null;
  category: string;
  order_index: number;
  created_at: string;
}

interface CourseFile {
  id: string;
  teacher_id: string;
  module_id: string | null;
  title: string;
  description: string | null;
  file_url: string | null;
  file_type: string | null;
  file_size: number;
  file_name: string | null;
  thumbnail_url: string | null;
  visibility: 'draft' | 'published';
  release_date: string | null;
  order_index: number;
  view_count: number;
  download_count: number;
  created_at: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const CATEGORIES = ['All', 'Robotics Basics', 'Electronics', 'Arduino Programming', 'Sensors', 'Projects', 'Homework'];

const FILE_TYPE_MAP: Record<string, { icon: typeof FileText; color: string; bg: string }> = {
  'application/pdf': { icon: FileText, color: 'text-red-500', bg: 'bg-red-50' },
  'video/mp4': { icon: Film, color: 'text-blue-500', bg: 'bg-blue-50' },
  'video/webm': { icon: Film, color: 'text-blue-500', bg: 'bg-blue-50' },
  'image/jpeg': { icon: Image, color: 'text-green-500', bg: 'bg-green-50' },
  'image/png': { icon: Image, color: 'text-green-500', bg: 'bg-green-50' },
  'image/gif': { icon: Image, color: 'text-green-500', bg: 'bg-green-50' },
  'application/zip': { icon: Archive, color: 'text-yellow-600', bg: 'bg-yellow-50' },
  'application/vnd.ms-excel': { icon: FileSpreadsheet, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { icon: FileSpreadsheet, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  'application/vnd.ms-powerpoint': { icon: Presentation, color: 'text-orange-500', bg: 'bg-orange-50' },
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': { icon: Presentation, color: 'text-orange-500', bg: 'bg-orange-50' },
  'application/msword': { icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' },
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' },
};

function getFileTypeInfo(mimeType: string | null) {
  if (!mimeType) return { icon: File, color: 'text-gray-500', bg: 'bg-gray-50' };
  return FILE_TYPE_MAP[mimeType] ?? { icon: File, color: 'text-gray-500', bg: 'bg-gray-50' };
}

function formatFileSize(bytes: number) {
  if (bytes === 0) return '—';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

function getFileExtLabel(mimeType: string | null): string {
  if (!mimeType) return 'FILE';
  if (mimeType.includes('pdf')) return 'PDF';
  if (mimeType.includes('mp4') || mimeType.includes('webm')) return 'VIDEO';
  if (mimeType.includes('image')) return 'IMAGE';
  if (mimeType.includes('zip')) return 'ZIP';
  if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) return 'XLSX';
  if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return 'PPTX';
  if (mimeType.includes('word')) return 'DOCX';
  return 'FILE';
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function FileTypeIcon({ mimeType, size = 'md' }: { mimeType: string | null; size?: 'sm' | 'md' | 'lg' }) {
  const info = getFileTypeInfo(mimeType);
  const sizeMap = { sm: 'w-4 h-4', md: 'w-5 h-5', lg: 'w-7 h-7' };
  const containerMap = { sm: 'w-8 h-8', md: 'w-10 h-10', lg: 'w-14 h-14' };
  return (
    <div className={`${containerMap[size]} ${info.bg} rounded-2xl flex items-center justify-center flex-shrink-0`}>
      <info.icon className={`${sizeMap[size]} ${info.color}`} />
    </div>
  );
}

// ─── Upload Modal ──────────────────────────────────────────────────────────────

interface UploadModalProps {
  modules: CourseModule[];
  teacherId: string;
  onClose: () => void;
  onUploaded: (files: CourseFile[]) => void;
}

function UploadModal({ modules, teacherId, onClose, onUploaded }: UploadModalProps) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [uploadErrors, setUploadErrors] = useState<Record<string, string>>({});
  const [moduleId, setModuleId] = useState<string>('');
  const [titles, setTitles] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = Array.from(e.dataTransfer.files);
    setSelectedFiles(prev => {
      const names = new Set(prev.map(f => f.name));
      return [...prev, ...dropped.filter(f => !names.has(f.name))];
    });
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const picked = Array.from(e.target.files);
    setSelectedFiles(prev => {
      const names = new Set(prev.map(f => f.name));
      return [...prev, ...picked.filter(f => !names.has(f.name))];
    });
  };

  const removeFile = (name: string) => {
    setSelectedFiles(prev => prev.filter(f => f.name !== name));
  };

  const getBucket = (mime: string) => {
    if (mime.startsWith('video/')) return 'lesson-videos';
    if (mime.startsWith('image/')) return 'project-images';
    return 'lesson-documents';
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) return;
    setUploading(true);
    const uploaded: CourseFile[] = [];

    for (const file of selectedFiles) {
      const key = file.name;
      try {
        setUploadProgress(prev => ({ ...prev, [key]: 10 }));

        const ext = file.name.split('.').pop();
        const safeName = `${teacherId}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
        const bucket = getBucket(file.type);

        const { error: storageError } = await supabase.storage
          .from(bucket)
          .upload(safeName, file, { cacheControl: '3600', upsert: false });

        if (storageError) throw storageError;
        setUploadProgress(prev => ({ ...prev, [key]: 70 }));

        const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(safeName);

        const { data: dbFile, error: dbError } = await supabase
          .from('course_files')
          .insert({
            teacher_id: teacherId,
            module_id: moduleId || null,
            title: titles[key] || file.name.replace(/\.[^/.]+$/, ''),
            file_url: publicUrl,
            file_type: file.type,
            file_size: file.size,
            file_name: file.name,
            visibility: 'draft',
          })
          .select()
          .single();

        if (dbError) throw dbError;
        setUploadProgress(prev => ({ ...prev, [key]: 100 }));
        if (dbFile) uploaded.push(dbFile);
      } catch (err: unknown) {
        setUploadErrors(prev => ({ ...prev, [key]: err instanceof Error ? err.message : 'Upload failed' }));
        setUploadProgress(prev => ({ ...prev, [key]: -1 }));
      }
    }

    if (uploaded.length > 0) onUploaded(uploaded);
    setUploading(false);
    if (Object.keys(uploadErrors).length === 0) onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="font-display font-bold text-xl text-gray-900">Upload Teaching Materials</h2>
            <p className="text-sm text-gray-500 mt-0.5">PDF, MP4, PPTX, DOCX, XLSX, ZIP, Images</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 transition-colors">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Module selector */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Add to Module (optional)</label>
            <select value={moduleId} onChange={e => setModuleId(e.target.value)} className="input-field">
              <option value="">No module (uncategorised)</option>
              {modules.map(m => <option key={m.id} value={m.id}>{m.title}</option>)}
            </select>
          </div>

          {/* Drop Zone */}
          <div
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`relative border-2 border-dashed rounded-3xl p-10 text-center cursor-pointer transition-all ${
              dragOver
                ? 'border-purple-500 bg-purple-50 scale-[1.01]'
                : 'border-gray-200 hover:border-purple-400 hover:bg-purple-50/50'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              className="hidden"
              accept=".pdf,.mp4,.webm,.pptx,.ppt,.docx,.doc,.xlsx,.xls,.zip,.jpg,.jpeg,.png,.gif,.webp"
              onChange={handleFileSelect}
            />
            <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Upload className="w-8 h-8 text-purple-600" />
            </div>
            <p className="font-semibold text-gray-900 text-lg mb-1">
              {dragOver ? 'Drop files here!' : 'Drag & drop files here'}
            </p>
            <p className="text-sm text-gray-400">or click to browse your computer</p>
            <p className="text-xs text-gray-300 mt-2">Max 500MB per video · 100MB per file</p>
          </div>

          {/* File list */}
          {selectedFiles.length > 0 && (
            <div className="space-y-3">
              <p className="text-sm font-semibold text-gray-700">{selectedFiles.length} file{selectedFiles.length > 1 ? 's' : ''} selected</p>
              {selectedFiles.map(file => {
                const progress = uploadProgress[file.name] ?? 0;
                const error = uploadErrors[file.name];
                // info used below for icon lookup
                return (
                  <div key={file.name} className="bg-gray-50 rounded-2xl p-4">
                    <div className="flex items-start gap-3 mb-2">
                      <FileTypeIcon mimeType={file.type} size="sm" />
                      <div className="flex-1 min-w-0">
                        <input
                          value={titles[file.name] ?? file.name.replace(/\.[^/.]+$/, '')}
                          onChange={e => setTitles(prev => ({ ...prev, [file.name]: e.target.value }))}
                          className="w-full text-sm font-medium text-gray-900 bg-transparent border-b border-gray-200 focus:border-purple-400 focus:outline-none pb-0.5 mb-1"
                          placeholder="File title"
                        />
                        <p className="text-xs text-gray-400">{file.name} · {formatFileSize(file.size)}</p>
                      </div>
                      {!uploading && (
                        <button onClick={() => removeFile(file.name)} className="p-1 rounded-lg hover:bg-gray-200 transition-colors flex-shrink-0">
                          <X className="w-3.5 h-3.5 text-gray-400" />
                        </button>
                      )}
                    </div>

                    {/* Progress bar */}
                    {uploading && progress > 0 && (
                      <div className="mt-2">
                        {progress === -1 ? (
                          <div className="flex items-center gap-2 text-xs text-red-500">
                            <AlertCircle className="w-3.5 h-3.5" />
                            {error ?? 'Upload failed'}
                          </div>
                        ) : progress === 100 ? (
                          <div className="flex items-center gap-2 text-xs text-green-600">
                            <Check className="w-3.5 h-3.5" />
                            Uploaded successfully
                          </div>
                        ) : (
                          <div className="progress-bar">
                            <div className="progress-fill transition-all duration-300" style={{ width: `${progress}%` }} />
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-100 flex gap-3">
          <button
            onClick={handleUpload}
            disabled={uploading || selectedFiles.length === 0}
            className="flex-1 btn-primary flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {uploading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Uploading…
              </>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                Upload {selectedFiles.length > 0 ? `${selectedFiles.length} file${selectedFiles.length > 1 ? 's' : ''}` : 'Files'}
              </>
            )}
          </button>
          <button onClick={onClose} className="btn-secondary px-5">Cancel</button>
        </div>
      </div>
    </div>
  );
}

// ─── Module Form Modal ─────────────────────────────────────────────────────────

interface ModuleFormProps {
  teacherId: string;
  existing?: CourseModule;
  onClose: () => void;
  onSaved: (mod: CourseModule) => void;
}

function ModuleFormModal({ teacherId, existing, onClose, onSaved }: ModuleFormProps) {
  const [title, setTitle] = useState(existing?.title ?? '');
  const [description, setDescription] = useState(existing?.description ?? '');
  const [category, setCategory] = useState(existing?.category ?? 'Robotics Basics');
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    if (existing) {
      const { data } = await supabase
        .from('course_modules')
        .update({ title, description, category, updated_at: new Date().toISOString() })
        .eq('id', existing.id)
        .select()
        .single();
      if (data) onSaved(data);
    } else {
      const { data } = await supabase
        .from('course_modules')
        .insert({ teacher_id: teacherId, title, description, category })
        .select()
        .single();
      if (data) onSaved(data);
    }
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md animate-scale-in">
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="font-display font-bold text-xl text-gray-900">{existing ? 'Edit Module' : 'New Module'}</h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 transition-colors">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <form onSubmit={handleSave} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Module Title</label>
            <input value={title} onChange={e => setTitle(e.target.value)} className="input-field" placeholder="e.g. Week 1 – Getting Started" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Category</label>
            <select value={category} onChange={e => setCategory(e.target.value)} className="input-field">
              {CATEGORIES.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Description (optional)</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} className="input-field h-20 resize-none" placeholder="What's in this module?" />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="submit" disabled={saving} className="flex-1 btn-primary flex items-center justify-center gap-2">
              {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Check className="w-4 h-4" />}
              {existing ? 'Save Changes' : 'Create Module'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary px-5">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── File Edit Modal ───────────────────────────────────────────────────────────

interface FileEditModalProps {
  file: CourseFile;
  modules: CourseModule[];
  onClose: () => void;
  onSaved: (file: CourseFile) => void;
}

function FileEditModal({ file, modules, onClose, onSaved }: FileEditModalProps) {
  const [title, setTitle] = useState(file.title);
  const [description, setDescription] = useState(file.description ?? '');
  const [moduleId, setModuleId] = useState(file.module_id ?? '');
  const [visibility, setVisibility] = useState<'draft' | 'published'>(file.visibility);
  const [releaseDate, setReleaseDate] = useState(file.release_date ? file.release_date.slice(0, 10) : '');
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const { data } = await supabase
      .from('course_files')
      .update({
        title,
        description,
        module_id: moduleId || null,
        visibility,
        release_date: releaseDate || null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', file.id)
      .select()
      .single();
    if (data) onSaved(data);
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg animate-scale-in">
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <FileTypeIcon mimeType={file.file_type} size="sm" />
            <h2 className="font-display font-bold text-xl text-gray-900">Edit File</h2>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 transition-colors">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <form onSubmit={handleSave} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Title</label>
            <input value={title} onChange={e => setTitle(e.target.value)} className="input-field" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} className="input-field h-20 resize-none" placeholder="Brief description of this file…" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Module</label>
              <select value={moduleId} onChange={e => setModuleId(e.target.value)} className="input-field">
                <option value="">Uncategorised</option>
                {modules.map(m => <option key={m.id} value={m.id}>{m.title}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Visibility</label>
              <select value={visibility} onChange={e => setVisibility(e.target.value as 'draft' | 'published')} className="input-field">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">
              <Calendar className="w-3.5 h-3.5 inline mr-1" />
              Schedule Release Date (optional)
            </label>
            <input type="date" value={releaseDate} onChange={e => setReleaseDate(e.target.value)} className="input-field" />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="submit" disabled={saving} className="flex-1 btn-primary flex items-center justify-center gap-2">
              {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Check className="w-4 h-4" />}
              Save Changes
            </button>
            <button type="button" onClick={onClose} className="btn-secondary px-5">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ─── File Card ─────────────────────────────────────────────────────────────────

interface FileCardProps {
  file: CourseFile;
  viewMode: 'grid' | 'list';
  onEdit: (file: CourseFile) => void;
  onDelete: (id: string) => void;
  onDuplicate: (file: CourseFile) => void;
  onToggleVisibility: (file: CourseFile) => void;
}

function FileCard({ file, viewMode, onEdit, onDelete, onDuplicate, onToggleVisibility }: FileCardProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuItems = [
    { icon: Edit2, label: 'Edit Info', action: () => { onEdit(file); setMenuOpen(false); } },
    { icon: file.visibility === 'published' ? Lock : Globe, label: file.visibility === 'published' ? 'Set to Draft' : 'Publish', action: () => { onToggleVisibility(file); setMenuOpen(false); } },
    { icon: Copy, label: 'Duplicate', action: () => { onDuplicate(file); setMenuOpen(false); } },
    { icon: Download, label: 'Download', action: () => { if (file.file_url) window.open(file.file_url, '_blank'); setMenuOpen(false); } },
    { icon: Trash2, label: 'Delete', action: () => { onDelete(file.id); setMenuOpen(false); }, danger: true },
  ];

  if (viewMode === 'list') {
    return (
      <div className="flex items-center gap-4 p-4 hover:bg-gray-50 rounded-2xl transition-colors group">
        <GripVertical className="w-4 h-4 text-gray-200 group-hover:text-gray-400 cursor-grab flex-shrink-0" />
        <FileTypeIcon mimeType={file.file_type} size="sm" />
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-gray-900 text-sm truncate">{file.title}</p>
          <p className="text-xs text-gray-400">{file.file_name} · {formatFileSize(file.file_size)}</p>
        </div>
        <div className="hidden md:flex items-center gap-4 text-xs text-gray-400 flex-shrink-0">
          <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" />{file.view_count}</span>
          <span className="flex items-center gap-1"><Download className="w-3.5 h-3.5" />{file.download_count}</span>
        </div>
        {file.release_date && (
          <span className="hidden lg:flex items-center gap-1 text-xs text-blue-500 flex-shrink-0">
            <Calendar className="w-3.5 h-3.5" />
            {new Date(file.release_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </span>
        )}
        <span className={`badge flex-shrink-0 ${file.visibility === 'published' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
          {file.visibility === 'published' ? <Globe className="w-3 h-3 mr-1" /> : <Lock className="w-3 h-3 mr-1" />}
          {file.visibility}
        </span>
        <div className="relative flex-shrink-0">
          <button onClick={() => setMenuOpen(!menuOpen)} className="p-1.5 rounded-lg hover:bg-gray-200 transition-colors opacity-0 group-hover:opacity-100">
            <MoreVertical className="w-4 h-4 text-gray-500" />
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-8 bg-white rounded-2xl shadow-xl border border-gray-100 py-1.5 z-20 min-w-[160px] animate-scale-in">
              {menuItems.map(item => (
                <button key={item.label} onClick={item.action}
                  className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-sm transition-colors hover:bg-gray-50 ${item.danger ? 'text-red-500' : 'text-gray-700'}`}>
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="card hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200 overflow-hidden group relative">
      {/* Thumbnail / preview area */}
      <div className={`relative h-32 flex items-center justify-center ${getFileTypeInfo(file.file_type).bg}`}>
        <FileTypeIcon mimeType={file.file_type} size="lg" />
        <span className="absolute top-3 left-3 badge bg-black/40 text-white text-xs font-bold tracking-wider">{getFileExtLabel(file.file_type)}</span>
        <span className={`absolute top-3 right-3 badge ${file.visibility === 'published' ? 'bg-green-500 text-white' : 'bg-gray-400 text-white'}`}>
          {file.visibility === 'published' ? <Globe className="w-3 h-3 mr-1" /> : <Lock className="w-3 h-3 mr-1" />}
          {file.visibility}
        </span>
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100 gap-3">
          {file.file_url && (
            <a href={file.file_url} target="_blank" rel="noreferrer"
              className="w-9 h-9 bg-white rounded-xl flex items-center justify-center shadow-lg hover:scale-110 transition-transform" title="Preview">
              <Eye className="w-4 h-4 text-gray-700" />
            </a>
          )}
          <button onClick={() => onEdit(file)}
            className="w-9 h-9 bg-white rounded-xl flex items-center justify-center shadow-lg hover:scale-110 transition-transform" title="Edit">
            <Edit2 className="w-4 h-4 text-gray-700" />
          </button>
        </div>
      </div>

      <div className="p-4">
        <p className="font-semibold text-gray-900 text-sm truncate mb-0.5">{file.title}</p>
        {file.description && <p className="text-xs text-gray-400 line-clamp-1 mb-2">{file.description}</p>}
        <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
          <span>{formatFileSize(file.file_size)}</span>
          <span className="flex items-center gap-2">
            <span className="flex items-center gap-0.5"><Eye className="w-3 h-3" />{file.view_count}</span>
            <span className="flex items-center gap-0.5"><Download className="w-3 h-3" />{file.download_count}</span>
          </span>
        </div>
        {file.release_date && (
          <div className="flex items-center gap-1 text-xs text-blue-500 mb-3">
            <Calendar className="w-3 h-3" />
            Releases {new Date(file.release_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </div>
        )}
        {/* Actions */}
        <div className="flex gap-1.5">
          <button onClick={() => onEdit(file)} className="flex-1 py-1.5 bg-blue-50 text-blue-600 text-xs font-semibold rounded-xl hover:bg-blue-100 transition-colors flex items-center justify-center gap-1">
            <Edit2 className="w-3 h-3" /> Edit
          </button>
          <button onClick={() => onToggleVisibility(file)} className={`flex-1 py-1.5 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1 ${
            file.visibility === 'published' ? 'bg-green-50 text-green-600 hover:bg-green-100' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
          }`}>
            {file.visibility === 'published' ? <><Globe className="w-3 h-3" /> Live</> : <><Lock className="w-3 h-3" /> Draft</>}
          </button>
          <div className="relative">
            <button onClick={() => setMenuOpen(!menuOpen)} className="w-8 h-8 bg-gray-50 text-gray-500 rounded-xl hover:bg-gray-100 transition-colors flex items-center justify-center">
              <MoreVertical className="w-3.5 h-3.5" />
            </button>
            {menuOpen && (
              <div className="absolute right-0 bottom-9 bg-white rounded-2xl shadow-xl border border-gray-100 py-1.5 z-20 min-w-[150px] animate-scale-in">
                {menuItems.map(item => (
                  <button key={item.label} onClick={item.action}
                    className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-xs transition-colors hover:bg-gray-50 ${item.danger ? 'text-red-500' : 'text-gray-700'}`}>
                    <item.icon className="w-3.5 h-3.5" />
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────────

export default function TeacherCourses() {
  const { teacher } = useAuthStore();
  const [modules, setModules] = useState<CourseModule[]>([]);
  const [files, setFiles] = useState<CourseFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [_filterCategory, _setFilterCategory] = useState('All');
  const [filterVisibility, setFilterVisibility] = useState<'all' | 'draft' | 'published'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeModuleId, setActiveModuleId] = useState<string | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showModuleForm, setShowModuleForm] = useState(false);
  const [editingModule, setEditingModule] = useState<CourseModule | undefined>(undefined);
  const [editingFile, setEditingFile] = useState<CourseFile | undefined>(undefined);
  const [collapsedModules, setCollapsedModules] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!teacher) return;
    const fetchData = async () => {
      const [modRes, fileRes] = await Promise.all([
        supabase.from('course_modules').select('*').eq('teacher_id', teacher.id).order('order_index'),
        supabase.from('course_files').select('*').eq('teacher_id', teacher.id).order('order_index'),
      ]);
      if (modRes.data) setModules(modRes.data);
      if (fileRes.data) setFiles(fileRes.data);
      setLoading(false);
    };
    fetchData();
  }, [teacher]);

  // Derived filtered files
  const filteredFiles = files.filter(f => {
    const matchSearch = f.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (f.description ?? '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (f.file_name ?? '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchVis = filterVisibility === 'all' || f.visibility === filterVisibility;
    const matchModule = activeModuleId === null ? true : f.module_id === activeModuleId;
    return matchSearch && matchVis && matchModule;
  });

  const uncategorisedFiles = filteredFiles.filter(f => !f.module_id);
  const totalPublished = files.filter(f => f.visibility === 'published').length;
  const totalDraft = files.filter(f => f.visibility === 'draft').length;

  // Handlers
  const handleUploaded = (newFiles: CourseFile[]) => setFiles(prev => [...newFiles, ...prev]);

  const handleModuleSaved = (mod: CourseModule) => {
    setModules(prev => {
      const idx = prev.findIndex(m => m.id === mod.id);
      if (idx >= 0) { const next = [...prev]; next[idx] = mod; return next; }
      return [mod, ...prev];
    });
  };

  const handleFileSaved = (updated: CourseFile) => {
    setFiles(prev => prev.map(f => f.id === updated.id ? updated : f));
    setEditingFile(undefined);
  };

  const handleDeleteFile = async (id: string) => {
    if (!confirm('Delete this file?')) return;
    await supabase.from('course_files').delete().eq('id', id);
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const handleDeleteModule = async (id: string) => {
    if (!confirm('Delete this module? Files inside will become uncategorised.')) return;
    await supabase.from('course_modules').delete().eq('id', id);
    setModules(prev => prev.filter(m => m.id !== id));
    setFiles(prev => prev.map(f => f.module_id === id ? { ...f, module_id: null } : f));
    if (activeModuleId === id) setActiveModuleId(null);
  };

  const handleDuplicate = async (file: CourseFile) => {
    if (!teacher) return;
    const { data } = await supabase.from('course_files').insert({
      ...file,
      id: undefined,
      title: `${file.title} (copy)`,
      visibility: 'draft',
      view_count: 0,
      download_count: 0,
      created_at: undefined,
    }).select().single();
    if (data) setFiles(prev => [data, ...prev]);
  };

  const handleToggleVisibility = async (file: CourseFile) => {
    const newVis = file.visibility === 'published' ? 'draft' : 'published';
    await supabase.from('course_files').update({ visibility: newVis }).eq('id', file.id);
    setFiles(prev => prev.map(f => f.id === file.id ? { ...f, visibility: newVis } : f));
  };

  const toggleModuleCollapse = (id: string) => {
    setCollapsedModules(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  if (!teacher) return (
    <div className="flex items-center justify-center h-64">
      <p className="text-gray-400">Teacher profile not found.</p>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* ── Page Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-start gap-4">
        <div className="flex-1">
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Course File Manager</h1>
          <p className="text-gray-500 text-sm">Upload and organise your teaching materials into modules</p>
        </div>
        <div className="flex gap-3 flex-shrink-0">
          <button
            onClick={() => { setEditingModule(undefined); setShowModuleForm(true); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border-2 border-blue-200 text-blue-600 text-sm font-semibold hover:bg-blue-50 transition-all"
          >
            <FolderPlus className="w-4 h-4" /> New Module
          </button>
          <button
            onClick={() => setShowUploadModal(true)}
            className="bg-gradient-to-r from-purple-600 to-purple-700 text-white font-semibold rounded-2xl px-5 py-2.5 text-sm flex items-center gap-2 hover:shadow-glow transition-all"
          >
            <Upload className="w-4 h-4" /> Upload Files
          </button>
        </div>
      </div>

      {/* ── Stats Bar ── */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Files', value: files.length, icon: File, color: 'bg-purple-50 text-purple-600', iconBg: 'bg-purple-100' },
          { label: 'Published', value: totalPublished, icon: Globe, color: 'bg-green-50 text-green-600', iconBg: 'bg-green-100' },
          { label: 'Drafts', value: totalDraft, icon: Lock, color: 'bg-yellow-50 text-yellow-600', iconBg: 'bg-yellow-100' },
        ].map(s => (
          <div key={s.label} className={`card p-4 ${s.color}`}>
            <div className={`w-9 h-9 ${s.iconBg} rounded-xl flex items-center justify-center mb-2`}>
              <s.icon className="w-4 h-4" />
            </div>
            <div className="font-display font-bold text-2xl text-gray-900">{s.value}</div>
            <div className="text-xs font-medium text-gray-500">{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── Layout: Sidebar + Main ── */}
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Module Sidebar */}
        <div className="lg:w-56 xl:w-64 flex-shrink-0">
          <div className="card p-4">
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3 px-1">Modules</p>
            <div className="space-y-1">
              <button
                onClick={() => setActiveModuleId(null)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  activeModuleId === null ? 'bg-purple-600 text-white' : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <FolderOpen className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1 text-left">All Files</span>
                <span className={`text-xs rounded-full px-1.5 py-0.5 ${activeModuleId === null ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-500'}`}>{files.length}</span>
              </button>

              {modules.map(mod => {
                const count = files.filter(f => f.module_id === mod.id).length;
                const isActive = activeModuleId === mod.id;
                return (
                  <div key={mod.id} className="group relative">
                    <button
                      onClick={() => setActiveModuleId(mod.id)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                        isActive ? 'bg-purple-600 text-white' : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <FolderOpen className="w-4 h-4 flex-shrink-0" />
                      <span className="flex-1 text-left truncate">{mod.title}</span>
                      <span className={`text-xs rounded-full px-1.5 py-0.5 flex-shrink-0 ${isActive ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-500'}`}>{count}</span>
                    </button>
                    {/* Edit/Delete on hover */}
                    <div className="absolute right-1 top-1/2 -translate-y-1/2 hidden group-hover:flex items-center gap-0.5 bg-white rounded-lg shadow-sm border border-gray-100 p-0.5">
                      <button onClick={() => { setEditingModule(mod); setShowModuleForm(true); }} className="p-1 rounded hover:bg-gray-100 transition-colors" title="Edit">
                        <Edit2 className="w-3 h-3 text-gray-500" />
                      </button>
                      <button onClick={() => handleDeleteModule(mod.id)} className="p-1 rounded hover:bg-red-50 transition-colors" title="Delete">
                        <Trash2 className="w-3 h-3 text-red-400" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {modules.length === 0 && (
                <button
                  onClick={() => { setEditingModule(undefined); setShowModuleForm(true); }}
                  className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm text-gray-400 border-2 border-dashed border-gray-200 hover:border-purple-300 hover:text-purple-500 transition-all"
                >
                  <Plus className="w-4 h-4" /> Add first module
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {/* Search + Filters bar */}
          <div className="flex flex-col sm:flex-row gap-3 mb-5">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="input-field pl-11 py-2.5"
                placeholder="Search files by title or filename…"
              />
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <select
                value={filterVisibility}
                onChange={e => setFilterVisibility(e.target.value as 'all' | 'draft' | 'published')}
                className="input-field py-2.5 pr-8 text-sm"
              >
                <option value="all">All visibility</option>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
              </select>
              <div className="flex rounded-2xl border border-gray-200 overflow-hidden">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2.5 transition-colors ${viewMode === 'grid' ? 'bg-purple-600 text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
                  title="Grid view"
                >
                  <Grid3X3 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2.5 transition-colors ${viewMode === 'list' ? 'bg-purple-600 text-white' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
                  title="List view"
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Loading skeleton */}
          {loading && (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-56 bg-gray-100 rounded-3xl animate-pulse" />
              ))}
            </div>
          )}

          {/* Empty state */}
          {!loading && filteredFiles.length === 0 && (
            <div className="card p-16 text-center">
              <div className="w-20 h-20 bg-purple-50 rounded-3xl flex items-center justify-center mx-auto mb-4">
                <Upload className="w-10 h-10 text-purple-300" />
              </div>
              <h3 className="font-display font-bold text-xl text-gray-900 mb-2">
                {searchQuery || filterVisibility !== 'all' ? 'No files match your filters' : 'No files yet'}
              </h3>
              <p className="text-gray-400 text-sm mb-6 max-w-xs mx-auto">
                {searchQuery || filterVisibility !== 'all'
                  ? 'Try adjusting your search or filters.'
                  : 'Upload your first lesson file to get started. Supports PDF, MP4, PPTX, DOCX, XLSX, ZIP, and images.'}
              </p>
              {!searchQuery && filterVisibility === 'all' && (
                <button onClick={() => setShowUploadModal(true)} className="btn-primary inline-flex items-center gap-2">
                  <Upload className="w-4 h-4" /> Upload First File
                </button>
              )}
            </div>
          )}

          {/* File content grouped by module */}
          {!loading && filteredFiles.length > 0 && (
            <div className="space-y-6">
              {/* Show per-module groups only when "All Files" is active */}
              {activeModuleId === null ? (
                <>
                  {modules.map(mod => {
                    const modFiles = filteredFiles.filter(f => f.module_id === mod.id);
                    if (modFiles.length === 0) return null;
                    const collapsed = collapsedModules.has(mod.id);
                    return (
                      <div key={mod.id}>
                        <button
                          onClick={() => toggleModuleCollapse(mod.id)}
                          className="flex items-center gap-2 mb-3 group w-full text-left"
                        >
                          {collapsed ? <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-purple-500 transition-colors" /> : <ChevronDown className="w-4 h-4 text-gray-400 group-hover:text-purple-500 transition-colors" />}
                          <FolderOpen className="w-4 h-4 text-purple-500" />
                          <span className="font-display font-bold text-gray-800">{mod.title}</span>
                          <span className="badge bg-purple-100 text-purple-600 text-xs">{modFiles.length}</span>
                          {mod.category && <span className="badge bg-gray-100 text-gray-500 text-xs">{mod.category}</span>}
                        </button>
                        {!collapsed && (
                          viewMode === 'grid' ? (
                            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                              {modFiles.map(f => (
                                <FileCard key={f.id} file={f} viewMode="grid"
                                  onEdit={setEditingFile} onDelete={handleDeleteFile}
                                  onDuplicate={handleDuplicate} onToggleVisibility={handleToggleVisibility} />
                              ))}
                            </div>
                          ) : (
                            <div className="card overflow-hidden divide-y divide-gray-50">
                              {modFiles.map(f => (
                                <FileCard key={f.id} file={f} viewMode="list"
                                  onEdit={setEditingFile} onDelete={handleDeleteFile}
                                  onDuplicate={handleDuplicate} onToggleVisibility={handleToggleVisibility} />
                              ))}
                            </div>
                          )
                        )}
                      </div>
                    );
                  })}

                  {/* Uncategorised */}
                  {uncategorisedFiles.length > 0 && (
                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <FolderOpen className="w-4 h-4 text-gray-400" />
                        <span className="font-display font-bold text-gray-500">Uncategorised</span>
                        <span className="badge bg-gray-100 text-gray-500 text-xs">{uncategorisedFiles.length}</span>
                      </div>
                      {viewMode === 'grid' ? (
                        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                          {uncategorisedFiles.map(f => (
                            <FileCard key={f.id} file={f} viewMode="grid"
                              onEdit={setEditingFile} onDelete={handleDeleteFile}
                              onDuplicate={handleDuplicate} onToggleVisibility={handleToggleVisibility} />
                          ))}
                        </div>
                      ) : (
                        <div className="card overflow-hidden divide-y divide-gray-50">
                          {uncategorisedFiles.map(f => (
                            <FileCard key={f.id} file={f} viewMode="list"
                              onEdit={setEditingFile} onDelete={handleDeleteFile}
                              onDuplicate={handleDuplicate} onToggleVisibility={handleToggleVisibility} />
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </>
              ) : (
                /* Single module view */
                viewMode === 'grid' ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                    {filteredFiles.map(f => (
                      <FileCard key={f.id} file={f} viewMode="grid"
                        onEdit={setEditingFile} onDelete={handleDeleteFile}
                        onDuplicate={handleDuplicate} onToggleVisibility={handleToggleVisibility} />
                    ))}
                  </div>
                ) : (
                  <div className="card overflow-hidden divide-y divide-gray-50">
                    {filteredFiles.map(f => (
                      <FileCard key={f.id} file={f} viewMode="list"
                        onEdit={setEditingFile} onDelete={handleDeleteFile}
                        onDuplicate={handleDuplicate} onToggleVisibility={handleToggleVisibility} />
                    ))}
                  </div>
                )
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Modals ── */}
      {showUploadModal && (
        <UploadModal
          modules={modules}
          teacherId={teacher.id}
          onClose={() => setShowUploadModal(false)}
          onUploaded={handleUploaded}
        />
      )}

      {showModuleForm && (
        <ModuleFormModal
          teacherId={teacher.id}
          existing={editingModule}
          onClose={() => { setShowModuleForm(false); setEditingModule(undefined); }}
          onSaved={handleModuleSaved}
        />
      )}

      {editingFile && (
        <FileEditModal
          file={editingFile}
          modules={modules}
          onClose={() => setEditingFile(undefined)}
          onSaved={handleFileSaved}
        />
      )}
    </div>
  );
}
