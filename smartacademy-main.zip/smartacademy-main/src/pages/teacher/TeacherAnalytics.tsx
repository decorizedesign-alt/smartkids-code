import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const completionData = [
  { course: 'Intro Robotics', completion: 82 },
  { course: 'Sensors', completion: 67 },
  { course: 'AI for Kids', completion: 45 },
  { course: 'Arduino', completion: 91 },
];

const engagementData = [
  { week: 'W1', xp: 3200, logins: 18 },
  { week: 'W2', xp: 4100, logins: 22 },
  { week: 'W3', xp: 3800, logins: 20 },
  { week: 'W4', xp: 5200, logins: 24 },
];

const badgeData = [
  { name: 'Streak', value: 35, color: '#FACC15' },
  { name: 'Level', value: 28, color: '#8B5CF6' },
  { name: 'Project', value: 20, color: '#22d3ee' },
  { name: 'Quiz', value: 17, color: '#4ade80' },
];

export default function TeacherAnalytics() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Analytics</h1>
        <p className="text-gray-500">Track student performance and engagement</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Avg Completion', value: '71%', trend: '+5%', color: 'bg-purple-50', icon: '📈' },
          { label: 'Active Students', value: '21/24', trend: '+2', color: 'bg-blue-50', icon: '👥' },
          { label: 'Submissions', value: '47', trend: '+12 this week', color: 'bg-green-50', icon: '📝' },
          { label: 'Engagement Score', value: '8.4/10', trend: '+0.3', color: 'bg-yellow-50', icon: '⭐' },
        ].map(kpi => (
          <div key={kpi.label} className={`card p-5 ${kpi.color}`}>
            <div className="text-2xl mb-2">{kpi.icon}</div>
            <div className="font-display font-bold text-2xl text-gray-900">{kpi.value}</div>
            <div className="text-sm text-gray-700 font-medium">{kpi.label}</div>
            <div className="text-xs text-green-600 mt-1">{kpi.trend}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Course Completion */}
        <div className="card p-6">
          <h2 className="font-display font-bold text-xl text-gray-900 mb-5">Course Completion Rates</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={completionData} layout="vertical">
              <XAxis type="number" domain={[0, 100]} tickFormatter={v => `${v}%`} axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#9CA3AF' }} />
              <YAxis type="category" dataKey="course" width={90} axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#374151' }} />
              <Tooltip formatter={(v) => [`${v}%`, 'Completion']} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
              <Bar dataKey="completion" fill="#8B5CF6" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Engagement Trend */}
        <div className="card p-6">
          <h2 className="font-display font-bold text-xl text-gray-900 mb-5">Weekly Engagement</h2>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={engagementData}>
              <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#9CA3AF' }} />
              <YAxis hide />
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} />
              <Line type="monotone" dataKey="xp" name="Total XP" stroke="#8B5CF6" strokeWidth={3} dot={false} />
              <Line type="monotone" dataKey="logins" name="Logins" stroke="#FACC15" strokeWidth={3} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Badge Distribution */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-xl text-gray-900 mb-5">Badge Distribution</h2>
        <div className="flex flex-col md:flex-row items-center gap-8">
          <PieChart width={200} height={200}>
            <Pie data={badgeData} cx={100} cy={100} outerRadius={80} dataKey="value" paddingAngle={3}>
              {badgeData.map(entry => <Cell key={entry.name} fill={entry.color} />)}
            </Pie>
            <Tooltip formatter={(v, name) => [v, name]} contentStyle={{ borderRadius: '12px', border: 'none' }} />
          </PieChart>
          <div className="flex flex-col gap-3">
            {badgeData.map(item => (
              <div key={item.name} className="flex items-center gap-3">
                <div className="w-4 h-4 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                <div>
                  <p className="font-medium text-gray-900">{item.name} Badges</p>
                  <p className="text-sm text-gray-400">{item.value} earned</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
