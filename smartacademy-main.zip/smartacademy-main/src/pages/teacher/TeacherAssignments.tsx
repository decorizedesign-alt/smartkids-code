import { useState } from 'react';
import { ClipboardList, Plus, Check, Clock, AlertCircle } from 'lucide-react';

const mockAssignments = [
  { id: '1', title: 'Build a Traffic Light Circuit', due: '2025-06-25', submitted: 14, total: 18, graded: 10, course: 'Intro to Robotics' },
  { id: '2', title: 'Ultrasonic Sensor Project', due: '2025-06-28', submitted: 8, total: 12, graded: 3, course: 'Sensors & Control' },
  { id: '3', title: 'Robot Navigation Code', due: '2025-07-02', submitted: 2, total: 18, graded: 0, course: 'Intro to Robotics' },
];

const mockSubmissions = [
  { id: '1', student: 'Alex Johnson', avatar: 'A', color: 'bg-purple-400', assignment: 'Traffic Light Circuit', grade: 95, status: 'graded' },
  { id: '2', student: 'Maya Chen', avatar: 'M', color: 'bg-blue-400', assignment: 'Traffic Light Circuit', grade: null, status: 'submitted' },
  { id: '3', student: 'Sofia Garcia', avatar: 'S', color: 'bg-orange-400', assignment: 'Traffic Light Circuit', grade: 88, status: 'graded' },
  { id: '4', student: 'Liam Smith', avatar: 'L', color: 'bg-green-400', assignment: 'Ultrasonic Sensor', grade: null, status: 'submitted' },
];

export default function TeacherAssignments() {
  const [activeTab, setActiveTab] = useState<'assignments' | 'submissions'>('assignments');
  const [gradingId, setGradingId] = useState<string | null>(null);
  const [grade, setGrade] = useState('');

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Assignments</h1>
          <p className="text-gray-500">Manage and grade student work</p>
        </div>
        <button className="bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-2xl px-5 py-2.5 text-sm flex items-center gap-2 hover:shadow-lg transition-all">
          <Plus className="w-4 h-4" /> New Assignment
        </button>
      </div>

      <div className="flex gap-3 border-b border-gray-100 pb-0">
        {[['assignments', 'Assignments'], ['submissions', 'Submissions to Grade']].map(([tab, label]) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as 'assignments' | 'submissions')}
            className={`pb-3 px-1 text-sm font-semibold border-b-2 transition-all -mb-px ${
              activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {activeTab === 'assignments' ? (
        <div className="space-y-4">
          {mockAssignments.map(assignment => (
            <div key={assignment.id} className="card p-5">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-display font-bold text-gray-900">{assignment.title}</h3>
                    <span className="badge bg-blue-100 text-blue-600">{assignment.course}</span>
                  </div>
                  <p className="text-sm text-gray-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> Due {new Date(assignment.due).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
                  </p>
                </div>
                <div className="flex gap-4 text-center">
                  <div>
                    <p className="font-bold text-gray-900">{assignment.submitted}/{assignment.total}</p>
                    <p className="text-xs text-gray-400">Submitted</p>
                  </div>
                  <div>
                    <p className="font-bold text-green-600">{assignment.graded}</p>
                    <p className="text-xs text-gray-400">Graded</p>
                  </div>
                  <div>
                    <p className="font-bold text-orange-500">{assignment.submitted - assignment.graded}</p>
                    <p className="text-xs text-gray-400">Pending</p>
                  </div>
                </div>
              </div>
              <div className="mt-3">
                <div className="progress-bar">
                  <div className="h-full bg-gradient-to-r from-green-400 to-green-500 rounded-full" style={{ width: `${(assignment.submitted / assignment.total) * 100}%` }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {mockSubmissions.map(sub => (
            <div key={sub.id} className="card p-4 flex items-center gap-4">
              <div className={`w-10 h-10 ${sub.color} rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0`}>
                {sub.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900">{sub.student}</p>
                <p className="text-sm text-gray-500">{sub.assignment}</p>
              </div>
              {sub.status === 'graded' ? (
                <div className="flex items-center gap-2">
                  <span className="font-bold text-green-600">{sub.grade}/100</span>
                  <span className="badge bg-green-100 text-green-600"><Check className="w-3 h-3 mr-1" />Graded</span>
                </div>
              ) : gradingId === sub.id ? (
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    max={100}
                    min={0}
                    value={grade}
                    onChange={e => setGrade(e.target.value)}
                    className="input-field w-20 py-1.5 text-center text-sm"
                    placeholder="0-100"
                  />
                  <button onClick={() => setGradingId(null)} className="bg-blue-600 text-white text-xs font-semibold px-3 py-1.5 rounded-xl hover:bg-blue-700 transition-colors">
                    Save
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setGradingId(sub.id)}
                  className="bg-orange-50 text-orange-600 border border-orange-200 text-sm font-semibold px-4 py-2 rounded-xl hover:bg-orange-100 transition-colors flex items-center gap-1"
                >
                  <ClipboardList className="w-3.5 h-3.5" /> Grade
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
