import { useState } from 'react';
import { Video, Plus, Calendar, Clock, ExternalLink, Users } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';

const mockSessions = [
  { id: '1', title: 'Arduino Basics – Week 3', scheduled_at: new Date(Date.now() + 3600000 * 24).toISOString(), duration_minutes: 60, platform: 'zoom', status: 'scheduled', meeting_url: '#', attendees: 14 },
  { id: '2', title: 'Robot Arm Assembly Live', scheduled_at: new Date(Date.now() + 3600000 * 72).toISOString(), duration_minutes: 90, platform: 'google_meet', status: 'scheduled', meeting_url: '#', attendees: 18 },
  { id: '3', title: 'Sensor Lab Review', scheduled_at: new Date(Date.now() - 3600000 * 48).toISOString(), duration_minutes: 60, platform: 'zoom', status: 'ended', meeting_url: '#', attendees: 11 },
];

export default function TeacherLiveSessions() {
  const { teacher } = useAuthStore();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ title: '', date: '', time: '', duration: 60, platform: 'zoom' });
  const [submitting, setSubmitting] = useState(false);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!teacher) return;
    setSubmitting(true);
    const scheduled_at = new Date(`${formData.date}T${formData.time}`).toISOString();
    await supabase.from('live_sessions').insert({
      teacher_id: teacher.id,
      title: formData.title,
      scheduled_at,
      duration_minutes: formData.duration,
      platform: formData.platform,
      status: 'scheduled',
    });
    setShowForm(false);
    setSubmitting(false);
  };

  const statusColors: Record<string, string> = {
    scheduled: 'bg-yellow-100 text-yellow-700',
    live: 'bg-green-100 text-green-700',
    ended: 'bg-gray-100 text-gray-500',
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Live Sessions</h1>
          <p className="text-gray-500">Schedule and manage live classes</p>
        </div>
        <button onClick={() => setShowForm(true)} className="bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold rounded-2xl px-5 py-2.5 text-sm flex items-center gap-2 hover:shadow-lg transition-all">
          <Plus className="w-4 h-4" /> Schedule Session
        </button>
      </div>

      {showForm && (
        <div className="card p-6 border-2 border-blue-200 animate-scale-in">
          <h3 className="font-display font-bold text-lg text-gray-900 mb-4">Schedule New Session</h3>
          <form onSubmit={handleCreate} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Session Title</label>
              <input value={formData.title} onChange={e => setFormData(p => ({ ...p, title: e.target.value }))} className="input-field" placeholder="e.g. Robot Building Workshop" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Date</label>
              <input type="date" value={formData.date} onChange={e => setFormData(p => ({ ...p, date: e.target.value }))} className="input-field" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Time</label>
              <input type="time" value={formData.time} onChange={e => setFormData(p => ({ ...p, time: e.target.value }))} className="input-field" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Duration (minutes)</label>
              <input type="number" value={formData.duration} onChange={e => setFormData(p => ({ ...p, duration: Number(e.target.value) }))} className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Platform</label>
              <select value={formData.platform} onChange={e => setFormData(p => ({ ...p, platform: e.target.value }))} className="input-field">
                <option value="zoom">Zoom</option>
                <option value="google_meet">Google Meet</option>
              </select>
            </div>
            <div className="sm:col-span-2 flex gap-3">
              <button type="submit" disabled={submitting} className="bg-blue-600 text-white font-semibold rounded-2xl px-5 py-2.5 text-sm hover:bg-blue-700 transition-colors">
                {submitting ? 'Scheduling...' : 'Schedule Session'}
              </button>
              <button type="button" onClick={() => setShowForm(false)} className="btn-secondary text-sm">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {mockSessions.map(session => (
          <div key={session.id} className="card p-5">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 ${session.platform === 'zoom' ? 'bg-blue-100' : 'bg-green-100'} rounded-2xl flex items-center justify-center`}>
                <Video className={`w-6 h-6 ${session.platform === 'zoom' ? 'text-blue-600' : 'text-green-600'}`} />
              </div>
              <span className={`badge ${statusColors[session.status] ?? 'bg-gray-100'}`}>{session.status}</span>
            </div>
            <h3 className="font-display font-bold text-gray-900 mb-3">{session.title}</h3>
            <div className="space-y-2 text-sm text-gray-500 mb-4">
              <div className="flex items-center gap-2"><Calendar className="w-4 h-4" />{new Date(session.scheduled_at).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</div>
              <div className="flex items-center gap-2"><Clock className="w-4 h-4" />{new Date(session.scheduled_at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })} · {session.duration_minutes} min</div>
              <div className="flex items-center gap-2"><Users className="w-4 h-4" />{session.attendees} students attending</div>
            </div>
            {session.status !== 'ended' ? (
              <a href={session.meeting_url} target="_blank" rel="noreferrer"
                className="block w-full text-center py-2.5 rounded-2xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition-colors">
                {session.status === 'live' ? 'Join Live' : 'Start Session'} <ExternalLink className="w-3.5 h-3.5 inline ml-1" />
              </a>
            ) : (
              <button disabled className="w-full py-2.5 rounded-2xl bg-gray-100 text-gray-400 text-sm">Session Ended</button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
