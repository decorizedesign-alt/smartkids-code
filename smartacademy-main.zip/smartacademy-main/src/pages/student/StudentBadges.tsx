import { useEffect, useState } from 'react';
import { Trophy, Lock } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import type { StudentBadge, Badge } from '../../types';

const BADGE_EMOJIS: Record<string, string> = {
  'First Login': '👋', 'Circuit Explorer': '⚡', 'Sensor Builder': '🔧', 'Robo Inventor': '🤖',
  'AI Engineer': '🧠', 'Robotics Master': '🏆', 'First Course': '📚', '7-Day Streak': '🔥',
  '30-Day Streak': '🌟', 'Project Star': '⭐', 'Quiz Master': '🎯', 'Speed Learner': '🚀',
};

export default function StudentBadges() {
  const { student } = useAuthStore();
  const [earned, setEarned] = useState<StudentBadge[]>([]);
  const [allBadges, setAllBadges] = useState<Badge[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const [earnedRes, allRes] = await Promise.all([
        student ? supabase.from('student_badges').select('*, badge:badges(*)').eq('student_id', student.id) : Promise.resolve({ data: [] }),
        supabase.from('badges').select('*'),
      ]);
      if (earnedRes.data) setEarned(earnedRes.data);
      if (allRes.data) setAllBadges(allRes.data);
      setLoading(false);
    };
    fetchData();
  }, [student]);

  const earnedIds = new Set(earned.map(e => e.badge_id));

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">My Badges</h1>
        <p className="text-gray-500">Collect all badges by completing challenges</p>
      </div>

      {/* Earned Badges Count */}
      <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-3xl p-6 text-gray-900 flex items-center gap-6">
        <div className="text-5xl animate-bounce-slow">🏆</div>
        <div>
          <p className="font-display text-4xl font-extrabold">{earned.length}</p>
          <p className="font-semibold">Badges Earned</p>
          <p className="text-yellow-800 text-sm">{allBadges.length - earned.length} more to collect</p>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
          {Array.from({ length: 12 }).map((_, i) => <div key={i} className="h-24 bg-gray-100 rounded-3xl animate-pulse" />)}
        </div>
      ) : (
        <div>
          <h2 className="font-display font-bold text-lg text-gray-900 mb-4">All Badges</h2>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
            {allBadges.map(badge => {
              const isEarned = earnedIds.has(badge.id);
              const earnedDate = earned.find(e => e.badge_id === badge.id)?.earned_at;
              return (
                <div
                  key={badge.id}
                  className={`flex flex-col items-center gap-2 p-3 rounded-3xl text-center transition-all ${
                    isEarned
                      ? 'bg-gradient-to-br from-yellow-50 to-white border-2 border-yellow-300 shadow-sm hover:shadow-md hover:scale-105'
                      : 'bg-gray-50 border-2 border-dashed border-gray-200 opacity-50'
                  }`}
                >
                  <div className={`text-3xl ${!isEarned ? 'grayscale' : ''}`}>
                    {isEarned ? (BADGE_EMOJIS[badge.name] ?? '🏅') : <Lock className="w-6 h-6 text-gray-300" />}
                  </div>
                  <p className={`text-xs font-medium leading-tight ${isEarned ? 'text-gray-700' : 'text-gray-400'}`}>{badge.name}</p>
                  {isEarned && earnedDate && (
                    <p className="text-xs text-gray-400">{new Date(earnedDate).toLocaleDateString()}</p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
