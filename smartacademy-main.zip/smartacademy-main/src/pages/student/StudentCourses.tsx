import { useEffect, useState } from 'react';
import { BookOpen, Lock, Play, ChevronRight, Star } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import type { Course, Enrollment } from '../../types';
import { Link } from 'react-router-dom';

export default function StudentCourses() {
  const { student } = useAuthStore();
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [available, setAvailable] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!student) return;
      const [enrollRes, coursesRes] = await Promise.all([
        supabase.from('enrollments').select('*, course:courses(*)').eq('student_id', student.id),
        supabase.from('courses').select('*').eq('is_published', true).limit(6),
      ]);
      if (enrollRes.data) setEnrollments(enrollRes.data);
      if (coursesRes.data) setAvailable(coursesRes.data);
      setLoading(false);
    };
    fetchData();
  }, [student]);

  const thumbnails = [
    'https://images.pexels.com/photos/8566472/pexels-photo-8566472.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/8761753/pexels-photo-8761753.jpeg?auto=compress&cs=tinysrgb&w=400',
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">My Courses</h1>
        <p className="text-gray-500">Track your learning journey</p>
      </div>

      {/* Enrolled Courses */}
      <div>
        <h2 className="font-display font-bold text-lg text-gray-900 mb-4">In Progress</h2>
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2].map(i => <div key={i} className="h-32 bg-gray-100 rounded-3xl animate-pulse" />)}
          </div>
        ) : enrollments.length === 0 ? (
          <div className="card p-8 text-center">
            <BookOpen className="w-12 h-12 text-gray-200 mx-auto mb-3" />
            <p className="text-gray-500 mb-4">You haven't enrolled in any courses yet.</p>
            <Link to="/courses" className="btn-primary text-sm py-2 px-5">Browse Courses</Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {enrollments.map((enrollment, i) => {
              const course = enrollment.course as Course;
              return (
                <div key={enrollment.id} className="card-hover p-5 flex gap-4">
                  <img
                    src={thumbnails[i % thumbnails.length]}
                    alt="Course"
                    className="w-20 h-20 object-cover rounded-2xl flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate">{course?.title ?? 'Course'}</h3>
                    <div className="flex items-center gap-2 mt-1 mb-2">
                      <span className="badge bg-purple-100 text-purple-600 text-xs">Level {course?.difficulty_level}</span>
                    </div>
                    <div className="progress-bar mb-1">
                      <div className="progress-fill" style={{ width: `${enrollment.progress_percent}%` }} />
                    </div>
                    <p className="text-xs text-gray-400">{enrollment.progress_percent}% complete</p>
                  </div>
                  <button className="w-9 h-9 bg-purple-100 rounded-xl flex items-center justify-center text-purple-600 hover:bg-purple-200 transition-colors flex-shrink-0">
                    <Play className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Available Courses */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-lg text-gray-900">Available Courses</h2>
          <Link to="/courses" className="text-purple-600 text-sm font-medium flex items-center gap-1">
            All courses <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {available.length === 0 ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="card-hover overflow-hidden">
                <img src={thumbnails[i % thumbnails.length]} alt="Course" className="w-full h-40 object-cover" />
                <div className="p-4">
                  <span className="badge bg-purple-100 text-purple-600 mb-2 inline-block">Level {i + 1}</span>
                  <h3 className="font-semibold text-gray-900 mb-1">
                    {['Intro to Robotics', 'Sensors & Control', 'AI for Kids'][i]}
                  </h3>
                  <div className="flex items-center gap-1 mb-3">
                    {[1,2,3,4,5].map(s => <Star key={s} className="w-3 h-3 text-yellow-400 fill-yellow-400" />)}
                    <span className="text-xs text-gray-400 ml-1">4.9</span>
                  </div>
                  <button className="btn-primary w-full text-sm py-2">
                    {enrollments.some(() => false) ? 'Continue' : 'Enroll'}
                  </button>
                </div>
              </div>
            ))
          ) : (
            available.map((course, i) => (
              <div key={course.id} className="card-hover overflow-hidden">
                <img src={thumbnails[i % thumbnails.length]} alt={course.title} className="w-full h-40 object-cover" />
                <div className="p-4">
                  <span className="badge bg-purple-100 text-purple-600 mb-2 inline-block">Level {course.difficulty_level}</span>
                  <h3 className="font-semibold text-gray-900 mb-3">{course.title}</h3>
                  <button className="btn-primary w-full text-sm py-2">Enroll</button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
