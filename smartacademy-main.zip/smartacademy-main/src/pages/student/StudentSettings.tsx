import { useState } from 'react';
import { Bell, Shield } from 'lucide-react';

export default function StudentSettings() {
  const [notifications, setNotifications] = useState({ badges: true, liveClass: true, streak: true, messages: false });

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Settings</h1>
        <p className="text-gray-500">Manage your preferences</p>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-purple-100 rounded-2xl flex items-center justify-center">
            <Bell className="w-5 h-5 text-purple-600" />
          </div>
          <h2 className="font-display font-bold text-lg text-gray-900">Notifications</h2>
        </div>
        <div className="space-y-4">
          {(Object.entries(notifications) as [string, boolean][]).map(([key, value]) => {
            const labels: Record<string, { title: string; desc: string }> = {
              badges: { title: 'Badge Notifications', desc: 'When you earn a new badge' },
              liveClass: { title: 'Live Class Reminders', desc: 'Before scheduled live sessions' },
              streak: { title: 'Daily Streak Alerts', desc: 'Keep your streak alive' },
              messages: { title: 'Teacher Messages', desc: 'When teachers send messages' },
            };
            return (
              <div key={key} className="flex items-center justify-between py-3 border-b border-gray-50 last:border-0">
                <div>
                  <p className="font-medium text-gray-900">{labels[key]?.title}</p>
                  <p className="text-sm text-gray-500">{labels[key]?.desc}</p>
                </div>
                <button
                  onClick={() => setNotifications(prev => ({ ...prev, [key]: !value }))}
                  className={`relative w-12 h-6 rounded-full transition-colors ${value ? 'bg-purple-500' : 'bg-gray-200'}`}
                >
                  <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform shadow ${value ? 'translate-x-7' : 'translate-x-1'}`} />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      <div className="card p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-blue-100 rounded-2xl flex items-center justify-center">
            <Shield className="w-5 h-5 text-blue-600" />
          </div>
          <h2 className="font-display font-bold text-lg text-gray-900">Privacy & Safety</h2>
        </div>
        <div className="space-y-3">
          <p className="text-sm text-gray-600 bg-blue-50 rounded-2xl p-4">
            Your account is protected by your parent. Contact your parent to change privacy settings.
          </p>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <Shield className="w-4 h-4 text-green-500" />
            COPPA Compliant – Data is encrypted and protected
          </div>
        </div>
      </div>
    </div>
  );
}
