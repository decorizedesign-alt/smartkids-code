import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Zap, Star, Flame, Trophy, Video, BookOpen, Award, ChevronRight, Bot, Target } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';
import { STUDENT_LEVELS, type Enrollment, type LiveSession, type StudentBadge } from '../../types';

const AVATAR_COLORS = ['bg-green-400', 'bg-blue-500', 'bg-purple-500', 'bg-orange-400', 'bg-yellow-400'];

export default function StudentDashboard() {
  const { student, profile } = useAuthStore();
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [liveSessions, setLiveSessions] = useState<LiveSession[]>([]);
  const [badges, setBadges] = useState<StudentBadge[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!student) return;
    const fetchData = async () => {
      const [enrollRes, sessionsRes, badgesRes] = await Promise.all([
        supabase.from('enrollments').select('*, course:courses(*)').eq('student_id', student.id).limit(3),
        supabase.from('live_sessions').select('*').eq('status', 'scheduled').order('scheduled_at').limit(2),
        supabase.from('student_badges').select('*, badge:badges(*)').eq('student_id', student.id).limit(6),
      ]);
      if (enrollRes.data) setEnrollments(enrollRes.data);
      if (sessionsRes.data) setLiveSessions(sessionsRes.data);
      if (badgesRes.data) setBadges(badgesRes.data);
      setLoading(false);
    };
    fetchData();
  }, [student]);

  const levelInfo = STUDENT_LEVELS[(student?.current_level ?? 1) - 1];
  const nextLevel = STUDENT_LEVELS[student?.current_level ?? 1];
  const xpToNext = nextLevel ? nextLevel.minXP : 9999;
  const xpPercent = student ? Math.min(100, ((student.xp_points - levelInfo.minXP) / (xpToNext - levelInfo.minXP)) * 100) : 0;
  const avatarColor = AVATAR_COLORS[(student?.current_level ?? 1) - 1];

  const firstName = profile?.full_name?.split(' ')[0] ?? student?.username ?? 'Explorer';

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-600 via-purple-700 to-purple-900 p-6 md:p-8 text-white">
        <div className="absolute inset-0 bg-cyber-grid opacity-10" />
        <div className="absolute top-0 right-0 w-48 h-48 bg-yellow-400/10 rounded-full -translate-y-1/4 translate-x-1/4" />
        <div className="relative flex flex-col md:flex-row md:items-center gap-6">
          <div className={`w-20 h-20 ${avatarColor} rounded-3xl flex items-center justify-center text-white font-extrabold text-3xl shadow-lg flex-shrink-0`}>
            {firstName[0].toUpperCase()}
          </div>
          <div className="flex-1">
            <p className="text-purple-200 text-sm mb-1">Welcome back,</p>
            <h1 className="font-display text-2xl md:text-3xl font-extrabold mb-1">Hey {firstName}! 🤖</h1>
            <p className="text-purple-200 text-sm">{levelInfo.name} • {student?.xp_points ?? 0} XP total</p>
          </div>
          <div className="flex gap-4 md:flex-col md:items-end">
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur rounded-2xl px-4 py-2">
              <Flame className="w-5 h-5 text-yellow-400" />
              <span className="font-bold text-lg">{student?.streak_days ?? 0}</span>
              <span className="text-purple-200 text-sm">streak</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur rounded-2xl px-4 py-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span className="font-bold text-lg">{student?.xp_points ?? 0}</span>
              <span className="text-purple-200 text-sm">XP</span>
            </div>
          </div>
        </div>

        {/* XP Progress */}
        <div className="relative mt-6">
          <div className="flex justify-between text-xs text-purple-200 mb-2">
            <span>{levelInfo.name}</span>
            <span>{nextLevel ? `${xpToNext - (student?.xp_points ?? 0)} XP to ${nextLevel.name}` : 'Max Level!'}</span>
          </div>
          <div className="h-3 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full transition-all duration-1000"
              style={{ width: `${xpPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: BookOpen, label: 'Courses', value: enrollments.length, color: 'bg-blue-50 text-blue-600', bg: 'bg-blue-100' },
          { icon: Award, label: 'Badges', value: badges.length, color: 'bg-yellow-50 text-yellow-600', bg: 'bg-yellow-100' },
          { icon: Flame, label: 'Day Streak', value: student?.streak_days ?? 0, color: 'bg-orange-50 text-orange-600', bg: 'bg-orange-100' },
          { icon: Star, label: 'Level', value: student?.current_level ?? 1, color: 'bg-purple-50 text-purple-600', bg: 'bg-purple-100' },
        ].map(stat => (
          <div key={stat.label} className={`card p-5 ${stat.color}`}>
            <div className={`w-10 h-10 ${stat.bg} rounded-2xl flex items-center justify-center mb-3`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div className="font-display font-bold text-2xl text-gray-900">{stat.value}</div>
            <div className="text-sm text-gray-500 mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Continue Learning */}
        <div className="lg:col-span-2 card p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-display font-bold text-xl text-gray-900">Continue Learning</h2>
            <Link to="/student/courses" className="text-purple-600 text-sm font-medium flex items-center gap-1 hover:gap-2 transition-all">
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          {loading ? (
            <div className="space-y-3">
              {[1, 2].map(i => <div key={i} className="h-20 bg-gray-100 rounded-2xl animate-pulse" />)}
            </div>
          ) : enrollments.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-purple-50 rounded-3xl flex items-center justify-center mx-auto mb-3">
                <BookOpen className="w-8 h-8 text-purple-400" />
              </div>
              <p className="text-gray-500 mb-3">No courses yet</p>
              <Link to="/student/courses" className="btn-primary text-sm py-2 px-4">Browse Courses</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {enrollments.map(enrollment => (
                <div key={enrollment.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl hover:bg-purple-50 transition-colors group">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <BookOpen className="w-6 h-6 text-purple-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 truncate">{(enrollment.course as { title?: string })?.title ?? 'Course'}</p>
                    <div className="progress-bar mt-1.5">
                      <div className="progress-fill" style={{ width: `${enrollment.progress_percent}%` }} />
                    </div>
                    <p className="text-xs text-gray-400 mt-1">{enrollment.progress_percent}% complete</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-purple-400 transition-colors flex-shrink-0" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Live Class */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-display font-bold text-xl text-gray-900">Live Classes</h2>
            <Link to="/student/live-classes" className="text-purple-600 text-sm font-medium">
              See all
            </Link>
          </div>
          {liveSessions.length === 0 ? (
            <div className="text-center py-6">
              <Video className="w-10 h-10 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-400 text-sm">No upcoming classes</p>
            </div>
          ) : (
            <div className="space-y-3">
              {liveSessions.map(session => (
                <div key={session.id} className="bg-gradient-to-br from-purple-50 to-white rounded-2xl p-4 border border-purple-100">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-2 h-2 rounded-full ${session.status === 'live' ? 'bg-green-500 animate-pulse' : 'bg-yellow-400'}`} />
                    <span className={`text-xs font-semibold ${session.status === 'live' ? 'text-green-600' : 'text-yellow-600'}`}>
                      {session.status === 'live' ? 'LIVE NOW' : 'Upcoming'}
                    </span>
                  </div>
                  <p className="font-semibold text-gray-900 text-sm mb-1">{session.title}</p>
                  <p className="text-xs text-gray-400">
                    {new Date(session.scheduled_at).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </p>
                  {session.status === 'live' && session.meeting_url && (
                    <a href={session.meeting_url} target="_blank" rel="noreferrer" className="btn-primary text-xs py-2 px-4 mt-2 inline-block">
                      Join Now
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Badges */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display font-bold text-xl text-gray-900">My Badges</h2>
          <Link to="/student/badges" className="text-purple-600 text-sm font-medium flex items-center gap-1">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        {badges.length === 0 ? (
          <div className="text-center py-6">
            <Trophy className="w-10 h-10 text-gray-200 mx-auto mb-2" />
            <p className="text-gray-400 text-sm">Complete lessons to earn badges!</p>
          </div>
        ) : (
          <div className="flex gap-4 flex-wrap">
            {badges.map(sb => (
              <div key={sb.id} className="flex flex-col items-center gap-2 group">
                <div className="w-16 h-16 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-2xl flex items-center justify-center text-3xl border-2 border-yellow-300 group-hover:scale-110 transition-transform shadow-sm">
                  🏆
                </div>
                <p className="text-xs text-gray-500 text-center max-w-[64px] leading-tight">{(sb.badge as { name?: string })?.name}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* AI Robot Helper */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 rounded-3xl p-6 text-white relative overflow-hidden">
        <div className="absolute right-6 top-1/2 -translate-y-1/2 text-7xl animate-float opacity-20">🤖</div>
        <div className="relative">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-white/20 rounded-2xl flex items-center justify-center">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <p className="font-display font-bold">RoboAI Assistant</p>
              <p className="text-purple-200 text-xs">Your personal robotics helper</p>
            </div>
          </div>
          <p className="text-purple-100 text-sm mb-4 max-w-sm">Need help with your robot project? Ask RoboAI anything about circuits, coding, or building!</p>
          <button className="btn-yellow text-sm py-2 px-5">
            Ask RoboAI
          </button>
        </div>
      </div>
    </div>
  );
}
