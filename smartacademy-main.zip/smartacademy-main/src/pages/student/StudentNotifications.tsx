import { useEffect, useState } from 'react';
import { Bell, Check, CheckCheck } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import type { Notification } from '../../types';

const typeColors: Record<string, string> = {
  info: 'bg-blue-100 text-blue-600',
  success: 'bg-green-100 text-green-600',
  warning: 'bg-yellow-100 text-yellow-600',
  achievement: 'bg-yellow-100 text-yellow-600',
};

const mockNotifications: Notification[] = [
  { id: '1', user_id: '', title: 'New Badge Earned!', message: 'You earned the "7-Day Streak" badge. Keep it up!', type: 'achievement', is_read: false, created_at: new Date(Date.now() - 3600000).toISOString() },
  { id: '2', user_id: '', title: 'Live Class Tomorrow', message: 'Your "Arduino Basics" live class is scheduled for tomorrow at 4PM.', type: 'info', is_read: false, created_at: new Date(Date.now() - 7200000).toISOString() },
  { id: '3', user_id: '', title: 'Project Approved!', message: 'Your teacher approved your "Line Follower Robot" project. Great work!', type: 'success', is_read: true, created_at: new Date(Date.now() - 86400000).toISOString() },
];

export default function StudentNotifications() {
  const { profile } = useAuthStore();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    supabase.from('notifications').select('*').eq('user_id', profile.id).order('created_at', { ascending: false }).then(({ data }) => {
      setNotifications(data?.length ? data : mockNotifications);
      setLoading(false);
    });
  }, [profile]);

  const markAllRead = async () => {
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    if (profile) {
      await supabase.from('notifications').update({ is_read: true }).eq('user_id', profile.id);
    }
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Notifications</h1>
          <p className="text-gray-500">{unreadCount} unread</p>
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="flex items-center gap-2 text-sm text-purple-600 font-medium hover:text-purple-700">
            <CheckCheck className="w-4 h-4" /> Mark all read
          </button>
        )}
      </div>

      <div className="space-y-3">
        {notifications.map(notification => (
          <div
            key={notification.id}
            className={`card p-4 flex items-start gap-4 transition-all ${!notification.is_read ? 'border-l-4 border-purple-500' : ''}`}
          >
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 ${typeColors[notification.type] ?? 'bg-gray-100 text-gray-500'}`}>
              <Bell className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <p className={`font-semibold text-gray-900 ${!notification.is_read ? '' : 'font-medium'}`}>{notification.title}</p>
                {!notification.is_read && <span className="w-2 h-2 bg-purple-500 rounded-full flex-shrink-0 mt-2" />}
              </div>
              {notification.message && <p className="text-sm text-gray-500 mt-0.5 leading-relaxed">{notification.message}</p>}
              <p className="text-xs text-gray-400 mt-1.5">
                {new Date(notification.created_at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
