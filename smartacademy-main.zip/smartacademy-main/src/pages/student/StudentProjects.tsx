import { useEffect, useState } from 'react';
import { Plus, Folder, CheckCircle, XCircle, Clock } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import type { RobotProject } from '../../types';

export default function StudentProjects() {
  const { student } = useAuthStore();
  const [projects, setProjects] = useState<RobotProject[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!student) return;
    supabase.from('robot_projects').select('*').eq('student_id', student.id).order('created_at', { ascending: false }).then(({ data }) => {
      if (data) setProjects(data);
      setLoading(false);
    });
  }, [student]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!student) return;
    setSubmitting(true);
    const { data } = await supabase.from('robot_projects').insert({
      student_id: student.id,
      title,
      description,
      status: 'pending',
    }).select().single();
    if (data) setProjects(prev => [data, ...prev]);
    setTitle(''); setDescription(''); setShowForm(false);
    setSubmitting(false);
  };

  const statusConfig = {
    pending: { icon: Clock, color: 'text-yellow-500 bg-yellow-50', label: 'Pending Review' },
    approved: { icon: CheckCircle, color: 'text-green-500 bg-green-50', label: 'Approved' },
    rejected: { icon: XCircle, color: 'text-red-500 bg-red-50', label: 'Needs Revision' },
  };

  const projectImages = [
    'https://images.pexels.com/photos/8566472/pexels-photo-8566472.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/8438919/pexels-photo-8438919.jpeg?auto=compress&cs=tinysrgb&w=400',
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">My Projects</h1>
          <p className="text-gray-500">Showcase your robot creations</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4" /> New Project
        </button>
      </div>

      {showForm && (
        <div className="card p-6 border-2 border-purple-200 animate-scale-in">
          <h3 className="font-display font-bold text-lg text-gray-900 mb-4">Submit New Project</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Project Title</label>
              <input value={title} onChange={e => setTitle(e.target.value)} className="input-field" placeholder="My Awesome Robot" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Description</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} className="input-field h-24 resize-none" placeholder="Tell us about your project..." />
            </div>
            <div className="flex gap-3">
              <button type="submit" disabled={submitting} className="btn-primary flex items-center gap-2 text-sm">
                {submitting ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Submit Project'}
              </button>
              <button type="button" onClick={() => setShowForm(false)} className="btn-secondary text-sm">Cancel</button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1,2,3].map(i => <div key={i} className="h-64 bg-gray-100 rounded-3xl animate-pulse" />)}
        </div>
      ) : projects.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="text-6xl mb-4">🤖</div>
          <h3 className="font-display font-bold text-xl text-gray-900 mb-2">No projects yet!</h3>
          <p className="text-gray-500 mb-4">Submit your first robot project to get feedback from your teacher.</p>
          <button onClick={() => setShowForm(true)} className="btn-primary">Add First Project</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects.map((project, i) => {
            const status = statusConfig[project.status];
            return (
              <div key={project.id} className="card-hover overflow-hidden">
                <img
                  src={project.photo_url ?? projectImages[i % projectImages.length]}
                  alt={project.title}
                  className="w-full h-44 object-cover"
                />
                <div className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-display font-bold text-gray-900">{project.title}</h3>
                    <span className={`badge ${status.color}`}>
                      <status.icon className="w-3 h-3 mr-1" />
                      {status.label}
                    </span>
                  </div>
                  {project.description && <p className="text-gray-500 text-sm line-clamp-2 mb-3">{project.description}</p>}
                  {project.teacher_feedback && (
                    <div className="bg-blue-50 rounded-xl p-3 text-sm text-blue-700">
                      <p className="font-medium mb-0.5">Teacher feedback:</p>
                      {project.teacher_feedback}
                    </div>
                  )}
                  <p className="text-xs text-gray-400 mt-3">{new Date(project.created_at).toLocaleDateString()}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
