import { useEffect, useState } from 'react';
import { Video, Calendar, Clock, ExternalLink } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import type { LiveSession } from '../../types';

export default function StudentLiveClasses() {
  const [sessions, setSessions] = useState<LiveSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('live_sessions').select('*').order('scheduled_at').then(({ data }) => {
      if (data) setSessions(data);
      setLoading(false);
    });
  }, []);

  const statusColors: Record<string, string> = {
    scheduled: 'bg-yellow-100 text-yellow-700',
    live: 'bg-green-100 text-green-700',
    ended: 'bg-gray-100 text-gray-500',
    cancelled: 'bg-red-100 text-red-500',
  };

  const mockSessions = [
    { id: '1', title: 'Introduction to Arduino', scheduled_at: new Date(Date.now() + 3600000 * 24).toISOString(), duration_minutes: 60, platform: 'zoom' as const, status: 'scheduled' as const, meeting_url: '#', teacher_id: '', course_id: null, created_at: '' },
    { id: '2', title: 'Building Your First Robot Arm', scheduled_at: new Date(Date.now() + 3600000 * 48).toISOString(), duration_minutes: 90, platform: 'google_meet' as const, status: 'scheduled' as const, meeting_url: '#', teacher_id: '', course_id: null, created_at: '' },
    { id: '3', title: 'Sensor Lab: Ultrasonic Detectors', scheduled_at: new Date(Date.now() - 3600000 * 24).toISOString(), duration_minutes: 60, platform: 'zoom' as const, status: 'ended' as const, meeting_url: '#', teacher_id: '', course_id: null, created_at: '' },
  ];

  const displaySessions = sessions.length > 0 ? sessions : mockSessions;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Live Classes</h1>
        <p className="text-gray-500">Join real-time learning sessions with your teacher</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {displaySessions.map(session => (
          <div key={session.id} className="card p-5 hover:shadow-card-hover transition-all">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center">
                <Video className="w-6 h-6 text-purple-600" />
              </div>
              <span className={`badge ${statusColors[session.status] ?? 'bg-gray-100 text-gray-500'}`}>
                {session.status === 'live' && <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse inline-block mr-1" />}
                {session.status.charAt(0).toUpperCase() + session.status.slice(1)}
              </span>
            </div>
            <h3 className="font-display font-bold text-gray-900 mb-2">{session.title}</h3>
            <div className="space-y-2 text-sm text-gray-500 mb-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 flex-shrink-0" />
                {new Date(session.scheduled_at).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 flex-shrink-0" />
                {new Date(session.scheduled_at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })} · {session.duration_minutes} min
              </div>
              <div className="flex items-center gap-2">
                <span className={`badge ${session.platform === 'zoom' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600'}`}>
                  {session.platform === 'zoom' ? '🎥 Zoom' : '📹 Google Meet'}
                </span>
              </div>
            </div>
            {session.status === 'live' ? (
              <a href={session.meeting_url ?? '#'} target="_blank" rel="noreferrer"
                className="btn-primary w-full text-center text-sm py-2.5 flex items-center justify-center gap-2">
                Join Live Now <ExternalLink className="w-4 h-4" />
              </a>
            ) : session.status === 'scheduled' ? (
              <button className="btn-secondary w-full text-sm py-2.5">
                Add to Calendar
              </button>
            ) : (
              <button className="w-full py-2.5 rounded-2xl bg-gray-100 text-gray-400 text-sm" disabled>
                Session Ended
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
