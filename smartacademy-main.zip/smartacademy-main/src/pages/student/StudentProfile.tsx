import { useState } from 'react';
import { Camera, Edit2, Save, User } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';
import { STUDENT_LEVELS } from '../../types';

const AVATARS = ['🤖', '🚀', '🦁', '🐉', '⭐', '🎯', '💎', '🔥', '🌟', '🎮'];

export default function StudentProfile() {
  const { student, profile, setProfile } = useAuthStore();
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [saving, setSaving] = useState(false);

  const levelInfo = STUDENT_LEVELS[(student?.current_level ?? 1) - 1];
  const nextLevel = STUDENT_LEVELS[student?.current_level ?? 1];
  const xpPercent = student && nextLevel
    ? Math.min(100, ((student.xp_points - levelInfo.minXP) / (nextLevel.minXP - levelInfo.minXP)) * 100)
    : 100;

  const handleSave = async () => {
    if (!profile) return;
    setSaving(true);
    await supabase.from('profiles').update({ full_name: fullName }).eq('id', profile.id);
    setProfile({ ...profile, full_name: fullName });
    setEditing(false);
    setSaving(false);
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">My Profile</h1>
        <p className="text-gray-500">Your robotics identity</p>
      </div>

      {/* Profile Card */}
      <div className="card p-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <div className="relative">
            <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-purple-700 rounded-3xl flex items-center justify-center text-5xl shadow-glow">
              🤖
            </div>
            <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-white border-2 border-gray-200 rounded-xl flex items-center justify-center hover:bg-gray-50 transition-colors shadow-sm">
              <Camera className="w-4 h-4 text-gray-500" />
            </button>
          </div>
          <div className="flex-1 text-center sm:text-left">
            {editing ? (
              <div className="flex items-center gap-2 mb-2">
                <input
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="input-field text-lg font-bold py-2"
                />
                <button onClick={handleSave} disabled={saving} className="btn-primary text-sm py-2 px-4 flex items-center gap-1">
                  <Save className="w-4 h-4" /> Save
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 mb-1 justify-center sm:justify-start">
                <h2 className="font-display font-bold text-2xl text-gray-900">{profile?.full_name ?? student?.username}</h2>
                <button onClick={() => setEditing(true)} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
                  <Edit2 className="w-4 h-4 text-gray-400" />
                </button>
              </div>
            )}
            <p className="text-gray-500 text-sm mb-3">@{student?.username}</p>
            <div className="flex items-center gap-3 justify-center sm:justify-start flex-wrap">
              <span className={`badge ${levelInfo.bg} ${levelInfo.color}`}>{levelInfo.name}</span>
              <span className="badge bg-yellow-100 text-yellow-700">⚡ {student?.xp_points ?? 0} XP</span>
              <span className="badge bg-orange-100 text-orange-700">🔥 {student?.streak_days ?? 0} day streak</span>
            </div>
          </div>
        </div>
      </div>

      {/* Level Progress */}
      <div className="card p-6">
        <h3 className="font-display font-bold text-lg text-gray-900 mb-4">Level Progress</h3>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 ${levelInfo.bg} rounded-xl flex items-center justify-center`}>
              <span className={`text-sm font-bold ${levelInfo.color}`}>{student?.current_level}</span>
            </div>
            <span className="font-semibold text-gray-900">{levelInfo.name}</span>
          </div>
          {nextLevel && (
            <div className="text-right">
              <p className="text-xs text-gray-400">Next Level</p>
              <p className="font-semibold text-gray-900 text-sm">{nextLevel.name}</p>
            </div>
          )}
        </div>
        <div className="xp-bar mb-2">
          <div className="xp-fill" style={{ width: `${xpPercent}%` }} />
        </div>
        <p className="text-sm text-gray-500">
          {student?.xp_points} / {nextLevel?.minXP ?? '∞'} XP {nextLevel ? `(${nextLevel.minXP - (student?.xp_points ?? 0)} to go)` : ''}
        </p>
      </div>

      {/* Avatar Selection */}
      <div className="card p-6">
        <h3 className="font-display font-bold text-lg text-gray-900 mb-4">Choose Avatar</h3>
        <div className="grid grid-cols-5 gap-3">
          {AVATARS.map((avatar, i) => (
            <button
              key={i}
              className={`w-14 h-14 rounded-2xl text-2xl flex items-center justify-center transition-all hover:scale-110 ${
                i === 0 ? 'bg-purple-100 ring-2 ring-purple-500 ring-offset-2' : 'bg-gray-50 hover:bg-purple-50'
              }`}
            >
              {avatar}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
