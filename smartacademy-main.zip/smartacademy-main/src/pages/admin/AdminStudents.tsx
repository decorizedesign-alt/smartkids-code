import { useEffect, useState } from 'react';
import { Search, Trash2, TrendingUp, Award, Flame, Check } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { STUDENT_LEVELS } from '../../types';

interface StudentRow {
  id: string;
  user_id: string;
  username: string;
  current_level: number;
  xp_points: number;
  streak_days: number;
  created_at: string;
  profile?: { full_name: string | null; is_active: boolean };
}

export default function AdminStudents() {
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  useEffect(() => {
    supabase.from('students').select('*, profile:profiles(full_name, is_active)').order('created_at', { ascending: false }).then(({ data }) => {
      if (data) setStudents(data as unknown as StudentRow[]);
      setLoading(false);
    });
  }, []);

  const handleDelete = async (student: StudentRow) => {
    if (!confirm('Delete this student account? All progress will be lost.')) return;
    await supabase.from('students').delete().eq('id', student.id);
    await supabase.from('profiles').delete().eq('id', student.user_id);
    setStudents(prev => prev.filter(s => s.id !== student.id));
    showToast('Student removed');
  };

  const filtered = students.filter(s =>
    s.username.toLowerCase().includes(search.toLowerCase()) ||
    ((s.profile as { full_name?: string | null })?.full_name ?? '').toLowerCase().includes(search.toLowerCase())
  );

  const LEVEL_COLORS = ['', 'bg-green-500/20 text-green-400', 'bg-blue-500/20 text-blue-400', 'bg-purple-500/20 text-purple-400', 'bg-orange-500/20 text-orange-400', 'bg-yellow-500/20 text-yellow-400'];

  return (
    <div className="space-y-6 animate-fade-in">
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-green-500 text-white px-5 py-3 rounded-2xl shadow-lg animate-slide-up">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div>
        <h1 className="font-display text-2xl font-bold text-white mb-1">Student Management</h1>
        <p className="text-gray-500 text-sm">{students.length} students registered</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          className="w-full bg-gray-900 border border-white/10 text-white rounded-2xl pl-11 pr-4 py-2.5 text-sm focus:outline-none focus:border-purple-500 placeholder:text-gray-600"
          placeholder="Search students…" />
      </div>

      <div className="bg-gray-900 border border-white/5 rounded-3xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                {['Student', 'Level', 'XP', 'Streak', 'Status', 'Joined', 'Actions'].map(h => (
                  <th key={h} className="text-left px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading && Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>{Array.from({ length: 7 }).map((_, j) => (
                  <td key={j} className="px-5 py-4"><div className="h-4 bg-gray-800 rounded animate-pulse" /></td>
                ))}</tr>
              ))}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={7} className="text-center py-12 text-gray-600">No students found</td></tr>
              )}
              {!loading && filtered.map(student => {
                const profile = student.profile as { full_name?: string | null; is_active?: boolean } | undefined;
                const level = STUDENT_LEVELS[student.current_level - 1];
                return (
                  <tr key={student.id} className="hover:bg-white/2 transition-colors">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-purple-500/20 rounded-xl flex items-center justify-center text-purple-400 font-bold text-sm flex-shrink-0">
                          {student.username[0]?.toUpperCase()}
                        </div>
                        <div>
                          <p className="text-white text-sm font-medium">{profile?.full_name ?? student.username}</p>
                          <p className="text-gray-600 text-xs">@{student.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-xl ${LEVEL_COLORS[student.current_level]}`}>
                        Lv.{student.current_level} {level?.name}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-yellow-400 text-sm font-bold flex items-center gap-1">
                        <TrendingUp className="w-3.5 h-3.5" />{student.xp_points}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-orange-400 text-sm flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5" />{student.streak_days}d
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1 text-xs font-medium ${profile?.is_active ? 'text-green-400' : 'text-gray-500'}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${profile?.is_active ? 'bg-green-400' : 'bg-gray-600'}`} />
                        {profile?.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-gray-500 text-xs">
                      {new Date(student.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>
                    <td className="px-5 py-4">
                      <button onClick={() => handleDelete(student)} className="p-1.5 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
