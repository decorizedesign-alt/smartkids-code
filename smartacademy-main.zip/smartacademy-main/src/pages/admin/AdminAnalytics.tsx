import { useEffect, useState } from 'react';
import { Users, TrendingUp, BookOpen, CreditCard, Download } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell,
} from 'recharts';

const emptyMonths = ['Jan','Feb','Mar','Apr','May','Jun'].map(m => ({ month: m, value: 0 }));

const PIE_COLORS = ['#8B5CF6', '#22d3ee', '#4ade80', '#FACC15'];

export default function AdminAnalytics() {
  const [counts, setCounts] = useState({ students: 0, teachers: 0, parents: 0, files: 0, enrollments: 0, revenue: 0 });

  useEffect(() => {
    const fetchAll = async () => {
      const [sR, tR, pR, fR, eR, paR] = await Promise.all([
        supabase.from('students').select('id', { count: 'exact', head: true }),
        supabase.from('teachers').select('id', { count: 'exact', head: true }),
        supabase.from('parents').select('id', { count: 'exact', head: true }),
        supabase.from('course_files').select('id', { count: 'exact', head: true }),
        supabase.from('enrollments').select('id', { count: 'exact', head: true }),
        supabase.from('payments').select('amount').eq('status', 'completed'),
      ]);
      const revenue = (paR.data ?? []).reduce((s, p) => s + (p.amount ?? 0), 0);
      setCounts({ students: sR.count ?? 0, teachers: tR.count ?? 0, parents: pR.count ?? 0, files: fR.count ?? 0, enrollments: eR.count ?? 0, revenue });
    };
    fetchAll();
  }, []);

  const roleData = [
    { name: 'Students', value: counts.students || 1 },
    { name: 'Teachers', value: counts.teachers || 1 },
    { name: 'Parents', value: counts.parents || 1 },
    { name: 'Admins', value: 1 },
  ];

  const tooltipStyle = { borderRadius: '12px', border: 'none', backgroundColor: '#1f2937', color: '#f9fafb' };

  const kpis = [
    { label: 'Total Users', value: counts.students + counts.teachers + counts.parents, icon: Users, color: 'text-purple-400', bg: 'bg-purple-500/10' },
    { label: 'Enrollments', value: counts.enrollments, icon: TrendingUp, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { label: 'Uploaded Files', value: counts.files, icon: BookOpen, color: 'text-green-400', bg: 'bg-green-500/10' },
    { label: 'Revenue', value: `$${counts.revenue.toFixed(0)}`, icon: CreditCard, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white mb-1">Analytics</h1>
          <p className="text-gray-500 text-sm">Platform performance overview</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-white/10 text-gray-400 hover:text-white text-sm transition-colors">
          <Download className="w-4 h-4" /> Export Report
        </button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {kpis.map(k => (
          <div key={k.label} className={`${k.bg} rounded-2xl p-5 border border-white/5`}>
            <div className="w-9 h-9 bg-white/5 rounded-xl flex items-center justify-center mb-3">
              <k.icon className={`w-4 h-4 ${k.color}`} />
            </div>
            <div className={`font-display font-bold text-2xl ${k.color}`}>{k.value}</div>
            <div className="text-gray-500 text-xs mt-0.5">{k.label}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User Growth */}
        <div className="lg:col-span-2 bg-gray-900 border border-white/5 rounded-3xl p-6">
          <h2 className="font-display font-bold text-lg text-white mb-5">User Growth (Last 6 Months)</h2>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={emptyMonths}>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#6B7280' }} />
              <YAxis hide />
              <Tooltip contentStyle={tooltipStyle} />
              <Line type="monotone" dataKey="value" name="Users" stroke="#8B5CF6" strokeWidth={3} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Role Distribution */}
        <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
          <h2 className="font-display font-bold text-lg text-white mb-5">User Roles</h2>
          <PieChart width={180} height={180}>
            <Pie data={roleData} cx={90} cy={90} outerRadius={70} dataKey="value" paddingAngle={3}>
              {roleData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
            </Pie>
            <Tooltip contentStyle={tooltipStyle} />
          </PieChart>
          <div className="mt-3 space-y-1">
            {roleData.map((r, i) => (
              <div key={r.name} className="flex items-center gap-2 text-xs text-gray-400">
                <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: PIE_COLORS[i] }} />
                {r.name}: {r.value}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Revenue & Enrollments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
          <h2 className="font-display font-bold text-lg text-white mb-4">Monthly Revenue</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={emptyMonths}>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#6B7280' }} />
              <YAxis hide />
              <Tooltip contentStyle={tooltipStyle} formatter={v => [`$${v}`, 'Revenue']} />
              <Bar dataKey="value" name="Revenue" fill="#FACC15" radius={[6,6,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
          <h2 className="font-display font-bold text-lg text-white mb-4">Course Enrollments</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={emptyMonths}>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#6B7280' }} />
              <YAxis hide />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="value" name="Enrollments" fill="#22d3ee" radius={[6,6,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-purple-500/10 border border-purple-500/20 rounded-2xl px-5 py-4 text-sm text-purple-300">
        Charts will populate automatically as users sign up, enroll in courses, and make payments.
      </div>
    </div>
  );
}
