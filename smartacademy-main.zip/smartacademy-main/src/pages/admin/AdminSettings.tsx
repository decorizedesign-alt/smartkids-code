import { useEffect, useState } from 'react';
import { Save, Globe, Mail, Phone, MapPin, Palette, DollarSign, FileText, Link as LinkIcon, Check, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';

interface SiteSettings {
  platform_name: string;
  tagline: string;
  logo_url: string;
  primary_color: string;
  accent_color: string;
  contact_email: string;
  contact_phone: string;
  contact_address: string;
  social_twitter: string;
  social_facebook: string;
  social_instagram: string;
  social_youtube: string;
  homepage_hero_title: string;
  homepage_hero_subtitle: string;
  pricing_monthly_explorer: number;
  pricing_monthly_inventor: number;
  pricing_monthly_master: number;
  email_welcome_template: string;
}

const DEFAULT: SiteSettings = {
  platform_name: 'Smart Kids Academy', tagline: 'Learn • Build • Create • Innovate',
  logo_url: '', primary_color: '#8B5CF6', accent_color: '#FACC15',
  contact_email: 'hello@smartkidsacademy.com', contact_phone: '+1 (800) 555-ROBOT',
  contact_address: '123 Innovation Drive, Tech City',
  social_twitter: '', social_facebook: '', social_instagram: '', social_youtube: '',
  homepage_hero_title: 'Where Kids Build the Future',
  homepage_hero_subtitle: 'Interactive robotics courses, live teacher-led classes, real robot kits, and a gamified learning adventure for children ages 6-14.',
  pricing_monthly_explorer: 19, pricing_monthly_inventor: 39, pricing_monthly_master: 69,
  email_welcome_template: 'Welcome to Smart Kids Academy! We are thrilled to have you join us.',
};

export default function AdminSettings() {
  const { profile } = useAuthStore();
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState('');
  const [activeTab, setActiveTab] = useState<'general' | 'branding' | 'contact' | 'pricing' | 'social' | 'email'>('general');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  useEffect(() => {
    supabase.from('site_settings').select('*').eq('id', 1).maybeSingle().then(({ data }) => {
      if (data) setSettings({ ...DEFAULT, ...data });
      setLoading(false);
    });
  }, []);

  const handleSave = async () => {
    setSaving(true);
    await supabase.from('site_settings').update({ ...settings, updated_at: new Date().toISOString() }).eq('id', 1);
    if (profile) {
      await supabase.from('admin_activity_log').insert({
        admin_id: profile.id,
        action: `Updated site settings (tab: ${activeTab})`,
        target_type: 'site_settings',
      });
    }
    setSaving(false);
    showToast('Settings saved');
  };

  const set = (field: keyof SiteSettings, value: string | number) =>
    setSettings(prev => ({ ...prev, [field]: value }));

  const tabs = [
    { id: 'general', label: 'General', icon: Globe },
    { id: 'branding', label: 'Branding', icon: Palette },
    { id: 'contact', label: 'Contact', icon: Mail },
    { id: 'pricing', label: 'Pricing', icon: DollarSign },
    { id: 'social', label: 'Social Links', icon: LinkIcon },
    { id: 'email', label: 'Email Templates', icon: FileText },
  ] as const;

  const inputClass = "w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-500 placeholder:text-gray-600";
  const labelClass = "block text-sm font-medium text-gray-400 mb-1.5";

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl">
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-green-500 text-white px-5 py-3 rounded-2xl shadow-lg animate-slide-up">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white mb-1">Website Settings</h1>
          <p className="text-gray-500 text-sm">Customise your platform for your brand</p>
        </div>
        <button onClick={handleSave} disabled={saving} className="btn-primary flex items-center gap-2 flex-shrink-0">
          {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'Saving…' : 'Save Changes'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto scrollbar-hide bg-gray-900 border border-white/5 rounded-2xl p-1">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? 'bg-purple-600 text-white'
                : 'text-gray-500 hover:text-white'
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="bg-gray-900 border border-white/5 rounded-3xl p-6 space-y-5">
        {/* General */}
        {activeTab === 'general' && (
          <>
            <div>
              <label className={labelClass}>Platform Name</label>
              <input value={settings.platform_name} onChange={e => set('platform_name', e.target.value)} className={inputClass} placeholder="Smart Kids Academy" />
            </div>
            <div>
              <label className={labelClass}>Tagline</label>
              <input value={settings.tagline} onChange={e => set('tagline', e.target.value)} className={inputClass} placeholder="Learn • Build • Create • Innovate" />
            </div>
            <div>
              <label className={labelClass}>Homepage Hero Title</label>
              <input value={settings.homepage_hero_title} onChange={e => set('homepage_hero_title', e.target.value)} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Homepage Hero Subtitle</label>
              <textarea value={settings.homepage_hero_subtitle} onChange={e => set('homepage_hero_subtitle', e.target.value)} className={`${inputClass} h-24 resize-none`} />
            </div>
            <div>
              <label className={labelClass}>Logo URL</label>
              <input value={settings.logo_url} onChange={e => set('logo_url', e.target.value)} className={inputClass} placeholder="https://…/logo.png" />
            </div>
          </>
        )}

        {/* Branding */}
        {activeTab === 'branding' && (
          <>
            <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl text-blue-300 text-sm flex items-start gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              Color values are stored and can be referenced in future theme customisation. CSS variable injection requires a code deployment.
            </div>
            <div>
              <label className={labelClass}>Primary Color (Neon Purple)</label>
              <div className="flex gap-3 items-center">
                <input type="color" value={settings.primary_color} onChange={e => set('primary_color', e.target.value)} className="w-12 h-12 rounded-xl border border-white/10 cursor-pointer bg-transparent" />
                <input value={settings.primary_color} onChange={e => set('primary_color', e.target.value)} className={`${inputClass} flex-1`} placeholder="#8B5CF6" />
              </div>
            </div>
            <div>
              <label className={labelClass}>Accent Color (Electric Yellow)</label>
              <div className="flex gap-3 items-center">
                <input type="color" value={settings.accent_color} onChange={e => set('accent_color', e.target.value)} className="w-12 h-12 rounded-xl border border-white/10 cursor-pointer bg-transparent" />
                <input value={settings.accent_color} onChange={e => set('accent_color', e.target.value)} className={`${inputClass} flex-1`} placeholder="#FACC15" />
              </div>
            </div>
          </>
        )}

        {/* Contact */}
        {activeTab === 'contact' && (
          <>
            <div>
              <label className={labelClass}><Mail className="w-3.5 h-3.5 inline mr-1" />Contact Email</label>
              <input type="email" value={settings.contact_email} onChange={e => set('contact_email', e.target.value)} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}><Phone className="w-3.5 h-3.5 inline mr-1" />Contact Phone</label>
              <input value={settings.contact_phone} onChange={e => set('contact_phone', e.target.value)} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}><MapPin className="w-3.5 h-3.5 inline mr-1" />Address</label>
              <textarea value={settings.contact_address} onChange={e => set('contact_address', e.target.value)} className={`${inputClass} h-20 resize-none`} />
            </div>
          </>
        )}

        {/* Pricing */}
        {activeTab === 'pricing' && (
          <>
            {[
              { label: 'Explorer Plan ($/month)', field: 'pricing_monthly_explorer' as const },
              { label: 'Inventor Plan ($/month)', field: 'pricing_monthly_inventor' as const },
              { label: 'Master Plan ($/month)', field: 'pricing_monthly_master' as const },
            ].map(p => (
              <div key={p.field}>
                <label className={labelClass}>{p.label}</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm">$</span>
                  <input
                    type="number"
                    value={settings[p.field]}
                    onChange={e => set(p.field, Number(e.target.value))}
                    className={`${inputClass} pl-8`}
                    min={0}
                  />
                </div>
              </div>
            ))}
          </>
        )}

        {/* Social */}
        {activeTab === 'social' && (
          <>
            {[
              { label: 'Twitter / X', field: 'social_twitter' as const, placeholder: 'https://twitter.com/…' },
              { label: 'Facebook', field: 'social_facebook' as const, placeholder: 'https://facebook.com/…' },
              { label: 'Instagram', field: 'social_instagram' as const, placeholder: 'https://instagram.com/…' },
              { label: 'YouTube', field: 'social_youtube' as const, placeholder: 'https://youtube.com/…' },
            ].map(s => (
              <div key={s.field}>
                <label className={labelClass}>{s.label}</label>
                <input value={settings[s.field]} onChange={e => set(s.field, e.target.value)} className={inputClass} placeholder={s.placeholder} />
              </div>
            ))}
          </>
        )}

        {/* Email */}
        {activeTab === 'email' && (
          <div>
            <label className={labelClass}>Welcome Email Template</label>
            <textarea value={settings.email_welcome_template} onChange={e => set('email_welcome_template', e.target.value)} className={`${inputClass} h-40 resize-none`} placeholder="Welcome message sent to new users…" />
            <p className="text-xs text-gray-600 mt-2">This template is stored for reference. Email delivery requires an external email service integration.</p>
          </div>
        )}
      </div>
    </div>
  );
}
