import { useEffect, useState } from 'react';
import { Users, GraduationCap, BookOpen, TrendingUp, CreditCard, Package, Activity, UserCheck } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Link } from 'react-router-dom';

const revenueData = [
  { month: 'Jan', revenue: 0 }, { month: 'Feb', revenue: 0 }, { month: 'Mar', revenue: 0 },
  { month: 'Apr', revenue: 0 }, { month: 'May', revenue: 0 }, { month: 'Jun', revenue: 0 },
];

const userGrowthData = [
  { month: 'Jan', users: 0 }, { month: 'Feb', users: 0 }, { month: 'Mar', users: 0 },
  { month: 'Apr', users: 0 }, { month: 'May', users: 0 }, { month: 'Jun', users: 0 },
];

export default function AdminDashboard() {
  const [counts, setCounts] = useState({
    students: 0, teachers: 0, parents: 0, enrollments: 0,
    revenue: 0, activeUsers: 0, courses: 0, files: 0,
  });
  const [recentActivity, setRecentActivity] = useState<{ action: string; created_at: string }[]>([]);

  useEffect(() => {
    const fetchStats = async () => {
      const [studRes, teachRes, parRes, enrollRes, paymRes, courseRes, filesRes] = await Promise.all([
        supabase.from('students').select('id', { count: 'exact', head: true }),
        supabase.from('teachers').select('id', { count: 'exact', head: true }),
        supabase.from('parents').select('id', { count: 'exact', head: true }),
        supabase.from('enrollments').select('id', { count: 'exact', head: true }),
        supabase.from('payments').select('amount').eq('status', 'completed'),
        supabase.from('courses').select('id', { count: 'exact', head: true }),
        supabase.from('course_files').select('id', { count: 'exact', head: true }),
      ]);
      const revenue = (paymRes.data ?? []).reduce((s, p) => s + (p.amount ?? 0), 0);
      setCounts({
        students: studRes.count ?? 0,
        teachers: teachRes.count ?? 0,
        parents: parRes.count ?? 0,
        enrollments: enrollRes.count ?? 0,
        revenue,
        activeUsers: (studRes.count ?? 0) + (teachRes.count ?? 0) + (parRes.count ?? 0),
        courses: courseRes.count ?? 0,
        files: filesRes.count ?? 0,
      });
    };
    fetchStats();

    supabase.from('admin_activity_log').select('action,created_at').order('created_at', { ascending: false }).limit(8)
      .then(({ data }) => { if (data) setRecentActivity(data); });
  }, []);

  const statCards = [
    { icon: Users, label: 'Total Students', value: counts.students, color: 'bg-purple-500/10 text-purple-400', iconBg: 'bg-purple-500/20', href: '/admin/students' },
    { icon: GraduationCap, label: 'Total Teachers', value: counts.teachers, color: 'bg-blue-500/10 text-blue-400', iconBg: 'bg-blue-500/20', href: '/admin/teachers' },
    { icon: UserCheck, label: 'Total Parents', value: counts.parents, color: 'bg-green-500/10 text-green-400', iconBg: 'bg-green-500/20', href: '/admin/parents' },
    { icon: BookOpen, label: 'Courses & Files', value: counts.files, color: 'bg-orange-500/10 text-orange-400', iconBg: 'bg-orange-500/20', href: '/admin/courses' },
    { icon: TrendingUp, label: 'Enrollments', value: counts.enrollments, color: 'bg-cyan-500/10 text-cyan-400', iconBg: 'bg-cyan-500/20', href: '/admin/students' },
    { icon: CreditCard, label: 'Revenue', value: `$${counts.revenue.toLocaleString()}`, color: 'bg-emerald-500/10 text-emerald-400', iconBg: 'bg-emerald-500/20', href: '/admin/billing' },
    { icon: Activity, label: 'Active Users', value: counts.activeUsers, color: 'bg-pink-500/10 text-pink-400', iconBg: 'bg-pink-500/20', href: '/admin/users' },
    { icon: Package, label: 'Kits Shipped', value: 0, color: 'bg-yellow-500/10 text-yellow-400', iconBg: 'bg-yellow-500/20', href: '/admin/kits' },
  ];

  const tooltipStyle = { borderRadius: '12px', border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.4)', backgroundColor: '#1f2937', color: '#f9fafb' };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-display text-2xl font-bold text-white mb-1">Dashboard Overview</h1>
        <p className="text-gray-500 text-sm">Welcome to the Smart Kids Academy admin panel</p>
      </div>

      {/* Empty-state banner */}
      {counts.activeUsers === 0 && (
        <div className="bg-gradient-to-r from-purple-600/20 to-purple-800/20 border border-purple-500/30 rounded-3xl p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="text-4xl">🚀</div>
          <div className="flex-1">
            <p className="font-display font-bold text-white text-lg">Platform Ready for Launch</p>
            <p className="text-gray-400 text-sm mt-0.5">No users yet. Start by inviting teachers, then have parents register to create student accounts.</p>
          </div>
          <Link to="/admin/users" className="btn-primary text-sm py-2.5 flex-shrink-0">
            Manage Users
          </Link>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {statCards.map(card => (
          <Link
            key={card.label}
            to={card.href}
            className={`rounded-2xl p-4 md:p-5 ${card.color} border border-white/5 hover:border-white/10 transition-all hover:-translate-y-0.5 group`}
          >
            <div className={`w-9 h-9 ${card.iconBg} rounded-xl flex items-center justify-center mb-3`}>
              <card.icon className="w-4 h-4" />
            </div>
            <div className="font-display font-bold text-2xl text-white">{card.value}</div>
            <div className="text-xs text-gray-500 mt-0.5 font-medium">{card.label}</div>
          </Link>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
          <h2 className="font-display font-bold text-lg text-white mb-5">Revenue Overview</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={revenueData}>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#6B7280' }} />
              <YAxis hide />
              <Tooltip contentStyle={tooltipStyle} formatter={(v) => [`$${v}`, 'Revenue']} />
              <Bar dataKey="revenue" fill="#8B5CF6" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
          <h2 className="font-display font-bold text-lg text-white mb-5">User Growth</h2>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={userGrowthData}>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#6B7280' }} />
              <YAxis hide />
              <Tooltip contentStyle={tooltipStyle} />
              <Line type="monotone" dataKey="users" name="Users" stroke="#FACC15" strokeWidth={3} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
        <h2 className="font-display font-bold text-lg text-white mb-4">Recent Activity</h2>
        {recentActivity.length === 0 ? (
          <div className="text-center py-8">
            <Activity className="w-10 h-10 text-gray-700 mx-auto mb-2" />
            <p className="text-gray-600 text-sm">No activity yet. Actions you take will appear here.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {recentActivity.map((a, i) => (
              <div key={i} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
                <div className="w-2 h-2 bg-purple-500 rounded-full flex-shrink-0" />
                <p className="text-gray-300 text-sm flex-1">{a.action}</p>
                <p className="text-gray-600 text-xs flex-shrink-0">
                  {new Date(a.created_at).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
