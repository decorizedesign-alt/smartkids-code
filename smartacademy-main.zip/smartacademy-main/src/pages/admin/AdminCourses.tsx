import { useEffect, useState } from 'react';
import { Search, Globe, Lock, Trash2, Eye, FolderOpen, File, Check } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface FileRow {
  id: string;
  title: string;
  file_type: string | null;
  file_size: number;
  visibility: 'draft' | 'published';
  view_count: number;
  download_count: number;
  created_at: string;
  module?: { title: string } | null;
  teacher?: { profile: { full_name: string | null } | null } | null;
}

function formatFileSize(bytes: number) {
  if (!bytes) return '—';
  const k = 1024;
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${['B','KB','MB','GB'][i]}`;
}

export default function AdminCourses() {
  const [files, setFiles] = useState<FileRow[]>([]);
  const [modules, setModules] = useState<{ id: string; title: string; teacher_id: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [visFilter, setVisFilter] = useState<'all' | 'published' | 'draft'>('all');
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  useEffect(() => {
    Promise.all([
      supabase.from('course_files').select('*, module:course_modules(title)').order('created_at', { ascending: false }),
      supabase.from('course_modules').select('id, title, teacher_id').order('created_at'),
    ]).then(([filesRes, modRes]) => {
      if (filesRes.data) setFiles(filesRes.data as unknown as FileRow[]);
      if (modRes.data) setModules(modRes.data);
      setLoading(false);
    });
  }, []);

  const handleToggleVisibility = async (file: FileRow) => {
    const vis = file.visibility === 'published' ? 'draft' : 'published';
    await supabase.from('course_files').update({ visibility: vis }).eq('id', file.id);
    setFiles(prev => prev.map(f => f.id === file.id ? { ...f, visibility: vis } : f));
    showToast(`File ${vis === 'published' ? 'published' : 'set to draft'}`);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this file permanently?')) return;
    await supabase.from('course_files').delete().eq('id', id);
    setFiles(prev => prev.filter(f => f.id !== id));
    showToast('File deleted');
  };

  const filtered = files.filter(f => {
    const ms = f.title.toLowerCase().includes(search.toLowerCase());
    const mv = visFilter === 'all' || f.visibility === visFilter;
    return ms && mv;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-green-500 text-white px-5 py-3 rounded-2xl shadow-lg animate-slide-up">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white mb-1">Courses & Files</h1>
          <p className="text-gray-500 text-sm">{files.length} files · {modules.length} modules</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Files', value: files.length, color: 'text-purple-400', bg: 'bg-purple-500/10' },
          { label: 'Published', value: files.filter(f => f.visibility === 'published').length, color: 'text-green-400', bg: 'bg-green-500/10' },
          { label: 'Drafts', value: files.filter(f => f.visibility === 'draft').length, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-4 border border-white/5`}>
            <div className={`font-display font-bold text-2xl ${s.color}`}>{s.value}</div>
            <div className="text-gray-500 text-xs mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            className="w-full bg-gray-900 border border-white/10 text-white rounded-2xl pl-11 pr-4 py-2.5 text-sm focus:outline-none focus:border-purple-500 placeholder:text-gray-600"
            placeholder="Search files…" />
        </div>
        <div className="flex gap-2">
          {(['all', 'published', 'draft'] as const).map(v => (
            <button key={v} onClick={() => setVisFilter(v)}
              className={`px-4 py-2 rounded-xl text-sm font-medium capitalize transition-all ${visFilter === v ? 'bg-purple-600 text-white' : 'bg-gray-900 border border-white/10 text-gray-400 hover:border-purple-500'}`}>
              {v}
            </button>
          ))}
        </div>
      </div>

      {/* Modules */}
      {modules.length > 0 && (
        <div>
          <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Modules ({modules.length})</p>
          <div className="flex gap-3 flex-wrap">
            {modules.map(m => (
              <div key={m.id} className="flex items-center gap-2 bg-gray-900 border border-white/5 rounded-2xl px-4 py-2.5 text-sm text-gray-300">
                <FolderOpen className="w-4 h-4 text-purple-400" />
                {m.title}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Files Table */}
      <div className="bg-gray-900 border border-white/5 rounded-3xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                {['File', 'Module', 'Size', 'Views', 'Status', 'Actions'].map(h => (
                  <th key={h} className="text-left px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading && Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>{Array.from({ length: 6 }).map((_, j) => (
                  <td key={j} className="px-5 py-4"><div className="h-4 bg-gray-800 rounded animate-pulse" /></td>
                ))}</tr>
              ))}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={6} className="text-center py-12 text-gray-600">No files found</td></tr>
              )}
              {!loading && filtered.map(file => {
                const mod = file.module as { title?: string } | null;
                return (
                  <tr key={file.id} className="hover:bg-white/2 transition-colors">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <File className="w-4 h-4 text-gray-500 flex-shrink-0" />
                        <span className="text-white text-sm font-medium truncate max-w-[200px]">{file.title}</span>
                      </div>
                    </td>
                    <td className="px-5 py-4 text-gray-500 text-xs">{mod?.title ?? '—'}</td>
                    <td className="px-5 py-4 text-gray-500 text-xs">{formatFileSize(file.file_size)}</td>
                    <td className="px-5 py-4">
                      <span className="flex items-center gap-1 text-gray-400 text-xs">
                        <Eye className="w-3.5 h-3.5" />{file.view_count}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-full ${
                        file.visibility === 'published' ? 'bg-green-500/15 text-green-400' : 'bg-gray-500/15 text-gray-400'
                      }`}>
                        {file.visibility === 'published' ? <Globe className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                        {file.visibility}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex gap-1.5">
                        <button onClick={() => handleToggleVisibility(file)}
                          className={`p-1.5 rounded-lg transition-colors ${file.visibility === 'published' ? 'bg-yellow-500/10 text-yellow-400 hover:bg-yellow-500/20' : 'bg-green-500/10 text-green-400 hover:bg-green-500/20'}`}>
                          {file.visibility === 'published' ? <Lock className="w-3.5 h-3.5" /> : <Globe className="w-3.5 h-3.5" />}
                        </button>
                        <button onClick={() => handleDelete(file.id)} className="p-1.5 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
