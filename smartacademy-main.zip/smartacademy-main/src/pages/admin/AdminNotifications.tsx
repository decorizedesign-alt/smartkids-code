import { useState } from 'react';
import { Send, Bell, Users, GraduationCap, User, Megaphone, Check } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';

type Audience = 'all' | 'teachers' | 'students' | 'parents';

export default function AdminNotifications() {
  const { profile } = useAuthStore();
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [audience, setAudience] = useState<Audience>('all');
  const [type, setType] = useState('info');
  const [sending, setSending] = useState(false);
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  const audienceOptions = [
    { value: 'all', label: 'All Users', icon: Users },
    { value: 'teachers', label: 'Teachers Only', icon: GraduationCap },
    { value: 'students', label: 'Students Only', icon: User },
    { value: 'parents', label: 'Parents Only', icon: User },
  ];

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;
    setSending(true);

    try {
      // Fetch target user IDs based on audience
      let userIds: string[] = [];

      if (audience === 'all') {
        const { data } = await supabase.from('profiles').select('id').neq('role', 'admin');
        userIds = (data ?? []).map(d => d.id);
      } else if (audience === 'teachers') {
        const { data } = await supabase.from('profiles').select('id').eq('role', 'teacher');
        userIds = (data ?? []).map(d => d.id);
      } else if (audience === 'students') {
        const { data } = await supabase.from('profiles').select('id').eq('role', 'student');
        userIds = (data ?? []).map(d => d.id);
      } else if (audience === 'parents') {
        const { data } = await supabase.from('profiles').select('id').eq('role', 'parent');
        userIds = (data ?? []).map(d => d.id);
      }

      if (userIds.length > 0) {
        const rows = userIds.map(id => ({ user_id: id, title, message, type }));
        await supabase.from('notifications').insert(rows);
      }

      // Log admin action
      if (profile) {
        await supabase.from('admin_activity_log').insert({
          admin_id: profile.id,
          action: `Sent announcement "${title}" to ${audience} (${userIds.length} users)`,
          target_type: 'notification',
          details: { audience, userCount: userIds.length },
        });
      }

      showToast(`Announcement sent to ${userIds.length} users`);
      setTitle('');
      setMessage('');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl">
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-green-500 text-white px-5 py-3 rounded-2xl shadow-lg animate-slide-up">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div>
        <h1 className="font-display text-2xl font-bold text-white mb-1">Notification Center</h1>
        <p className="text-gray-500 text-sm">Send announcements and messages to platform users</p>
      </div>

      <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-purple-500/20 rounded-2xl flex items-center justify-center">
            <Megaphone className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h2 className="font-display font-bold text-lg text-white">Send Announcement</h2>
            <p className="text-gray-500 text-xs">Reach your audience instantly</p>
          </div>
        </div>

        <form onSubmit={handleSend} className="space-y-5">
          {/* Audience */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Send To</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {audienceOptions.map(opt => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setAudience(opt.value as Audience)}
                  className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl text-xs font-semibold transition-all border ${
                    audience === opt.value
                      ? 'bg-purple-600 border-purple-500 text-white'
                      : 'bg-gray-800 border-white/10 text-gray-400 hover:border-purple-500/50'
                  }`}
                >
                  <opt.icon className="w-4 h-4" />
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Type */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">Notification Type</label>
            <div className="flex gap-2 flex-wrap">
              {[
                { value: 'info', label: 'Info', color: 'bg-blue-500/20 text-blue-400' },
                { value: 'success', label: 'Success', color: 'bg-green-500/20 text-green-400' },
                { value: 'warning', label: 'Warning', color: 'bg-yellow-500/20 text-yellow-400' },
                { value: 'achievement', label: 'Achievement', color: 'bg-purple-500/20 text-purple-400' },
              ].map(t => (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setType(t.value)}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                    type === t.value ? t.color + ' ring-2 ring-white/20' : 'bg-gray-800 text-gray-500 hover:text-gray-300'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1.5">Title</label>
            <input
              value={title}
              onChange={e => setTitle(e.target.value)}
              required
              className="w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-purple-500 placeholder:text-gray-600"
              placeholder="e.g. New Course Available!"
            />
          </div>

          {/* Message */}
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1.5">Message</label>
            <textarea
              value={message}
              onChange={e => setMessage(e.target.value)}
              required
              rows={4}
              className="w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-purple-500 resize-none placeholder:text-gray-600"
              placeholder="Write your announcement here…"
            />
          </div>

          <button
            type="submit"
            disabled={sending || !title.trim() || !message.trim()}
            className="btn-primary flex items-center gap-2 disabled:opacity-60"
          >
            {sending
              ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              : <Send className="w-4 h-4" />
            }
            {sending ? 'Sending…' : 'Send Announcement'}
          </button>
        </form>
      </div>

      {/* Tips */}
      <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
        <h3 className="font-semibold text-white mb-3 text-sm">Tips</h3>
        <ul className="space-y-2 text-xs text-gray-500">
          <li className="flex items-start gap-2"><span className="text-purple-400 mt-0.5">•</span> Announcements are delivered instantly to all matching users' notification feeds</li>
          <li className="flex items-start gap-2"><span className="text-purple-400 mt-0.5">•</span> Use "Achievement" type for celebration messages to keep students motivated</li>
          <li className="flex items-start gap-2"><span className="text-purple-400 mt-0.5">•</span> New platform announcements are best sent to "All Users"</li>
        </ul>
      </div>
    </div>
  );
}
