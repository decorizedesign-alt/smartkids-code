import { useEffect, useState } from 'react';
import { Search, Trash2, Link as LinkIcon, CreditCard, Check } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface ParentRow {
  id: string;
  user_id: string;
  phone: string | null;
  created_at: string;
  profile?: { full_name: string | null; is_active: boolean };
  children?: { id: string; username: string }[];
  payments?: { amount: number; status: string }[];
}

export default function AdminParents() {
  const [parents, setParents] = useState<ParentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  useEffect(() => {
    supabase.from('parents')
      .select('*, profile:profiles(full_name, is_active), children:students(id, username), payments(amount, status)')
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        if (data) setParents(data as unknown as ParentRow[]);
        setLoading(false);
      });
  }, []);

  const handleDelete = async (parent: ParentRow) => {
    if (!confirm('Delete this parent account? Linked students will lose their parent link.')) return;
    await supabase.from('parents').delete().eq('id', parent.id);
    await supabase.from('profiles').delete().eq('id', parent.user_id);
    setParents(prev => prev.filter(p => p.id !== parent.id));
    showToast('Parent account removed');
  };

  const filtered = parents.filter(p =>
    ((p.profile as { full_name?: string | null })?.full_name ?? '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-green-500 text-white px-5 py-3 rounded-2xl shadow-lg animate-slide-up">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div>
        <h1 className="font-display text-2xl font-bold text-white mb-1">Parent Management</h1>
        <p className="text-gray-500 text-sm">{parents.length} parent accounts</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          className="w-full bg-gray-900 border border-white/10 text-white rounded-2xl pl-11 pr-4 py-2.5 text-sm focus:outline-none focus:border-purple-500 placeholder:text-gray-600"
          placeholder="Search parents…" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {loading && Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-40 bg-gray-900 border border-white/5 rounded-3xl animate-pulse" />
        ))}
        {!loading && filtered.length === 0 && (
          <div className="col-span-3 text-center py-16">
            <p className="text-gray-600">No parent accounts yet.</p>
          </div>
        )}
        {!loading && filtered.map(parent => {
          const profile = parent.profile as { full_name?: string | null; is_active?: boolean } | undefined;
          const children = (parent.children ?? []) as { id: string; username: string }[];
          const payments = (parent.payments ?? []) as { amount: number; status: string }[];
          const totalPaid = payments.filter(p => p.status === 'completed').reduce((s, p) => s + p.amount, 0);
          return (
            <div key={parent.id} className="bg-gray-900 border border-white/5 rounded-3xl p-5 hover:border-white/10 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-green-500/20 rounded-2xl flex items-center justify-center text-green-400 font-bold text-lg">
                    {(profile?.full_name ?? 'P')[0]?.toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-white">{profile?.full_name ?? 'Parent'}</p>
                    {parent.phone && <p className="text-xs text-gray-500">{parent.phone}</p>}
                  </div>
                </div>
                <span className={`w-2 h-2 rounded-full mt-2 ${profile?.is_active ? 'bg-green-400' : 'bg-gray-600'}`} />
              </div>

              <div className="flex gap-3 mb-4 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <LinkIcon className="w-3.5 h-3.5 text-blue-400" />
                  {children.length} child{children.length !== 1 ? 'ren' : ''}
                </span>
                <span className="flex items-center gap-1">
                  <CreditCard className="w-3.5 h-3.5 text-green-400" />
                  ${totalPaid} paid
                </span>
              </div>

              {children.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-4">
                  {children.map(c => (
                    <span key={c.id} className="text-xs bg-purple-500/10 text-purple-400 border border-purple-500/20 px-2 py-0.5 rounded-full">
                      @{c.username}
                    </span>
                  ))}
                </div>
              )}

              <button onClick={() => handleDelete(parent)} className="flex items-center gap-1.5 text-xs text-red-400 hover:text-red-300 transition-colors">
                <Trash2 className="w-3.5 h-3.5" /> Remove account
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
