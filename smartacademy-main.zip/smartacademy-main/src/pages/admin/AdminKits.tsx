import { useEffect, useState } from 'react';
import { Plus, Package, Truck, CheckCircle, Clock, Search, X, Check } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface KitRow {
  id: string;
  serial_number: string;
  name: string | null;
  student_id: string | null;
  created_at: string;
  shipment?: { status: string; tracking_number: string | null; carrier: string | null; estimated_delivery: string | null } | null;
  student?: { username: string } | null;
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  processing: { label: 'Processing', color: 'bg-yellow-500/15 text-yellow-400', icon: Clock },
  shipped: { label: 'Shipped', color: 'bg-blue-500/15 text-blue-400', icon: Truck },
  in_transit: { label: 'In Transit', color: 'bg-cyan-500/15 text-cyan-400', icon: Truck },
  delivered: { label: 'Delivered', color: 'bg-green-500/15 text-green-400', icon: CheckCircle },
  returned: { label: 'Returned', color: 'bg-red-500/15 text-red-400', icon: Package },
};

export default function AdminKits() {
  const [kits, setKits] = useState<KitRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ serial: '', name: '' });
  const [creating, setCreating] = useState(false);
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  useEffect(() => {
    supabase.from('physical_kits')
      .select('*, shipment:kit_shipments(status,tracking_number,carrier,estimated_delivery), student:students(username)')
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        if (data) setKits(data as unknown as KitRow[]);
        setLoading(false);
      });
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    const { data } = await supabase.from('physical_kits').insert({
      serial_number: form.serial,
      name: form.name,
    }).select().single();
    if (data) setKits(prev => [data as KitRow, ...prev]);
    setForm({ serial: '', name: '' });
    setShowForm(false);
    setCreating(false);
    showToast('Kit created');
  };

  const filtered = kits.filter(k =>
    (k.serial_number.toLowerCase().includes(search.toLowerCase())) ||
    ((k.name ?? '').toLowerCase().includes(search.toLowerCase())) ||
    ((k.student as { username?: string })?.username ?? '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-green-500 text-white px-5 py-3 rounded-2xl shadow-lg animate-slide-up">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white mb-1">Robotics Kit Management</h1>
          <p className="text-gray-500 text-sm">{kits.length} kits in inventory</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary text-sm flex items-center gap-2 flex-shrink-0">
          <Plus className="w-4 h-4" /> Create Kit
        </button>
      </div>

      {showForm && (
        <div className="bg-gray-900 border border-white/10 rounded-3xl p-6 animate-scale-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-bold text-lg text-white">New Robotics Kit</h3>
            <button onClick={() => setShowForm(false)} className="text-gray-500 hover:text-white"><X className="w-5 h-5" /></button>
          </div>
          <form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-400 mb-1.5">Serial Number</label>
              <input value={form.serial} onChange={e => setForm(p => ({ ...p, serial: e.target.value }))} required
                className="w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-500" placeholder="SKA-2025-001" />
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-400 mb-1.5">Kit Name</label>
              <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                className="w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-500" placeholder="Inventor Kit v2" />
            </div>
            <div className="flex items-end gap-2">
              <button type="submit" disabled={creating} className="btn-primary text-sm h-[44px] flex items-center gap-2">
                {creating ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Check className="w-4 h-4" />}
                Create
              </button>
              <button type="button" onClick={() => setShowForm(false)} className="h-[44px] px-4 rounded-2xl border border-white/10 text-gray-400 hover:text-white text-sm transition-colors">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="relative max-w-md">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          className="w-full bg-gray-900 border border-white/10 text-white rounded-2xl pl-11 pr-4 py-2.5 text-sm focus:outline-none focus:border-purple-500 placeholder:text-gray-600"
          placeholder="Search by serial, name, or student…" />
      </div>

      <div className="bg-gray-900 border border-white/5 rounded-3xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                {['Serial', 'Name', 'Assigned To', 'Tracking', 'Status', 'Est. Delivery'].map(h => (
                  <th key={h} className="text-left px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading && Array.from({ length: 4 }).map((_, i) => (
                <tr key={i}>{Array.from({ length: 6 }).map((_, j) => (
                  <td key={j} className="px-5 py-4"><div className="h-4 bg-gray-800 rounded animate-pulse" /></td>
                ))}</tr>
              ))}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={6} className="text-center py-12 text-gray-600">No kits yet. Create your first kit above.</td></tr>
              )}
              {!loading && filtered.map(kit => {
                const shipment = kit.shipment as { status?: string; tracking_number?: string | null; carrier?: string | null; estimated_delivery?: string | null } | null;
                const student = kit.student as { username?: string } | null;
                const statusCfg = STATUS_CONFIG[shipment?.status ?? ''] ?? STATUS_CONFIG.processing;
                const StatusIcon = statusCfg.icon;
                return (
                  <tr key={kit.id} className="hover:bg-white/2 transition-colors">
                    <td className="px-5 py-4 text-white text-sm font-mono">{kit.serial_number}</td>
                    <td className="px-5 py-4 text-gray-300 text-sm">{kit.name ?? '—'}</td>
                    <td className="px-5 py-4">
                      {student?.username ? (
                        <span className="text-purple-400 text-xs font-medium">@{student.username}</span>
                      ) : (
                        <span className="text-gray-600 text-xs">Unassigned</span>
                      )}
                    </td>
                    <td className="px-5 py-4 text-gray-500 text-xs font-mono">{shipment?.tracking_number ?? '—'}</td>
                    <td className="px-5 py-4">
                      {shipment ? (
                        <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full ${statusCfg.color}`}>
                          <StatusIcon className="w-3 h-3" />
                          {statusCfg.label}
                        </span>
                      ) : (
                        <span className="text-gray-600 text-xs">No shipment</span>
                      )}
                    </td>
                    <td className="px-5 py-4 text-gray-500 text-xs">
                      {shipment?.estimated_delivery
                        ? new Date(shipment.estimated_delivery).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
                        : '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
