import { useEffect, useState } from 'react';
import { Search, Plus, Edit2, Trash2, ToggleLeft, ToggleRight, RefreshCw, Shield, AlertCircle, Check, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface UserRow {
  id: string;
  full_name: string | null;
  role: string;
  is_active: boolean;
  created_at: string;
  email?: string;
}

function RoleBadge({ role }: { role: string }) {
  const map: Record<string, string> = {
    admin: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    teacher: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    student: 'bg-green-500/20 text-green-400 border-green-500/30',
    parent: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${map[role] ?? 'bg-gray-500/20 text-gray-400 border-gray-500/30'}`}>
      {role}
    </span>
  );
}

export default function AdminUsers() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState('');
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  useEffect(() => {
    supabase.from('profiles').select('*').order('created_at', { ascending: false }).then(({ data }) => {
      if (data) setUsers(data as UserRow[]);
      setLoading(false);
    });
  }, []);

  const filtered = users.filter(u => {
    const matchSearch = (u.full_name ?? '').toLowerCase().includes(search.toLowerCase()) ||
      u.role.includes(search.toLowerCase());
    const matchRole = roleFilter === 'all' || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  const handleToggleActive = async (user: UserRow) => {
    await supabase.from('profiles').update({ is_active: !user.is_active }).eq('id', user.id);
    setUsers(prev => prev.map(u => u.id === user.id ? { ...u, is_active: !u.is_active } : u));
    showToast(`Account ${!user.is_active ? 'activated' : 'deactivated'}`);
  };

  const handleStartEdit = (user: UserRow) => {
    setEditingId(user.id);
    setEditName(user.full_name ?? '');
    setEditRole(user.role);
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    setSaving(true);
    await supabase.from('profiles').update({ full_name: editName, role: editRole }).eq('id', editingId);
    setUsers(prev => prev.map(u => u.id === editingId ? { ...u, full_name: editName, role: editRole } : u));
    setEditingId(null);
    setSaving(false);
    showToast('User updated');
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this user permanently? This cannot be undone.')) return;
    await supabase.from('profiles').delete().eq('id', id);
    setUsers(prev => prev.filter(u => u.id !== id));
    showToast('User deleted');
  };

  const handleResetPassword = async (id: string) => {
    await supabase.from('profiles').update({ force_password_change: true }).eq('id', id);
    showToast('Password reset flag set. User must change password on next login.');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-green-500 text-white px-5 py-3 rounded-2xl shadow-lg animate-slide-up">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white mb-1">User Management</h1>
          <p className="text-gray-500 text-sm">{users.length} total accounts</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-gray-900 border border-white/10 text-white rounded-2xl pl-11 pr-4 py-2.5 text-sm focus:outline-none focus:border-purple-500 placeholder:text-gray-600"
            placeholder="Search by name or role…"
          />
        </div>
        <div className="flex gap-2">
          {['all', 'admin', 'teacher', 'student', 'parent'].map(r => (
            <button
              key={r}
              onClick={() => setRoleFilter(r)}
              className={`px-4 py-2 rounded-xl text-sm font-medium capitalize transition-all ${
                roleFilter === r
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-900 border border-white/10 text-gray-400 hover:border-purple-500'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-gray-900 border border-white/5 rounded-3xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                {['Name', 'Role', 'Status', 'Joined', 'Actions'].map(h => (
                  <th key={h} className="text-left px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading && Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  {Array.from({ length: 5 }).map((_, j) => (
                    <td key={j} className="px-5 py-4"><div className="h-4 bg-gray-800 rounded animate-pulse" /></td>
                  ))}
                </tr>
              ))}
              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-gray-600">
                    {search ? 'No users match your search' : 'No users found'}
                  </td>
                </tr>
              )}
              {!loading && filtered.map(user => (
                <tr key={user.id} className="hover:bg-white/2 transition-colors">
                  <td className="px-5 py-4">
                    {editingId === user.id ? (
                      <input
                        value={editName}
                        onChange={e => setEditName(e.target.value)}
                        className="bg-gray-800 border border-white/10 text-white rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:border-purple-500 w-36"
                      />
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-purple-500/20 rounded-xl flex items-center justify-center text-purple-400 font-bold text-sm flex-shrink-0">
                          {(user.full_name ?? '?')[0]?.toUpperCase()}
                        </div>
                        <span className="text-white text-sm font-medium">{user.full_name ?? '—'}</span>
                      </div>
                    )}
                  </td>
                  <td className="px-5 py-4">
                    {editingId === user.id ? (
                      <select
                        value={editRole}
                        onChange={e => setEditRole(e.target.value)}
                        className="bg-gray-800 border border-white/10 text-white rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:border-purple-500"
                      >
                        {['student', 'teacher', 'parent', 'admin'].map(r => <option key={r} value={r}>{r}</option>)}
                      </select>
                    ) : (
                      <RoleBadge role={user.role} />
                    )}
                  </td>
                  <td className="px-5 py-4">
                    <span className={`inline-flex items-center gap-1 text-xs font-medium ${user.is_active ? 'text-green-400' : 'text-gray-500'}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${user.is_active ? 'bg-green-400' : 'bg-gray-600'}`} />
                      {user.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-gray-500 text-xs">
                    {new Date(user.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                  </td>
                  <td className="px-5 py-4">
                    {editingId === user.id ? (
                      <div className="flex items-center gap-2">
                        <button onClick={handleSaveEdit} disabled={saving} className="p-1.5 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors">
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => setEditingId(null)} className="p-1.5 bg-gray-700 text-gray-400 rounded-lg hover:bg-gray-600 transition-colors">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <button onClick={() => handleStartEdit(user)} title="Edit" className="p-1.5 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500/20 transition-colors">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleToggleActive(user)} title={user.is_active ? 'Deactivate' : 'Activate'} className="p-1.5 bg-yellow-500/10 text-yellow-400 rounded-lg hover:bg-yellow-500/20 transition-colors">
                          {user.is_active ? <ToggleRight className="w-3.5 h-3.5" /> : <ToggleLeft className="w-3.5 h-3.5" />}
                        </button>
                        <button onClick={() => handleResetPassword(user.id)} title="Force password reset" className="p-1.5 bg-purple-500/10 text-purple-400 rounded-lg hover:bg-purple-500/20 transition-colors">
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>
                        {user.role !== 'admin' && (
                          <button onClick={() => handleDelete(user.id)} title="Delete" className="p-1.5 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
