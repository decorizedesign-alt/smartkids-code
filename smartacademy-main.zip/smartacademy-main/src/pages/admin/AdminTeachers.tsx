import { useEffect, useState } from 'react';
import { Search, Plus, Trash2, Eye, Star, Check, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface TeacherRow {
  id: string;
  user_id: string;
  bio: string | null;
  specialization: string | null;
  rating: number;
  total_students: number;
  created_at: string;
  profile?: { full_name: string | null; is_active: boolean };
}

export default function AdminTeachers() {
  const [teachers, setTeachers] = useState<TeacherRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ email: '', fullName: '', specialization: '', password: '' });
  const [creating, setCreating] = useState(false);
  const [toast, setToast] = useState('');

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  const fetchTeachers = async () => {
    const { data } = await supabase
      .from('teachers')
      .select('*, profile:profiles(full_name, is_active)')
      .order('created_at', { ascending: false });
    if (data) setTeachers(data as unknown as TeacherRow[]);
    setLoading(false);
  };

  useEffect(() => { fetchTeachers(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    try {
      const { data: auth, error } = await supabase.auth.admin
        ? (await (supabase.auth as unknown as { admin: { createUser: (p: unknown) => Promise<{ data: { user?: { id: string } } | null; error: unknown }> } }).admin.createUser({
            email: form.email,
            password: form.password,
            email_confirm: true,
            user_metadata: { full_name: form.fullName },
          }))
        : { data: null, error: new Error('Admin API not available in client') };

      if (error || !auth?.user) {
        // Fallback: use signUp
        const { data: su } = await supabase.auth.signUp({ email: form.email, password: form.password });
        if (su.user) {
          await supabase.from('profiles').insert({ id: su.user.id, role: 'teacher', full_name: form.fullName });
          await supabase.from('teachers').insert({ user_id: su.user.id, specialization: form.specialization });
          showToast('Teacher account created (email confirmation may be required)');
        }
      } else {
        await supabase.from('profiles').insert({ id: auth.user.id, role: 'teacher', full_name: form.fullName });
        await supabase.from('teachers').insert({ user_id: auth.user.id, specialization: form.specialization });
        showToast('Teacher created successfully');
      }
      setShowForm(false);
      setForm({ email: '', fullName: '', specialization: '', password: '' });
      fetchTeachers();
    } catch {
      showToast('Failed to create teacher. Check email format.');
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (teacher: TeacherRow) => {
    if (!confirm('Remove this teacher? Their files will be preserved.')) return;
    await supabase.from('teachers').delete().eq('id', teacher.id);
    await supabase.from('profiles').delete().eq('id', teacher.user_id);
    setTeachers(prev => prev.filter(t => t.id !== teacher.id));
    showToast('Teacher removed');
  };

  const filtered = teachers.filter(t =>
    ((t.profile as { full_name?: string | null })?.full_name ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (t.specialization ?? '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {toast && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 bg-green-500 text-white px-5 py-3 rounded-2xl shadow-lg animate-slide-up">
          <Check className="w-4 h-4" /> {toast}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white mb-1">Teacher Management</h1>
          <p className="text-gray-500 text-sm">{teachers.length} teachers registered</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary text-sm flex items-center gap-2 flex-shrink-0">
          <Plus className="w-4 h-4" /> Add Teacher
        </button>
      </div>

      {showForm && (
        <div className="bg-gray-900 border border-white/10 rounded-3xl p-6 animate-scale-in">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-display font-bold text-lg text-white">New Teacher Account</h3>
            <button onClick={() => setShowForm(false)} className="text-gray-500 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
          </div>
          <form onSubmit={handleCreate} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1.5">Full Name</label>
              <input value={form.fullName} onChange={e => setForm(p => ({ ...p, fullName: e.target.value }))} required
                className="w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-500" placeholder="Jane Smith" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1.5">Email</label>
              <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} required
                className="w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-500" placeholder="teacher@school.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1.5">Specialization</label>
              <input value={form.specialization} onChange={e => setForm(p => ({ ...p, specialization: e.target.value }))}
                className="w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-500" placeholder="Robotics & Arduino" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1.5">Temporary Password</label>
              <input type="password" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} required minLength={8}
                className="w-full bg-gray-800 border border-white/10 text-white rounded-2xl px-4 py-2.5 text-sm focus:outline-none focus:border-purple-500" placeholder="Min. 8 characters" />
            </div>
            <div className="sm:col-span-2 flex gap-3">
              <button type="submit" disabled={creating} className="btn-primary text-sm flex items-center gap-2">
                {creating ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Check className="w-4 h-4" />}
                Create Teacher
              </button>
              <button type="button" onClick={() => setShowForm(false)} className="px-5 py-2.5 rounded-2xl border border-white/10 text-gray-400 hover:text-white text-sm transition-colors">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 w-4 h-4" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          className="w-full bg-gray-900 border border-white/10 text-white rounded-2xl pl-11 pr-4 py-2.5 text-sm focus:outline-none focus:border-purple-500 max-w-md placeholder:text-gray-600"
          placeholder="Search teachers…" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {loading && Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-40 bg-gray-900 border border-white/5 rounded-3xl animate-pulse" />
        ))}
        {!loading && filtered.length === 0 && (
          <div className="col-span-3 text-center py-16">
            <p className="text-gray-600">No teachers yet. Add your first teacher above.</p>
          </div>
        )}
        {!loading && filtered.map(teacher => {
          const profile = teacher.profile as { full_name?: string | null; is_active?: boolean } | undefined;
          return (
            <div key={teacher.id} className="bg-gray-900 border border-white/5 rounded-3xl p-5 hover:border-white/10 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-blue-500/20 rounded-2xl flex items-center justify-center text-blue-400 font-bold text-lg">
                    {(profile?.full_name ?? 'T')[0]?.toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-white">{profile?.full_name ?? 'Teacher'}</p>
                    <p className="text-xs text-gray-500">{teacher.specialization ?? 'No specialization'}</p>
                  </div>
                </div>
                <span className={`w-2 h-2 rounded-full mt-2 ${profile?.is_active ? 'bg-green-400' : 'bg-gray-600'}`} />
              </div>
              <div className="flex items-center gap-3 text-sm text-gray-500 mb-4">
                <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-yellow-400" />{teacher.rating}</span>
                <span>{teacher.total_students} students</span>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 py-2 bg-blue-500/10 text-blue-400 rounded-xl text-xs font-semibold hover:bg-blue-500/20 transition-colors flex items-center justify-center gap-1">
                  <Eye className="w-3.5 h-3.5" /> View Files
                </button>
                <button onClick={() => handleDelete(teacher)} className="p-2 bg-red-500/10 text-red-400 rounded-xl hover:bg-red-500/20 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
