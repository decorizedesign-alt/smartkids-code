import { useEffect, useState } from 'react';
import { CreditCard, TrendingUp, Download, Search } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface PaymentRow {
  id: string;
  parent_id: string;
  amount: number;
  currency: string;
  status: string;
  payment_method: string | null;
  description: string | null;
  created_at: string;
}
interface SubRow {
  id: string;
  plan: string;
  status: string;
  amount: number | null;
  started_at: string;
  expires_at: string | null;
}

const monthlyRevenue = Array.from({ length: 6 }, (_, i) => ({
  month: ['Jan','Feb','Mar','Apr','May','Jun'][i],
  revenue: 0,
}));

export default function AdminBilling() {
  const [payments, setPayments] = useState<PaymentRow[]>([]);
  const [subs, setSubs] = useState<SubRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    Promise.all([
      supabase.from('payments').select('*').order('created_at', { ascending: false }),
      supabase.from('subscriptions').select('*').order('started_at', { ascending: false }),
    ]).then(([pRes, sRes]) => {
      if (pRes.data) setPayments(pRes.data);
      if (sRes.data) setSubs(sRes.data);
      setLoading(false);
    });
  }, []);

  const totalRevenue = payments.filter(p => p.status === 'completed').reduce((s, p) => s + p.amount, 0);
  const activeSubs = subs.filter(s => s.status === 'active').length;

  const statusColor: Record<string, string> = {
    completed: 'bg-green-500/15 text-green-400',
    pending: 'bg-yellow-500/15 text-yellow-400',
    failed: 'bg-red-500/15 text-red-400',
    refunded: 'bg-gray-500/15 text-gray-400',
  };
  const subStatusColor: Record<string, string> = {
    active: 'bg-green-500/15 text-green-400',
    cancelled: 'bg-red-500/15 text-red-400',
    expired: 'bg-gray-500/15 text-gray-400',
  };

  const filtered = payments.filter(p =>
    (p.description ?? '').toLowerCase().includes(search.toLowerCase()) || p.status.includes(search.toLowerCase())
  );

  const tooltipStyle = { borderRadius: '12px', border: 'none', backgroundColor: '#1f2937', color: '#f9fafb' };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white mb-1">Billing Management</h1>
          <p className="text-gray-500 text-sm">Payment history and subscription overview</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-white/10 text-gray-400 hover:text-white text-sm transition-colors">
          <Download className="w-4 h-4" /> Export CSV
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Revenue', value: `$${totalRevenue.toFixed(2)}`, color: 'text-green-400', bg: 'bg-green-500/10' },
          { label: 'Active Subs', value: activeSubs, color: 'text-purple-400', bg: 'bg-purple-500/10' },
          { label: 'Total Payments', value: payments.length, color: 'text-blue-400', bg: 'bg-blue-500/10' },
          { label: 'Failed Payments', value: payments.filter(p => p.status === 'failed').length, color: 'text-red-400', bg: 'bg-red-500/10' },
        ].map(s => (
          <div key={s.label} className={`${s.bg} rounded-2xl p-4 border border-white/5`}>
            <div className={`font-display font-bold text-2xl ${s.color}`}>{s.value}</div>
            <div className="text-gray-500 text-xs mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Revenue Chart */}
      <div className="bg-gray-900 border border-white/5 rounded-3xl p-6">
        <h2 className="font-display font-bold text-lg text-white mb-4">Monthly Revenue</h2>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={monthlyRevenue}>
            <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#6B7280' }} />
            <YAxis hide />
            <Tooltip contentStyle={tooltipStyle} formatter={v => [`$${v}`, 'Revenue']} />
            <Bar dataKey="revenue" fill="#8B5CF6" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Subscriptions */}
      <div className="bg-gray-900 border border-white/5 rounded-3xl overflow-hidden">
        <div className="px-6 py-4 border-b border-white/5">
          <h2 className="font-display font-bold text-lg text-white">Subscriptions</h2>
        </div>
        {subs.length === 0 ? (
          <div className="text-center py-10 text-gray-600">No subscriptions yet</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  {['Plan', 'Amount', 'Status', 'Started', 'Expires'].map(h => (
                    <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {subs.map(s => (
                  <tr key={s.id} className="hover:bg-white/2 transition-colors">
                    <td className="px-5 py-4 text-white text-sm capitalize">{s.plan}</td>
                    <td className="px-5 py-4 text-gray-300 text-sm">${s.amount ?? '—'}/mo</td>
                    <td className="px-5 py-4"><span className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${subStatusColor[s.status] ?? ''}`}>{s.status}</span></td>
                    <td className="px-5 py-4 text-gray-500 text-xs">{new Date(s.started_at).toLocaleDateString()}</td>
                    <td className="px-5 py-4 text-gray-500 text-xs">{s.expires_at ? new Date(s.expires_at).toLocaleDateString() : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Payments */}
      <div className="bg-gray-900 border border-white/5 rounded-3xl overflow-hidden">
        <div className="px-6 py-4 border-b border-white/5 flex items-center justify-between gap-4">
          <h2 className="font-display font-bold text-lg text-white">Payment History</h2>
          <div className="relative w-56">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 w-3.5 h-3.5" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              className="w-full bg-gray-800 border border-white/10 text-white rounded-xl pl-9 pr-3 py-2 text-xs focus:outline-none focus:border-purple-500 placeholder:text-gray-600"
              placeholder="Filter payments…" />
          </div>
        </div>
        {filtered.length === 0 ? (
          <div className="text-center py-10 text-gray-600">No payments yet</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/5">
                  {['Amount', 'Description', 'Method', 'Status', 'Date'].map(h => (
                    <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filtered.map(p => (
                  <tr key={p.id} className="hover:bg-white/2 transition-colors">
                    <td className="px-5 py-4 text-white font-semibold text-sm">${p.amount}</td>
                    <td className="px-5 py-4 text-gray-400 text-sm">{p.description ?? '—'}</td>
                    <td className="px-5 py-4 text-gray-500 text-xs capitalize">{p.payment_method ?? '—'}</td>
                    <td className="px-5 py-4"><span className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${statusColor[p.status] ?? ''}`}>{p.status}</span></td>
                    <td className="px-5 py-4 text-gray-500 text-xs">{new Date(p.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
