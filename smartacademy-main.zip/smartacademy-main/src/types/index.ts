export type UserRole = 'student' | 'teacher' | 'parent' | 'admin';

export interface Profile {
  id: string;
  role: UserRole;
  full_name: string | null;
  avatar_url: string | null;
  force_password_change?: boolean;
  is_active?: boolean;
  created_at: string;
  updated_at: string;
}

export interface Student {
  id: string;
  user_id: string;
  parent_id: string | null;
  username: string;
  current_level: number;
  xp_points: number;
  streak_days: number;
  last_activity_at: string;
  avatar_id: string;
  created_at: string;
}

export interface Parent {
  id: string;
  user_id: string;
  phone: string | null;
  address: Address | null;
  created_at: string;
}

export interface Teacher {
  id: string;
  user_id: string;
  bio: string | null;
  specialization: string | null;
  rating: number;
  total_students: number;
  created_at: string;
}

export interface Address {
  street: string;
  city: string;
  state: string;
  zip: string;
  country: string;
}

export interface Course {
  id: string;
  teacher_id: string;
  title: string;
  description: string | null;
  thumbnail_url: string | null;
  category: string | null;
  difficulty_level: number;
  duration_minutes: number;
  price: number;
  is_published: boolean;
  xp_reward: number;
  created_at: string;
  updated_at: string;
  teacher?: Teacher & { profiles?: Profile };
}

export interface Lesson {
  id: string;
  course_id: string;
  title: string;
  description: string | null;
  video_url: string | null;
  duration_minutes: number;
  order_index: number;
  content: Record<string, unknown> | null;
  xp_reward: number;
  created_at: string;
}

export interface Enrollment {
  id: string;
  student_id: string;
  course_id: string;
  enrolled_at: string;
  completed_at: string | null;
  progress_percent: number;
  course?: Course;
}

export interface LiveSession {
  id: string;
  teacher_id: string;
  course_id: string | null;
  title: string;
  scheduled_at: string;
  duration_minutes: number;
  platform: 'zoom' | 'google_meet';
  meeting_url: string | null;
  status: 'scheduled' | 'live' | 'ended' | 'cancelled';
  created_at: string;
}

export interface Assignment {
  id: string;
  teacher_id: string;
  course_id: string | null;
  title: string;
  description: string | null;
  due_date: string | null;
  max_points: number;
  created_at: string;
}

export interface Submission {
  id: string;
  assignment_id: string;
  student_id: string;
  content: string | null;
  photo_url: string | null;
  grade: number | null;
  feedback: string | null;
  status: 'pending' | 'submitted' | 'graded';
  submitted_at: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string | null;
  icon_url: string | null;
  category: string | null;
  requirement: Record<string, unknown> | null;
  created_at: string;
}

export interface StudentBadge {
  id: string;
  student_id: string;
  badge_id: string;
  earned_at: string;
  badge?: Badge;
}

export interface RobotProject {
  id: string;
  student_id: string;
  title: string;
  description: string | null;
  photo_url: string | null;
  course_id: string | null;
  status: 'pending' | 'approved' | 'rejected';
  teacher_feedback: string | null;
  created_at: string;
}

export interface PhysicalKit {
  id: string;
  serial_number: string;
  student_id: string | null;
  name: string | null;
  description: string | null;
  contents: Record<string, unknown> | null;
  created_at: string;
  shipment?: KitShipment;
}

export interface KitShipment {
  id: string;
  kit_id: string;
  tracking_number: string | null;
  carrier: string | null;
  address: Address;
  status: 'processing' | 'shipped' | 'in_transit' | 'delivered' | 'returned';
  shipped_at: string | null;
  delivered_at: string | null;
  estimated_delivery: string | null;
  created_at: string;
}

export interface Payment {
  id: string;
  parent_id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  payment_method: string | null;
  description: string | null;
  invoice_url: string | null;
  created_at: string;
}

export interface Subscription {
  id: string;
  parent_id: string;
  plan: 'monthly' | 'annual';
  status: 'active' | 'cancelled' | 'expired';
  amount: number | null;
  started_at: string;
  expires_at: string | null;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string | null;
  type: string;
  is_read: boolean;
  created_at: string;
}

export interface Message {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
}

export interface Certificate {
  id: string;
  student_id: string;
  course_id: string;
  issued_at: string;
  certificate_url: string | null;
  certificate_number: string;
  course?: Course;
}

export const STUDENT_LEVELS = [
  { level: 1, name: 'Circuit Explorer', color: 'text-green-500', bg: 'bg-green-100', minXP: 0 },
  { level: 2, name: 'Sensor Builder', color: 'text-blue-500', bg: 'bg-blue-100', minXP: 500 },
  { level: 3, name: 'Robo Inventor', color: 'text-purple-500', bg: 'bg-purple-100', minXP: 1500 },
  { level: 4, name: 'AI Engineer', color: 'text-orange-500', bg: 'bg-orange-100', minXP: 3500 },
  { level: 5, name: 'Robotics Master', color: 'text-yellow-500', bg: 'bg-yellow-100', minXP: 7500 },
];

export const LEVEL_NAMES = STUDENT_LEVELS.map(l => l.name);
