import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Profile, Student, Teacher, Parent } from '../types';
import { supabase } from '../lib/supabase';

interface AuthState {
  profile: Profile | null;
  student: Student | null;
  teacher: Teacher | null;
  parent: Parent | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  setProfile: (profile: Profile | null) => void;
  setStudent: (student: Student | null) => void;
  setTeacher: (teacher: Teacher | null) => void;
  setParent: (parent: Parent | null) => void;
  setLoading: (loading: boolean) => void;
  signOut: () => Promise<void>;
  fetchUserData: (userId: string) => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      profile: null,
      student: null,
      teacher: null,
      parent: null,
      isLoading: true,
      isAuthenticated: false,
      setProfile: (profile) => set({ profile, isAuthenticated: !!profile }),
      setStudent: (student) => set({ student }),
      setTeacher: (teacher) => set({ teacher }),
      setParent: (parent) => set({ parent }),
      setLoading: (isLoading) => set({ isLoading }),
      signOut: async () => {
        await supabase.auth.signOut();
        set({ profile: null, student: null, teacher: null, parent: null, isAuthenticated: false });
      },
      fetchUserData: async (userId: string) => {
        try {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', userId)
            .maybeSingle();

          if (!profile) return;
          set({ profile, isAuthenticated: true });

          if (profile.role === 'student') {
            const { data: student } = await supabase
              .from('students')
              .select('*')
              .eq('user_id', userId)
              .maybeSingle();
            set({ student });
          } else if (profile.role === 'teacher') {
            const { data: teacher } = await supabase
              .from('teachers')
              .select('*')
              .eq('user_id', userId)
              .maybeSingle();
            set({ teacher });
          } else if (profile.role === 'parent') {
            const { data: parent } = await supabase
              .from('parents')
              .select('*')
              .eq('user_id', userId)
              .maybeSingle();
            set({ parent });
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        }
      },
    }),
    {
      name: 'auth-store',
      partialize: (state) => ({
        profile: state.profile,
        student: state.student,
        teacher: state.teacher,
        parent: state.parent,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);
