
-- Storage RLS policies for course-files bucket
CREATE POLICY "teachers_manage_course_files"
ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'course-files')
WITH CHECK (bucket_id = 'course-files');

CREATE POLICY "teachers_manage_lesson_videos"
ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'lesson-videos')
WITH CHECK (bucket_id = 'lesson-videos');

CREATE POLICY "teachers_manage_lesson_documents"
ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'lesson-documents')
WITH CHECK (bucket_id = 'lesson-documents');

CREATE POLICY "authenticated_manage_project_images"
ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'project-images')
WITH CHECK (bucket_id = 'project-images');

CREATE POLICY "public_read_project_images"
ON storage.objects FOR SELECT TO anon
USING (bucket_id = 'project-images');
