
-- ── Selling mode: clear all user-generated data ─────────────────────────────
TRUNCATE TABLE
  admin_activity_log,
  attendance,
  file_downloads,
  file_views,
  lesson_completions,
  student_badges,
  submissions,
  robot_projects,
  certificates,
  enrollments,
  kit_shipments,
  physical_kits,
  payments,
  subscriptions,
  notifications,
  messages,
  live_sessions,
  assignments,
  course_files,
  course_modules,
  lessons,
  courses,
  students,
  teachers,
  parents,
  profiles
CASCADE;

-- Re-seed reference badges
INSERT INTO badges (name, description, category) VALUES
  ('First Login',     'Logged in for the first time',                'milestone'),
  ('Circuit Explorer','Reached Level 1',                             'level'),
  ('Sensor Builder',  'Reached Level 2',                             'level'),
  ('Robo Inventor',   'Reached Level 3',                             'level'),
  ('AI Engineer',     'Reached Level 4',                             'level'),
  ('Robotics Master', 'Reached Level 5',                             'level'),
  ('First Course',    'Completed first course',                      'achievement'),
  ('7-Day Streak',    'Maintained a 7-day learning streak',          'streak'),
  ('30-Day Streak',   'Maintained a 30-day learning streak',         'streak'),
  ('Project Star',    'Had a project approved by teacher',           'project'),
  ('Quiz Master',     'Scored 100% on a quiz',                       'quiz'),
  ('Speed Learner',   'Completed 3 lessons in one day',              'learning')
ON CONFLICT DO NOTHING;

-- ── Seed default admin auth user ────────────────────────────────────────────
DO $$
DECLARE
  admin_uid UUID;
  existing_uid UUID;
BEGIN
  -- Check if admin already exists in auth.users
  SELECT id INTO existing_uid FROM auth.users WHERE email = 'admin@smartkidsacademy.com' LIMIT 1;

  IF existing_uid IS NULL THEN
    admin_uid := gen_random_uuid();

    INSERT INTO auth.users (
      id, instance_id, email, encrypted_password,
      email_confirmed_at, created_at, updated_at,
      raw_app_meta_data, raw_user_meta_data,
      is_super_admin, role, aud,
      confirmation_token, recovery_token, email_change_token_new,
      email_change
    ) VALUES (
      admin_uid,
      '00000000-0000-0000-0000-000000000000',
      'admin@smartkidsacademy.com',
      crypt('ChangeMe123!', gen_salt('bf')),
      NOW(), NOW(), NOW(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"Admin"}',
      FALSE, 'authenticated', 'authenticated',
      '', '', '', ''
    );

    INSERT INTO profiles (id, role, full_name, force_password_change, is_active)
    VALUES (admin_uid, 'admin', 'Admin', TRUE, TRUE);

  ELSE
    -- Admin exists: update password and set force_password_change
    UPDATE auth.users
    SET encrypted_password = crypt('ChangeMe123!', gen_salt('bf')),
        updated_at = NOW()
    WHERE id = existing_uid;

    INSERT INTO profiles (id, role, full_name, force_password_change, is_active)
    VALUES (existing_uid, 'admin', 'Admin', TRUE, TRUE)
    ON CONFLICT (id) DO UPDATE
      SET force_password_change = TRUE, is_active = TRUE, role = 'admin';
  END IF;
END $$;
