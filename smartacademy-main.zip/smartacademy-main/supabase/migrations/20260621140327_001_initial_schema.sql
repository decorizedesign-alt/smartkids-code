
-- Users table (extends Supabase auth.users)
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('student', 'teacher', 'parent', 'admin')),
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Parents
CREATE TABLE parents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE REFERENCES profiles(id) ON DELETE CASCADE,
  phone TEXT,
  address JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Teachers
CREATE TABLE teachers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE REFERENCES profiles(id) ON DELETE CASCADE,
  bio TEXT,
  specialization TEXT,
  rating NUMERIC(3,2) DEFAULT 0,
  total_students INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Students
CREATE TABLE students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE REFERENCES profiles(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES parents(id),
  username TEXT UNIQUE NOT NULL,
  pin_hash TEXT,
  current_level INT DEFAULT 1 CHECK (current_level BETWEEN 1 AND 5),
  xp_points INT DEFAULT 0,
  streak_days INT DEFAULT 0,
  last_activity_at TIMESTAMPTZ DEFAULT NOW(),
  avatar_id TEXT DEFAULT 'robot1',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Courses
CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id),
  title TEXT NOT NULL,
  description TEXT,
  thumbnail_url TEXT,
  category TEXT,
  difficulty_level INT DEFAULT 1 CHECK (difficulty_level BETWEEN 1 AND 5),
  duration_minutes INT DEFAULT 0,
  price NUMERIC(10,2) DEFAULT 0,
  is_published BOOLEAN DEFAULT FALSE,
  xp_reward INT DEFAULT 100,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Lessons
CREATE TABLE lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  video_url TEXT,
  duration_minutes INT DEFAULT 0,
  order_index INT NOT NULL,
  content JSONB,
  xp_reward INT DEFAULT 20,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enrollments
CREATE TABLE enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  course_id UUID REFERENCES courses(id) ON DELETE CASCADE,
  enrolled_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  progress_percent INT DEFAULT 0,
  UNIQUE(student_id, course_id)
);

-- Lesson completions
CREATE TABLE lesson_completions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  lesson_id UUID REFERENCES lessons(id) ON DELETE CASCADE,
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, lesson_id)
);

-- Live sessions
CREATE TABLE live_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id),
  course_id UUID REFERENCES courses(id),
  title TEXT NOT NULL,
  scheduled_at TIMESTAMPTZ NOT NULL,
  duration_minutes INT DEFAULT 60,
  platform TEXT DEFAULT 'zoom' CHECK (platform IN ('zoom', 'google_meet')),
  meeting_url TEXT,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'live', 'ended', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Assignments
CREATE TABLE assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id),
  course_id UUID REFERENCES courses(id),
  title TEXT NOT NULL,
  description TEXT,
  due_date TIMESTAMPTZ,
  max_points INT DEFAULT 100,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Submissions
CREATE TABLE submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id UUID REFERENCES assignments(id) ON DELETE CASCADE,
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  content TEXT,
  photo_url TEXT,
  grade INT,
  feedback TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'submitted', 'graded')),
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(assignment_id, student_id)
);

-- Badges
CREATE TABLE badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  icon_url TEXT,
  category TEXT,
  requirement JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Student badges
CREATE TABLE student_badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  badge_id UUID REFERENCES badges(id),
  earned_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, badge_id)
);

-- Robot projects
CREATE TABLE robot_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  photo_url TEXT,
  course_id UUID REFERENCES courses(id),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  teacher_feedback TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Physical kits
CREATE TABLE physical_kits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  serial_number TEXT UNIQUE NOT NULL,
  student_id UUID REFERENCES students(id),
  name TEXT,
  description TEXT,
  contents JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Kit shipments
CREATE TABLE kit_shipments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kit_id UUID REFERENCES physical_kits(id),
  tracking_number TEXT,
  carrier TEXT,
  address JSONB NOT NULL,
  status TEXT DEFAULT 'processing' CHECK (status IN ('processing', 'shipped', 'in_transit', 'delivered', 'returned')),
  shipped_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  estimated_delivery TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Payments
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID REFERENCES parents(id),
  amount NUMERIC(10,2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  payment_method TEXT,
  description TEXT,
  invoice_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Subscriptions
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID REFERENCES parents(id),
  plan TEXT NOT NULL CHECK (plan IN ('monthly', 'annual')),
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired')),
  amount NUMERIC(10,2),
  started_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notifications
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT,
  type TEXT DEFAULT 'info',
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Messages
CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID REFERENCES profiles(id),
  recipient_id UUID REFERENCES profiles(id),
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Certificates
CREATE TABLE certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  course_id UUID REFERENCES courses(id),
  issued_at TIMESTAMPTZ DEFAULT NOW(),
  certificate_url TEXT,
  certificate_number TEXT UNIQUE
);

-- Attendance
CREATE TABLE attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES live_sessions(id) ON DELETE CASCADE,
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  left_at TIMESTAMPTZ,
  UNIQUE(session_id, student_id)
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE parents ENABLE ROW LEVEL SECURITY;
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE lesson_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE live_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE student_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE robot_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE physical_kits ENABLE ROW LEVEL SECURITY;
ALTER TABLE kit_shipments ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;

-- RLS Policies: profiles
CREATE POLICY "select_own_profile" ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE TO authenticated USING (auth.uid() = id);

-- RLS Policies: notifications
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_notifications" ON notifications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_notifications" ON notifications FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies: messages
CREATE POLICY "select_own_messages" ON messages FOR SELECT TO authenticated USING (auth.uid() = sender_id OR auth.uid() = recipient_id);
CREATE POLICY "insert_own_messages" ON messages FOR INSERT TO authenticated WITH CHECK (auth.uid() = sender_id);
CREATE POLICY "update_own_messages" ON messages FOR UPDATE TO authenticated USING (auth.uid() = sender_id OR auth.uid() = recipient_id);
CREATE POLICY "delete_own_messages" ON messages FOR DELETE TO authenticated USING (auth.uid() = sender_id);

-- RLS Policies: courses (public read for published, teacher write)
CREATE POLICY "select_published_courses" ON courses FOR SELECT USING (is_published = TRUE);
CREATE POLICY "insert_own_courses" ON courses FOR INSERT TO authenticated WITH CHECK (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_courses" ON courses FOR UPDATE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "delete_own_courses" ON courses FOR DELETE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);

-- RLS Policies: lessons (public read for published courses)
CREATE POLICY "select_lessons" ON lessons FOR SELECT USING (
  course_id IN (SELECT id FROM courses WHERE is_published = TRUE)
);
CREATE POLICY "insert_lessons" ON lessons FOR INSERT TO authenticated WITH CHECK (
  course_id IN (SELECT id FROM courses WHERE teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid()))
);
CREATE POLICY "update_lessons" ON lessons FOR UPDATE TO authenticated USING (
  course_id IN (SELECT id FROM courses WHERE teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid()))
);
CREATE POLICY "delete_lessons" ON lessons FOR DELETE TO authenticated USING (
  course_id IN (SELECT id FROM courses WHERE teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid()))
);

-- RLS Policies: students
CREATE POLICY "select_own_student" ON students FOR SELECT TO authenticated USING (
  user_id = auth.uid() OR 
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid()) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "insert_own_student" ON students FOR INSERT TO authenticated WITH CHECK (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_student" ON students FOR UPDATE TO authenticated USING (
  user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);
CREATE POLICY "delete_own_student" ON students FOR DELETE TO authenticated USING (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);

-- RLS Policies: parents
CREATE POLICY "select_own_parent" ON parents FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "insert_own_parent" ON parents FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "update_own_parent" ON parents FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "delete_own_parent" ON parents FOR DELETE TO authenticated USING (user_id = auth.uid());

-- RLS Policies: teachers
CREATE POLICY "select_teachers" ON teachers FOR SELECT USING (TRUE);
CREATE POLICY "insert_own_teacher" ON teachers FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "update_own_teacher" ON teachers FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "delete_own_teacher" ON teachers FOR DELETE TO authenticated USING (user_id = auth.uid());

-- RLS Policies: enrollments
CREATE POLICY "select_own_enrollments" ON enrollments FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid()))
);
CREATE POLICY "insert_own_enrollments" ON enrollments FOR INSERT TO authenticated WITH CHECK (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid()))
);
CREATE POLICY "update_own_enrollments" ON enrollments FOR UPDATE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid()))
);
CREATE POLICY "delete_own_enrollments" ON enrollments FOR DELETE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid()))
);

-- RLS Policies: badges (public read)
CREATE POLICY "select_badges" ON badges FOR SELECT USING (TRUE);
CREATE POLICY "insert_badges" ON badges FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "update_badges" ON badges FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "delete_badges" ON badges FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- RLS Policies: student_badges
CREATE POLICY "select_own_student_badges" ON student_badges FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "insert_student_badges" ON student_badges FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "update_student_badges" ON student_badges FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "delete_student_badges" ON student_badges FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);

-- RLS Policies: robot_projects
CREATE POLICY "select_own_projects" ON robot_projects FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "insert_own_projects" ON robot_projects FOR INSERT TO authenticated WITH CHECK (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_projects" ON robot_projects FOR UPDATE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid()) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "delete_own_projects" ON robot_projects FOR DELETE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid()) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- RLS Policies: payments
CREATE POLICY "select_own_payments" ON payments FOR SELECT TO authenticated USING (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);
CREATE POLICY "insert_own_payments" ON payments FOR INSERT TO authenticated WITH CHECK (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_payments" ON payments FOR UPDATE TO authenticated USING (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);
CREATE POLICY "delete_own_payments" ON payments FOR DELETE TO authenticated USING (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);

-- RLS Policies: subscriptions
CREATE POLICY "select_own_subscriptions" ON subscriptions FOR SELECT TO authenticated USING (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);
CREATE POLICY "insert_own_subscriptions" ON subscriptions FOR INSERT TO authenticated WITH CHECK (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_subscriptions" ON subscriptions FOR UPDATE TO authenticated USING (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);
CREATE POLICY "delete_own_subscriptions" ON subscriptions FOR DELETE TO authenticated USING (
  parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
);

-- RLS Policies: certificates
CREATE POLICY "select_own_certificates" ON certificates FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid()))
);
CREATE POLICY "insert_certificates" ON certificates FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "update_certificates" ON certificates FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "delete_certificates" ON certificates FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- RLS Policies: live_sessions
CREATE POLICY "select_live_sessions" ON live_sessions FOR SELECT USING (TRUE);
CREATE POLICY "insert_live_sessions" ON live_sessions FOR INSERT TO authenticated WITH CHECK (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "update_live_sessions" ON live_sessions FOR UPDATE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "delete_live_sessions" ON live_sessions FOR DELETE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);

-- RLS Policies: assignments
CREATE POLICY "select_assignments" ON assignments FOR SELECT TO authenticated USING (TRUE);
CREATE POLICY "insert_assignments" ON assignments FOR INSERT TO authenticated WITH CHECK (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "update_assignments" ON assignments FOR UPDATE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "delete_assignments" ON assignments FOR DELETE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);

-- RLS Policies: submissions
CREATE POLICY "select_own_submissions" ON submissions FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid()) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "insert_own_submissions" ON submissions FOR INSERT TO authenticated WITH CHECK (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_submissions" ON submissions FOR UPDATE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid()) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "delete_own_submissions" ON submissions FOR DELETE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);

-- RLS Policies: physical_kits
CREATE POLICY "select_own_kits" ON physical_kits FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "insert_kits" ON physical_kits FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "update_kits" ON physical_kits FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "delete_kits" ON physical_kits FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- RLS Policies: kit_shipments
CREATE POLICY "select_own_shipments" ON kit_shipments FOR SELECT TO authenticated USING (
  kit_id IN (SELECT id FROM physical_kits WHERE student_id IN (
    SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid())
  ))
);
CREATE POLICY "insert_shipments" ON kit_shipments FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "update_shipments" ON kit_shipments FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "delete_shipments" ON kit_shipments FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- RLS Policies: lesson_completions
CREATE POLICY "select_own_completions" ON lesson_completions FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid() OR parent_id IN (SELECT id FROM parents WHERE user_id = auth.uid()))
);
CREATE POLICY "insert_own_completions" ON lesson_completions FOR INSERT TO authenticated WITH CHECK (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_completions" ON lesson_completions FOR UPDATE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "delete_own_completions" ON lesson_completions FOR DELETE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);

-- RLS Policies: attendance
CREATE POLICY "select_attendance" ON attendance FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid()) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('teacher', 'admin'))
);
CREATE POLICY "insert_attendance" ON attendance FOR INSERT TO authenticated WITH CHECK (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "update_attendance" ON attendance FOR UPDATE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "delete_attendance" ON attendance FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Seed badges
INSERT INTO badges (name, description, category) VALUES
  ('First Login', 'Logged in for the first time', 'milestone'),
  ('Circuit Explorer', 'Reached Level 1', 'level'),
  ('Sensor Builder', 'Reached Level 2', 'level'),
  ('Robo Inventor', 'Reached Level 3', 'level'),
  ('AI Engineer', 'Reached Level 4', 'level'),
  ('Robotics Master', 'Reached Level 5', 'level'),
  ('First Course', 'Completed first course', 'achievement'),
  ('7-Day Streak', 'Maintained a 7-day learning streak', 'streak'),
  ('30-Day Streak', 'Maintained a 30-day learning streak', 'streak'),
  ('Project Star', 'Had a project approved by teacher', 'project'),
  ('Quiz Master', 'Scored 100% on a quiz', 'quiz'),
  ('Speed Learner', 'Completed 3 lessons in one day', 'learning');
