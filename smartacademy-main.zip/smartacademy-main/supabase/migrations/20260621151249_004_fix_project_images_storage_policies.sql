
-- Drop the two overly-broad project-images policies
DROP POLICY IF EXISTS "authenticated_manage_project_images" ON storage.objects;
DROP POLICY IF EXISTS "public_read_project_images" ON storage.objects;

-- Authenticated users (teachers / students) can INSERT into project-images
CREATE POLICY "project_images_insert"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'project-images');

-- Authenticated users can UPDATE only objects they own
CREATE POLICY "project_images_update"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'project-images' AND owner = auth.uid())
  WITH CHECK (bucket_id = 'project-images' AND owner = auth.uid());

-- Authenticated users can DELETE only objects they own
CREATE POLICY "project_images_delete"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'project-images' AND owner = auth.uid());

-- Authenticated users can SELECT only objects they own
-- (direct URL access for public bucket doesn't require a policy;
--  this prevents authenticated clients from listing others' files)
CREATE POLICY "project_images_select_own"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'project-images' AND owner = auth.uid());

-- Anon SELECT is intentionally removed: public bucket serves object URLs
-- via the CDN without needing a storage.objects SELECT policy for anon.
-- Removing anon SELECT prevents bucket enumeration while URLs still work.
