
-- Course modules (folders/sections teachers organize files into)
CREATE TABLE course_modules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT DEFAULT 'General',
  order_index INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Course files (uploaded teaching materials)
CREATE TABLE course_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
  module_id UUID REFERENCES course_modules(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT,
  file_url TEXT,
  file_type TEXT,
  file_size BIGINT DEFAULT 0,
  file_name TEXT,
  thumbnail_url TEXT,
  visibility TEXT DEFAULT 'draft' CHECK (visibility IN ('draft', 'published')),
  release_date TIMESTAMPTZ,
  order_index INT DEFAULT 0,
  view_count INT DEFAULT 0,
  download_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Track which students viewed a file
CREATE TABLE file_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  file_id UUID REFERENCES course_files(id) ON DELETE CASCADE,
  viewed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, file_id)
);

-- Track file downloads by students
CREATE TABLE file_downloads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  file_id UUID REFERENCES course_files(id) ON DELETE CASCADE,
  downloaded_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE course_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_downloads ENABLE ROW LEVEL SECURITY;

-- RLS: course_modules
CREATE POLICY "select_own_modules" ON course_modules FOR SELECT TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid()) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('student','parent'))
);
CREATE POLICY "insert_own_modules" ON course_modules FOR INSERT TO authenticated WITH CHECK (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_modules" ON course_modules FOR UPDATE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "delete_own_modules" ON course_modules FOR DELETE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);

-- RLS: course_files
CREATE POLICY "select_course_files" ON course_files FOR SELECT TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid()) OR
  (visibility = 'published' AND EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('student','parent')))
);
CREATE POLICY "insert_own_files" ON course_files FOR INSERT TO authenticated WITH CHECK (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "update_own_files" ON course_files FOR UPDATE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);
CREATE POLICY "delete_own_files" ON course_files FOR DELETE TO authenticated USING (
  teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid())
);

-- RLS: file_views
CREATE POLICY "select_file_views" ON file_views FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid()) OR
  file_id IN (SELECT id FROM course_files WHERE teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid()))
);
CREATE POLICY "insert_file_views" ON file_views FOR INSERT TO authenticated WITH CHECK (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "update_file_views" ON file_views FOR UPDATE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "delete_file_views" ON file_views FOR DELETE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);

-- RLS: file_downloads
CREATE POLICY "select_file_downloads" ON file_downloads FOR SELECT TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid()) OR
  file_id IN (SELECT id FROM course_files WHERE teacher_id IN (SELECT id FROM teachers WHERE user_id = auth.uid()))
);
CREATE POLICY "insert_file_downloads" ON file_downloads FOR INSERT TO authenticated WITH CHECK (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "update_file_downloads" ON file_downloads FOR UPDATE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
CREATE POLICY "delete_file_downloads" ON file_downloads FOR DELETE TO authenticated USING (
  student_id IN (SELECT id FROM students WHERE user_id = auth.uid())
);
